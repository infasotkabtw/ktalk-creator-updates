﻿<?php

require __DIR__ . '/vendor/autoload.php';

use Kontur\Talk\TalkClient;

function failJson(string $message): void {
    echo json_encode([
        'ok' => false,
        'message' => $message
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit(1);
}

function friendlyException(Throwable $e): string {
    $message = $e->getMessage();
    $code = (int)$e->getCode();
    $lower = mb_strtolower($message);

    if (str_contains($lower, 'curl error 6') || str_contains($lower, 'could not resolve')) {
        return 'Нет интернета';
    }
    if (str_contains($lower, 'curl error 7') || str_contains($lower, 'failed to connect')) {
        return 'KTalk недоступен';
    }
    if (str_contains($lower, 'curl error 28') || str_contains($lower, 'timed out')) {
        return 'KTalk не отвечает';
    }
    if (str_contains($lower, 'curl error 60') || str_contains($lower, 'certificate')) {
        return 'Ошибка SSL';
    }
    if ($code === 401 || str_contains($lower, '401')) {
        return 'API-ключ недействителен или истёк';
    }
    if ($code === 403 || str_contains($lower, '403') || str_contains($lower, 'forbidden')) {
        return 'API-ключ принят, но у него недостаточно прав';
    }

    if ($message === '' || $message === 'API error') {
        return 'API KTalk вернул ошибку';
    }

    return $message;
}

$apiKey = getenv('KTALK_API_KEY');
if (!$apiKey) {
    failJson('API-ключ не сохранён');
}

try {
    $client = new TalkClient('oooparta', $apiKey);

    // Безопасная проверка: ничего не создаёт и не меняет.
    $client->users->search([
        'email' => ['ktalk-healthcheck@invalid.example']
    ]);

    echo json_encode([
        'ok' => true,
        'message' => 'доступен'
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {
    failJson(friendlyException($e));
}
