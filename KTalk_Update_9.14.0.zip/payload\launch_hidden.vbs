Option Explicit

Dim shell, cmd
Set shell = CreateObject("WScript.Shell")

cmd = "powershell.exe -NoProfile -ExecutionPolicy Bypass -STA -WindowStyle Hidden -File ""C:\\ktalk-auto\\KTalk_GUI.ps1"""
shell.Run cmd, 0, False
