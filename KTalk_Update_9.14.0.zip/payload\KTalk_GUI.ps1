﻿Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName System.Security

[System.Windows.Forms.Application]::EnableVisualStyles()

# ==================== Native Windows UI ====================
# Тёмная нативная строка заголовка Windows + placeholder для поиска.

try {
    Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class KTalkNativeUi
{
    [DllImport("dwmapi.dll")]
    public static extern int DwmSetWindowAttribute(
        IntPtr hwnd,
        int dwAttribute,
        ref int pvAttribute,
        int cbAttribute
    );

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern IntPtr SendMessage(
        IntPtr hWnd,
        UInt32 Msg,
        IntPtr wParam,
        string lParam
    );

    [StructLayout(LayoutKind.Sequential)]
    public struct RECT
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    [DllImport("user32.dll", EntryPoint = "SendMessageW")]
    public static extern IntPtr SendMessageRect(
        IntPtr hWnd,
        UInt32 Msg,
        IntPtr wParam,
        ref RECT lParam
    );
}
"@ -ErrorAction SilentlyContinue
} catch {}

function Set-NativeTitleBarTheme($window, [bool]$dark) {
    try {
        # Доступ к Handle гарантирует создание нативного окна.
        $hwnd = $window.Handle
        if ($hwnd -eq [IntPtr]::Zero) { return }

        $enabled = if ($dark) { 1 } else { 0 }

        # Windows 10 1903+ / Windows 11.
        $result = [KTalkNativeUi]::DwmSetWindowAttribute(
            $hwnd,
            20,
            [ref]$enabled,
            4
        )

        # Fallback для некоторых более старых сборок Windows 10.
        if ($result -ne 0) {
            [void][KTalkNativeUi]::DwmSetWindowAttribute(
                $hwnd,
                19,
                [ref]$enabled,
                4
            )
        }
    } catch {
        # Если DWM-атрибут не поддерживается, оставляем системный title bar.
    }
}

function Set-TextBoxCueBanner($textBox, [string]$text) {
    try {
        # EM_SETCUEBANNER = 0x1501
        [void][KTalkNativeUi]::SendMessage(
            $textBox.Handle,
            0x1501,
            [IntPtr]::Zero,
            $text
        )
    } catch {}
}

function Set-EditTextCenterRect([System.Windows.Forms.TextBox]$box) {
    if ($null -eq $box -or $box.IsDisposed) {
        return
    }

    try {
        # EM_SETRECT works on a multiline Win32 Edit control.
        # We deliberately use a multiline TextBox with one visible line so
        # Windows lets us define the exact vertical formatting rectangle.
        $null = $box.Handle

        $clientWidth = [Math]::Max(1, $box.ClientSize.Width)
        $clientHeight = [Math]::Max(1, $box.ClientSize.Height)

        $fontHeight = [Math]::Max(14, $box.Font.Height)
        $lineHeight = [Math]::Min($clientHeight - 2, $fontHeight + 2)
        $top = [Math]::Max(0, [int][Math]::Floor(($clientHeight - $lineHeight) / 2.0))

        $rect = New-Object KTalkNativeUi+RECT
        $rect.Left = 4
        $rect.Top = $top
        $rect.Right = [Math]::Max(5, $clientWidth - 4)
        $rect.Bottom = [Math]::Min($clientHeight, $top + $lineHeight)

        # EM_SETRECT = 0x00B3
        [void][KTalkNativeUi]::SendMessageRect(
            $box.Handle,
            0x00B3,
            [IntPtr]::Zero,
            [ref]$rect
        )

        $box.Invalidate()
    } catch {}
}

# ==================== Single instance ====================
# Если KTalk Creator уже запущен, второй экземпляр не создаётся.
# Вместо этого существующее окно поднимается на передний план.

$appWindowTitle = "KTalk Creator v9.14.0"
$createdNew = $false
$script:singleInstanceMutex = [System.Threading.Mutex]::new(
    $true,
    "Local\PARTA_KTalk_Creator",
    [ref]$createdNew
)

if (-not $createdNew) {
    try {
        Add-Type @"
using System;
using System.Runtime.InteropServices;

public static class KTalkWindowNative
{
    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);

    [DllImport("user32.dll")]
    public static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);
}
"@ -ErrorAction SilentlyContinue

        $existingWindow = [KTalkWindowNative]::FindWindow($null, $appWindowTitle)

        if ($existingWindow -ne [IntPtr]::Zero) {
            # 9 = SW_RESTORE, 5 = SW_SHOW
            [void][KTalkWindowNative]::ShowWindow($existingWindow, 9)
            [void][KTalkWindowNative]::ShowWindow($existingWindow, 5)
            [void][KTalkWindowNative]::SetForegroundWindow($existingWindow)
        }
    } catch {}

    try { $script:singleInstanceMutex.Dispose() } catch {}
    exit
}

# ==================== Paths / state ====================

$base = Split-Path -Parent $MyInvocation.MyCommand.Path
$keyFile = Join-Path $base "ktalk_api_key.dat"
$phpFile = Join-Path $base "create_room.php"
$apiCheckFile = Join-Path $base "api_check.php"
$dataDir = Join-Path $base "data"
$historyFile = Join-Path $dataDir "history.csv"
$historyAuditFile = Join-Path $dataDir "history_audit.csv"
$settingsFile = Join-Path $dataDir "settings.json"
$roomMapFile = Join-Path $dataDir "room_map.csv"
$archiveDir = Join-Path $dataDir "archive"
$versionFile = Join-Path $base "version.json"
$updateChannelFile = Join-Path $base "update_channel.json"
$updaterFile = Join-Path $base "KTalk_Updater.ps1"
$script:appVersion = [version]"9.14.0"

if (-not (Test-Path $dataDir)) {
    New-Item -ItemType Directory -Path $dataDir -Force | Out-Null
}

if (-not (Test-Path $archiveDir)) {
    New-Item -ItemType Directory -Path $archiveDir -Force | Out-Null
}

$standardSlots = @("11:00","12:30","14:00","15:30","17:00","18:30","20:00","21:30")
$script:selectedTime = $null
$script:isCustomTime = $false
$script:plainKey = $null
$script:lastUrl = $null
$script:lastMessage = $null
$script:history = @()
$script:archiveHistory = @()
$script:slotFilter = $null
$script:stateFilter = "Все"
$script:appPage = "Main"
$script:roomMap = @()
$script:exitRequested = $false
$script:selectedHistoryRecord = $null
$script:remindedHandoffs = @{}
$script:historySearchPlaceholderActive = $false
$script:lastClipboardSignature = ""
$script:pendingAmoData = $null
$script:restoringUiState = $false
$script:clipboardDealIdCandidate = $null
$script:lastDeletedRecord = $null
$culture = [System.Globalization.CultureInfo]::InvariantCulture

# ==================== Helpers ====================

function Get-MoscowNow {
    try {
        return [System.TimeZoneInfo]::ConvertTimeBySystemTimeZoneId(
            [DateTime]::UtcNow,
            "Russian Standard Time"
        )
    } catch {
        return Get-Date
    }
}

function Get-EndTime([string]$start) {
    try {
        $dt = [DateTime]::ParseExact($start, "HH:mm", $culture)
        return $dt.AddMinutes(90).ToString("HH:mm")
    } catch {
        return ""
    }
}

function Is-StandardTime([string]$time) {
    return ($standardSlots -contains $time)
}

function Get-StandardSlotBucket([string]$time) {
    if ([string]::IsNullOrWhiteSpace($time)) {
        return $null
    }

    try {
        $target = [DateTime]::ParseExact($time, "HH:mm", $culture)

        foreach ($slot in $standardSlots) {
            $start = [DateTime]::ParseExact($slot, "HH:mm", $culture)
            $end = $start.AddMinutes(90)

            # Левая граница включается, правая — нет:
            # 14:00 <= 15:00 < 15:30
            # 15:30 уже относится к следующему слоту.
            if ($target -ge $start -and $target -lt $end) {
                return $slot
            }
        }
    } catch {}

    return $null
}

function Test-TimeInSlotBucket([string]$time, [string]$slot) {
    if ([string]::IsNullOrWhiteSpace($slot)) {
        return $false
    }

    return ([string](Get-StandardSlotBucket $time) -eq [string]$slot)
}

function Show-Error([string]$message) {
    if ($script:settings.Sounds) {
        [System.Media.SystemSounds]::Hand.Play()
    }

    [System.Windows.Forms.MessageBox]::Show(
        $message,
        "KTalk — ошибка",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
}

function Show-Info([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        "KTalk",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null
}

function Ask-YesNo([string]$message, [string]$title = "KTalk") {
    $r = [System.Windows.Forms.MessageBox]::Show(
        $message,
        $title,
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    return ($r -eq [System.Windows.Forms.DialogResult]::Yes)
}

function Build-Message([string]$date, [string]$time, [string]$url) {
    return @"
Добрый день!
Сегодня у Вас встреча $date $time по Москве
Ссылка: $url
Ваша PARTA!
"@.Trim()
}

# ==================== API key ====================

function Save-ApiKey([string]$plainKey) {
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($plainKey)
    $protected = [System.Security.Cryptography.ProtectedData]::Protect(
        $bytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )

    [System.IO.File]::WriteAllText(
        $keyFile,
        [Convert]::ToBase64String($protected),
        [System.Text.Encoding]::UTF8
    )
}

function Load-ApiKey {
    if (-not (Test-Path $keyFile)) { return $null }

    try {
        $raw = [System.IO.File]::ReadAllText($keyFile).Trim()
        if ([string]::IsNullOrWhiteSpace($raw)) { return $null }

        $protected = [Convert]::FromBase64String($raw)
        $bytes = [System.Security.Cryptography.ProtectedData]::Unprotect(
            $protected,
            $null,
            [System.Security.Cryptography.DataProtectionScope]::CurrentUser
        )

        return [System.Text.Encoding]::UTF8.GetString($bytes)
    } catch {
        return $null
    }
}

function Ask-And-Save-ApiKey {
    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = "KTalk — API-ключ"
    $dialog.StartPosition = "CenterScreen"
    $dialog.Size = New-Object System.Drawing.Size(485, 210)
    $dialog.FormBorderStyle = "FixedDialog"
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $label = New-Object System.Windows.Forms.Label
    $label.Text = "Введите API-ключ KTalk. Он будет зашифрован Windows DPAPI."
    $label.AutoSize = $true
    $label.Location = New-Object System.Drawing.Point(20, 20)
    $dialog.Controls.Add($label)

    $box = New-Object System.Windows.Forms.TextBox
    $box.Location = New-Object System.Drawing.Point(23, 55)
    $box.Size = New-Object System.Drawing.Size(425, 30)
    $box.UseSystemPasswordChar = $true
    $dialog.Controls.Add($box)

    $save = New-Object System.Windows.Forms.Button
    $save.Text = "Сохранить"
    $save.Location = New-Object System.Drawing.Point(260, 110)
    $save.Size = New-Object System.Drawing.Size(90, 35)
    $save.DialogResult = [System.Windows.Forms.DialogResult]::OK
    $dialog.Controls.Add($save)

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = "Отмена"
    $cancel.Location = New-Object System.Drawing.Point(358, 110)
    $cancel.Size = New-Object System.Drawing.Size(90, 35)
    $cancel.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
    $dialog.Controls.Add($cancel)

    $dialog.AcceptButton = $save
    $dialog.CancelButton = $cancel

    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        return $null
    }

    $value = $box.Text.Trim()

    if ([string]::IsNullOrWhiteSpace($value)) {
        Show-Error "API-ключ не введён."
        return $null
    }

    try {
        Save-ApiKey $value
        return $value
    } catch {
        Show-Error ("Не удалось сохранить API-ключ:`r`n" + $_.Exception.Message)
        return $null
    }
}

function Ensure-ApiKey {
    if (-not [string]::IsNullOrWhiteSpace($script:plainKey)) {
        return $true
    }

    $script:plainKey = Load-ApiKey

    if ([string]::IsNullOrWhiteSpace($script:plainKey)) {
        Remove-Item $keyFile -Force -ErrorAction SilentlyContinue
        $script:plainKey = Ask-And-Save-ApiKey
    }

    return (-not [string]::IsNullOrWhiteSpace($script:plainKey))
}

# ==================== Settings ====================

function Get-DefaultSettings {
    return [pscustomobject]@{
        FutureWarningDays = 14
        Sounds = $true
        Notifications = $true
        Theme = "Light"
        AfterCreate = "SMS"
        MvlTag = ""
        FirstRunCompleted = $false
        AutoUpdateCheck = $true
        UpdateManifestUrl = ""
        LastUpdateCheck = ""
        LastDate = ""
        LastSlotFilter = ""
        LastSelectedId = ""
        LastWorkTab = "Message"
        LastStateFilter = "Все"
        LastAppPage = "Main"
    }
}

function Load-Settings {
    if (-not (Test-Path $settingsFile)) {
        return Get-DefaultSettings
    }

    try {
        $s = Get-Content $settingsFile -Raw -Encoding UTF8 | ConvertFrom-Json

        if ($null -eq $s.FutureWarningDays) {
            $s | Add-Member FutureWarningDays 14 -Force
        }

        if ($null -eq $s.Sounds) {
            $s | Add-Member Sounds $true -Force
        }

        if ($null -eq $s.Notifications) {
            $s | Add-Member Notifications $true -Force
        }

        if ([string]::IsNullOrWhiteSpace([string]$s.Theme)) {
            $s | Add-Member Theme "Light" -Force
        }

        if ([string]::IsNullOrWhiteSpace([string]$s.AfterCreate)) {
            $s | Add-Member AfterCreate "SMS" -Force
        }

        if (@("None","SMS","Link") -notcontains [string]$s.AfterCreate) {
            $s.AfterCreate = "SMS"
        }

        if ($null -eq $s.MvlTag) {
            $s | Add-Member MvlTag "" -Force
        }

        if ($null -eq $s.FirstRunCompleted) {
            $s | Add-Member FirstRunCompleted $false -Force
        }

        if ($null -eq $s.AutoUpdateCheck) {
            $s | Add-Member AutoUpdateCheck $true -Force
        }

        if ($null -eq $s.UpdateManifestUrl) {
            $s | Add-Member UpdateManifestUrl "" -Force
        }

        if ($null -eq $s.LastUpdateCheck) {
            $s | Add-Member LastUpdateCheck "" -Force
        }
        if ($null -eq $s.LastDate) { $s | Add-Member LastDate "" -Force }
        if ($null -eq $s.LastSlotFilter) { $s | Add-Member LastSlotFilter "" -Force }
        if ($null -eq $s.LastSelectedId) { $s | Add-Member LastSelectedId "" -Force }
        if ([string]::IsNullOrWhiteSpace([string]$s.LastWorkTab)) { $s | Add-Member LastWorkTab "Message" -Force }
        if ([string]::IsNullOrWhiteSpace([string]$s.LastStateFilter)) { $s | Add-Member LastStateFilter "Все" -Force }
        if ([string]::IsNullOrWhiteSpace([string]$s.LastAppPage)) { $s | Add-Member LastAppPage "Main" -Force }

        return $s
    } catch {
        return Get-DefaultSettings
    }
}

function Save-Settings($settings) {
    $settings | ConvertTo-Json | Set-Content $settingsFile -Encoding UTF8
}

$script:settings = Load-Settings

# ==================== First run / team setup ====================

function Normalize-MvlTag([string]$value) {
    $tag = ([string]$value).Trim()

    if ([string]::IsNullOrWhiteSpace($tag)) {
        return ""
    }

    if (-not $tag.StartsWith("@")) {
        $tag = "@$tag"
    }

    return $tag
}

function Test-FirstRunRequired {
    if ([bool]$script:settings.FirstRunCompleted) {
        return $false
    }

    # Existing installations are migrated silently if both values already exist.
    $existingKey = Load-ApiKey
    $existingMvl = Normalize-MvlTag ([string]$script:settings.MvlTag)

    if (-not [string]::IsNullOrWhiteSpace($existingKey) -and
        -not [string]::IsNullOrWhiteSpace($existingMvl)) {
        $script:plainKey = $existingKey
        $script:settings.MvlTag = $existingMvl
        $script:settings.FirstRunCompleted = $true
        Save-Settings $script:settings
        return $false
    }

    return $true
}

function Get-RuntimeStatusText {
    $phpOk = ($null -ne (Get-Command php.exe -ErrorAction SilentlyContinue))
    $vendorOk = Test-Path (Join-Path $base "vendor\autoload.php")

    if ($phpOk -and $vendorOk) {
        return "Среда KTalk: готова"
    }

    if (-not $phpOk -and -not $vendorOk) {
        return "Среда KTalk: не найдены PHP и vendor"
    }

    if (-not $phpOk) {
        return "Среда KTalk: не найден PHP"
    }

    return "Среда KTalk: не найден vendor"
}

function Show-FirstRunSetup {
    $d = New-Object System.Windows.Forms.Form
    $d.Text = "Первичная настройка"
    $d.StartPosition = "CenterScreen"
    $d.Size = New-Object System.Drawing.Size(520, 380)
    $d.FormBorderStyle = "FixedDialog"
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $d.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = "Первичная настройка"
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 18)
    $titleLabel.AutoSize = $true
    $titleLabel.Location = New-Object System.Drawing.Point(28, 24)
    $d.Controls.Add($titleLabel)

    $subLabel = New-Object System.Windows.Forms.Label
    $subLabel.Text = "Эти данные сохраняются только на этом компьютере."
    $subLabel.AutoSize = $true
    $subLabel.Location = New-Object System.Drawing.Point(30, 64)
    $d.Controls.Add($subLabel)

    $mvlLabel = New-Object System.Windows.Forms.Label
    $mvlLabel.Text = "Имя / МВЛ"
    $mvlLabel.AutoSize = $true
    $mvlLabel.Location = New-Object System.Drawing.Point(30, 108)
    $d.Controls.Add($mvlLabel)

    $mvlBox = New-Object System.Windows.Forms.TextBox
    $mvlBox.Location = New-Object System.Drawing.Point(30, 134)
    $mvlBox.Size = New-Object System.Drawing.Size(440, 30)
    $mvlBox.Text = [string]$script:settings.MvlTag
    $d.Controls.Add($mvlBox)

    $mvlHint = New-Object System.Windows.Forms.Label
    $mvlHint.Text = "Например: @nikita"
    $mvlHint.AutoSize = $true
    $mvlHint.Location = New-Object System.Drawing.Point(30, 168)
    $d.Controls.Add($mvlHint)

    $keyLabel = New-Object System.Windows.Forms.Label
    $keyLabel.Text = "KTalk API-ключ"
    $keyLabel.AutoSize = $true
    $keyLabel.Location = New-Object System.Drawing.Point(30, 202)
    $d.Controls.Add($keyLabel)

    $keyBox = New-Object System.Windows.Forms.TextBox
    $keyBox.Location = New-Object System.Drawing.Point(30, 228)
    $keyBox.Size = New-Object System.Drawing.Size(440, 30)
    $keyBox.UseSystemPasswordChar = $true
    $d.Controls.Add($keyBox)

    $runtimeLabel = New-Object System.Windows.Forms.Label
    $runtimeLabel.Text = Get-RuntimeStatusText
    $runtimeLabel.AutoSize = $true
    $runtimeLabel.Location = New-Object System.Drawing.Point(30, 270)
    $d.Controls.Add($runtimeLabel)

    $errorLabel = New-Object System.Windows.Forms.Label
    $errorLabel.Text = ""
    $errorLabel.AutoSize = $false
    $errorLabel.Location = New-Object System.Drawing.Point(30, 296)
    $errorLabel.Size = New-Object System.Drawing.Size(280, 28)
    $d.Controls.Add($errorLabel)

    $save = New-Object System.Windows.Forms.Button
    $save.Text = "Сохранить"
    $save.Location = New-Object System.Drawing.Point(338, 292)
    $save.Size = New-Object System.Drawing.Size(132, 40)
    $d.Controls.Add($save)

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $d.BackColor = $palette.Card
    $d.ForeColor = $palette.Text
    Set-NativeTitleBarTheme $d $dark

    $titleLabel.ForeColor = $palette.Text
    $subLabel.ForeColor = $palette.Muted
    $mvlLabel.ForeColor = $palette.Text
    $keyLabel.ForeColor = $palette.Text
    $mvlHint.ForeColor = $palette.Muted
    $runtimeLabel.ForeColor = $palette.Muted
    $errorLabel.ForeColor = $palette.Danger

    foreach ($box in @($mvlBox,$keyBox)) {
        $box.BackColor = $palette.Input
        $box.ForeColor = $palette.Text
        $box.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    }

    Set-FlatButtonStyle $save $palette
    $save.BackColor = $palette.Accent
    $save.ForeColor = [System.Drawing.Color]::White
    $save.FlatAppearance.BorderColor = $palette.Accent
    $save.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    $saved = $false

    $save.Add_Click({
        $tag = Normalize-MvlTag $mvlBox.Text
        $key = $keyBox.Text.Trim()

        if ([string]::IsNullOrWhiteSpace($tag)) {
            $errorLabel.Text = "Укажите имя / МВЛ."
            $mvlBox.Focus()
            return
        }

        if ([string]::IsNullOrWhiteSpace($key)) {
            $errorLabel.Text = "Введите KTalk API-ключ."
            $keyBox.Focus()
            return
        }

        try {
            Save-ApiKey $key
            $script:plainKey = $key
            $script:settings.MvlTag = $tag
            $script:settings.FirstRunCompleted = $true
            Save-Settings $script:settings

            $script:firstRunSaved = $true
            $d.DialogResult = [System.Windows.Forms.DialogResult]::OK
            $d.Close()
        } catch {
            $errorLabel.Text = "Не удалось сохранить настройки."
        }
    })

    $d.AcceptButton = $save

    $result = $d.ShowDialog()

    return (
        $result -eq [System.Windows.Forms.DialogResult]::OK -and
        [bool]$script:firstRunSaved
    )
}

# ==================== Updates ====================

function Get-UpdateChannelManifestUrl {
    $fromSettings = ([string]$script:settings.UpdateManifestUrl).Trim()
    if (-not [string]::IsNullOrWhiteSpace($fromSettings)) {
        return $fromSettings
    }

    if (-not (Test-Path $updateChannelFile)) {
        return ""
    }

    try {
        $channel = Get-Content $updateChannelFile -Raw -Encoding UTF8 | ConvertFrom-Json
        return ([string]$channel.ManifestUrl).Trim()
    } catch {
        return ""
    }
}

function Get-UpdateManifest([bool]$silent) {
    $url = Get-UpdateChannelManifestUrl

    if ([string]::IsNullOrWhiteSpace($url)) {
        if (-not $silent) {
            Show-Info "Канал обновлений пока не настроен.`r`n`r`nУкажите URL manifest.json в Настройки → Обновления."
        }
        return $null
    }

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        $response = Invoke-WebRequest -Uri $url -UseBasicParsing -TimeoutSec 8
        $manifest = $response.Content | ConvertFrom-Json

        if ([string]::IsNullOrWhiteSpace([string]$manifest.version) -or
            [string]::IsNullOrWhiteSpace([string]$manifest.url) -or
            [string]::IsNullOrWhiteSpace([string]$manifest.sha256)) {
            throw "manifest.json заполнен не полностью."
        }

        return $manifest
    } catch {
        if (-not $silent) {
            Show-Error ("Не удалось проверить обновления:`r`n" + $_.Exception.Message)
        }
        return $null
    }
}

function Show-UpdateAvailableDialog($manifest) {
    $d = New-Object System.Windows.Forms.Form
    $d.Text = "Обновление KTalk Creator"
    $d.StartPosition = "CenterParent"
    $d.Size = New-Object System.Drawing.Size(520, 320)
    $d.FormBorderStyle = "FixedDialog"
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $titleLabel = New-Object System.Windows.Forms.Label
    $titleLabel.Text = "Доступна версия $([string]$manifest.version)"
    $titleLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 16)
    $titleLabel.AutoSize = $true
    $titleLabel.Location = New-Object System.Drawing.Point(24, 22)
    $d.Controls.Add($titleLabel)

    $currentLabel = New-Object System.Windows.Forms.Label
    $currentLabel.Text = "Установлена: $($script:appVersion.ToString())"
    $currentLabel.AutoSize = $true
    $currentLabel.Location = New-Object System.Drawing.Point(26, 58)
    $d.Controls.Add($currentLabel)

    $notes = New-Object System.Windows.Forms.TextBox
    $notes.Multiline = $true
    $notes.ReadOnly = $true
    $notes.ScrollBars = "Vertical"
    $notes.Location = New-Object System.Drawing.Point(26, 88)
    $notes.Size = New-Object System.Drawing.Size(458, 116)
    $notes.Text = [string]$manifest.notes
    $d.Controls.Add($notes)

    $later = New-Object System.Windows.Forms.Button
    $later.Text = "Позже"
    $later.Location = New-Object System.Drawing.Point(246, 222)
    $later.Size = New-Object System.Drawing.Size(110, 38)
    $d.Controls.Add($later)

    $update = New-Object System.Windows.Forms.Button
    $update.Text = "Обновить"
    $update.Location = New-Object System.Drawing.Point(374, 222)
    $update.Size = New-Object System.Drawing.Size(110, 38)
    $d.Controls.Add($update)

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark
    $d.BackColor = $palette.Card
    $d.ForeColor = $palette.Text
    Set-NativeTitleBarTheme $d $dark

    $titleLabel.ForeColor = $palette.Text
    $currentLabel.ForeColor = $palette.Muted
    $notes.BackColor = $palette.Input
    $notes.ForeColor = $palette.Text

    foreach ($b in @($later,$update)) {
        Set-FlatButtonStyle $b $palette
    }

    $update.BackColor = $palette.Accent
    $update.ForeColor = [System.Drawing.Color]::White
    $update.FlatAppearance.BorderColor = $palette.Accent
    $update.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    $later.Add_Click({
        $d.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $d.Close()
    })

    $update.Add_Click({
        $d.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $d.Close()
    })

    return ($d.ShowDialog($form) -eq [System.Windows.Forms.DialogResult]::OK)
}

function Start-AppUpdate($manifest) {
    if (-not (Test-Path $updaterFile)) {
        Show-Error "Не найден модуль обновления KTalk_Updater.ps1."
        return
    }

    $versionText = ([string]$manifest.version).Trim()
    $packageUrl = ([string]$manifest.url).Trim()
    $expectedHash = ([string]$manifest.sha256).Trim().ToUpperInvariant()

    $tempRoot = Join-Path $env:TEMP "KTalkCreator"
    if (-not (Test-Path $tempRoot)) {
        New-Item -ItemType Directory -Path $tempRoot -Force | Out-Null
    }

    $packagePath = Join-Path $tempRoot ("KTalk_Update_{0}.zip" -f $versionText)

    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $packageUrl -OutFile $packagePath -UseBasicParsing -TimeoutSec 60

        $actualHash = (Get-FileHash $packagePath -Algorithm SHA256).Hash.ToUpperInvariant()
        if ($actualHash -ne $expectedHash) {
            Remove-Item $packagePath -Force -ErrorAction SilentlyContinue
            throw "SHA-256 не совпал. Обновление отменено."
        }

        Start-Process "powershell.exe" -ArgumentList @(
            "-NoProfile",
            "-ExecutionPolicy", "Bypass",
            "-File", "`"$updaterFile`"",
            "-PackagePath", "`"$packagePath`"",
            "-ExpectedVersion", "`"$versionText`"",
            "-ParentPid", "$PID"
        )

        Save-UiState
        $script:exitRequested = $true
        $form.Close()
    } catch {
        Show-Error ("Не удалось установить обновление:`r`n" + $_.Exception.Message)
    }
}

function Check-ForUpdates([bool]$silent = $false) {
    $manifest = Get-UpdateManifest $silent
    if ($null -eq $manifest) {
        return
    }

    try {
        $remoteVersion = [version]([string]$manifest.version)
    } catch {
        if (-not $silent) {
            Show-Error "В manifest.json указана некорректная версия."
        }
        return
    }

    $script:settings.LastUpdateCheck = (Get-Date).ToString("s")
    Save-Settings $script:settings

    if ($remoteVersion -le $script:appVersion) {
        if (-not $silent) {
            Show-Info "У вас уже установлена последняя версия: $($script:appVersion.ToString())."
        }
        return
    }

    if (Show-UpdateAvailableDialog $manifest) {
        Start-AppUpdate $manifest
    }
}

# ==================== Stable unique room links ====================

function New-RoomName {
    $chars = "abcdefghijklmnopqrstuvwxyz0123456789"
    $bytes = New-Object byte[] 14

    $rng = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $rng.GetBytes($bytes)
    } finally {
        $rng.Dispose()
    }

    $result = New-Object System.Text.StringBuilder
    foreach ($b in $bytes) {
        [void]$result.Append($chars[$b % $chars.Length])
    }

    return $result.ToString()
}

function Load-RoomMap {
    if (Test-Path $roomMapFile) {
        try {
            $script:roomMap = @(Import-Csv $roomMapFile -Delimiter ';' -Encoding UTF8)
        } catch {
            $script:roomMap = @()
        }
    } else {
        $script:roomMap = @()
    }
}

function Find-RoomMapById([string]$id) {
    if ([string]::IsNullOrWhiteSpace($id)) {
        return $null
    }

    return $script:roomMap |
        Where-Object { $_.ID -eq $id } |
        Select-Object -Last 1
}

function Save-RoomMap([string]$id, [string]$roomName, [string]$url) {
    if ([string]::IsNullOrWhiteSpace($id) -or
        [string]::IsNullOrWhiteSpace($roomName) -or
        [string]::IsNullOrWhiteSpace($url)) {
        return
    }

    $existing = Find-RoomMapById $id
    if ($null -ne $existing) {
        return
    }

    $record = [pscustomobject]@{
        ID = $id
        RoomName = $roomName
        URL = $url
        CreatedAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm:ss")
    }

    $script:roomMap += $record

    if (Test-Path $roomMapFile) {
        $record | Export-Csv $roomMapFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation -Append
    } else {
        $record | Export-Csv $roomMapFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation
    }
}

function Resolve-RoomIdentity([string]$id) {
    $mapped = Find-RoomMapById $id

    if ($null -ne $mapped) {
        return [pscustomobject]@{
            RoomName = [string]$mapped.RoomName
            URL = [string]$mapped.URL
            IsExisting = $true
        }
    }

    $roomName = New-RoomName

    return [pscustomobject]@{
        RoomName = $roomName
        URL = "https://oooparta.ktalk.ru/$roomName"
        IsExisting = $false
    }
}

Load-RoomMap

# ==================== Daily archive ====================

function Convert-ToHistoryRecord($record, [bool]$isArchived = $false) {
    return [pscustomobject]@{
        CreatedAt = [string]$record.CreatedAt
        ConsultationDate = [string]$record.ConsultationDate
        Slot = [string]$record.Slot
        End = [string]$record.End
        ID = [string]$record.ID
        URL = [string]$record.URL
        Status = [string]$record.Status
        ConfirmationStatus = $(if ($record.PSObject.Properties.Name -contains "ConfirmationStatus") { [string]$record.ConfirmationStatus } else { "" })
        ConfirmedAt = $(if ($record.PSObject.Properties.Name -contains "ConfirmedAt") { [string]$record.ConfirmedAt } else { "" })
        Methodist = $(if ($record.PSObject.Properties.Name -contains "Methodist") { [string]$record.Methodist } else { "" })
        TelegramTag = $(if ($record.PSObject.Properties.Name -contains "TelegramTag") { [string]$record.TelegramTag } else { "" })
        HandoffStatus = $(if ($record.PSObject.Properties.Name -contains "HandoffStatus") { [string]$record.HandoffStatus } else { "" })
        HandoffAt = $(if ($record.PSObject.Properties.Name -contains "HandoffAt") { [string]$record.HandoffAt } else { "" })
        DecisionStatus = $(if ($record.PSObject.Properties.Name -contains "DecisionStatus") { [string]$record.DecisionStatus } else { "" })
        DecisionTag = $(if ($record.PSObject.Properties.Name -contains "DecisionTag") { [string]$record.DecisionTag } else { "" })
        DecisionAt = $(if ($record.PSObject.Properties.Name -contains "DecisionAt") { [string]$record.DecisionAt } else { "" })
        ClientPhone = $(if ($record.PSObject.Properties.Name -contains "ClientPhone") { [string]$record.ClientPhone } else { "" })
        ParentName = $(if ($record.PSObject.Properties.Name -contains "ParentName") { [string]$record.ParentName } else { "" })
        StudentName = $(if ($record.PSObject.Properties.Name -contains "StudentName") { [string]$record.StudentName } else { "" })
        ChildClass = $(if ($record.PSObject.Properties.Name -contains "ChildClass") { [string]$record.ChildClass } else { "" })
        LeadSource = $(if ($record.PSObject.Properties.Name -contains "LeadSource") { [string]$record.LeadSource } else { "" })
        CallCount = $(if ($record.PSObject.Properties.Name -contains "CallCount") { [int]$record.CallCount } else { 0 })
        CallTimes = $(if ($record.PSObject.Properties.Name -contains "CallTimes") { [string]$record.CallTimes } else { "" })
        IsArchived = $isArchived
    }
}

function Get-ArchiveFilePath([string]$dateText) {
    if ([string]::IsNullOrWhiteSpace($dateText)) {
        return $null
    }

    return (Join-Path $archiveDir "$dateText.csv")
}

function Save-ArchiveDay([string]$dateText, $records) {
    $file = Get-ArchiveFilePath $dateText
    if ([string]::IsNullOrWhiteSpace($file)) {
        return
    }

    $all = @()

    if (Test-Path $file) {
        try {
            $all += @(Import-Csv $file -Delimiter ';' -Encoding UTF8)
        } catch {}
    }

    $all += @($records)

    $latestById = @{}
    foreach ($record in $all) {
        if ($null -eq $record) { continue }
        $latestById[[string]$record.ID] = $record
    }

    $export = @(
        $latestById.Values |
        ForEach-Object {
            Convert-ToHistoryRecord $_ $false
        } |
        Select-Object CreatedAt,ConsultationDate,Slot,End,ID,URL,Status,
                      ConfirmationStatus,ConfirmedAt,Methodist,TelegramTag,
                      HandoffStatus,HandoffAt,DecisionStatus,DecisionTag,DecisionAt,
                      ClientPhone,ParentName,StudentName,ChildClass,LeadSource,
                      CallCount,CallTimes
    )

    if ($export.Count -gt 0) {
        $export |
            Sort-Object Slot, ID |
            Export-Csv $file -Delimiter ';' -Encoding UTF8 -NoTypeInformation
    }
}

function Load-ArchiveHistory {
    $script:archiveHistory = @()

    if (-not (Test-Path $archiveDir)) {
        return
    }

    foreach ($file in @(Get-ChildItem $archiveDir -Filter "*.csv" -File -ErrorAction SilentlyContinue)) {
        try {
            foreach ($record in @(Import-Csv $file.FullName -Delimiter ';' -Encoding UTF8)) {
                $script:archiveHistory += (Convert-ToHistoryRecord $record $true)
            }
        } catch {}
    }
}

function Archive-PastHistory {
    if ($script:history.Count -eq 0) {
        Load-ArchiveHistory
        return $false
    }

    $today = (Get-MoscowNow).Date
    $toArchive = @()
    $keep = @()

    foreach ($record in $script:history) {
        $recordDate = $null

        try {
            $recordDate = [DateTime]::ParseExact(
                [string]$record.ConsultationDate,
                "dd.MM.yyyy",
                $culture
            ).Date
        } catch {}

        if ($null -ne $recordDate -and $recordDate -lt $today) {
            $toArchive += $record
        } else {
            $keep += $record
        }
    }

    if ($toArchive.Count -eq 0) {
        Load-ArchiveHistory
        return $false
    }

    foreach ($group in ($toArchive | Group-Object ConsultationDate)) {
        Save-ArchiveDay ([string]$group.Name) @($group.Group)
    }

    $script:history = @($keep)
    Save-CurrentHistory
    Load-ArchiveHistory

    return $true
}

function Is-ArchivedRecord($record) {
    if ($null -eq $record) {
        return $false
    }

    return (
        $record.PSObject.Properties.Name -contains "IsArchived" -and
        [bool]$record.IsArchived
    )
}

# ==================== History ====================

function Save-CurrentHistory {
    if ($script:history.Count -eq 0) {
        if (Test-Path $historyFile) {
            Remove-Item $historyFile -Force -ErrorAction SilentlyContinue
        }
        return
    }

    $script:history |
        Sort-Object CreatedAt |
        Export-Csv $historyFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation
}

$script:auditCache = $null

function Get-AuditHistory {
    if ($null -ne $script:auditCache) {
        return @($script:auditCache)
    }

    if (-not (Test-Path $historyAuditFile)) {
        $script:auditCache = @()
        return @()
    }

    try {
        $script:auditCache = @(Import-Csv $historyAuditFile -Delimiter ';' -Encoding UTF8)
    } catch {
        $script:auditCache = @()
    }

    return @($script:auditCache)
}

function Append-AuditRecord($auditRecord) {
    if ($null -eq $auditRecord) {
        return
    }

    if (Test-Path $historyAuditFile) {
        $auditRecord |
            Export-Csv $historyAuditFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation -Append
    } else {
        $auditRecord |
            Export-Csv $historyAuditFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation
    }

    if ($null -eq $script:auditCache) {
        $script:auditCache = @()
    }

    $script:auditCache += $auditRecord
}

function Load-History {
    if (-not (Test-Path $historyFile)) {
        $script:history = @()
        return
    }

    try {
        $loaded = @(Import-Csv $historyFile -Delimiter ';' -Encoding UTF8)

        # v6.4: history.csv — это ТЕКУЩЕЕ состояние сделок.
        # Если файл пришёл из старой версии и в нём есть один ID несколько раз,
        # оставляем только самую последнюю запись этого ID.
        #
        # Перед миграцией сохраняем старый файл в append-only аудит,
        # чтобы информация о прежних слотах не потерялась полностью.
        if ($loaded.Count -gt 0 -and -not (Test-Path $historyAuditFile)) {
            $loaded |
                Export-Csv $historyAuditFile -Delimiter ';' -Encoding UTF8 -NoTypeInformation
            $script:auditCache = @($loaded)
        }

        $latestById = @{}

        foreach ($record in $loaded) {
            $latestById[[string]$record.ID] = $record
        }

        $script:history = @($latestById.Values)

        # Нормализуем текущую рабочую историю.
        $normalized = @()
        foreach ($record in $script:history) {
            $normalized += (Convert-ToHistoryRecord $record $false)
        }

        $script:history = @($normalized)

        if ($script:history.Count -ne $loaded.Count -or
            ($loaded.Count -gt 0 -and -not ($loaded[0].PSObject.Properties.Name -contains "ConfirmationStatus")) -or
            ($loaded.Count -gt 0 -and -not ($loaded[0].PSObject.Properties.Name -contains "DecisionStatus")) -or
            ($loaded.Count -gt 0 -and -not ($loaded[0].PSObject.Properties.Name -contains "ClientPhone")) -or
            ($loaded.Count -gt 0 -and -not ($loaded[0].PSObject.Properties.Name -contains "CallCount"))) {
            Save-CurrentHistory
        }

    } catch {
        $script:history = @()
    }
}

function Add-HistoryRecord(
    [string]$consultDate,
    [string]$time,
    [string]$id,
    [string]$url,
    [string]$status
) {
    $existing = $script:history |
        Where-Object { [string]$_.ID -eq [string]$id } |
        Select-Object -Last 1

    $confirmationStatus = ""
    $confirmedAt = ""
    $methodist = ""
    $telegramTag = ""
    $handoffStatus = ""
    $handoffAt = ""
    $decisionStatus = ""
    $decisionTag = ""
    $decisionAt = ""
    $clientPhone = ""
    $parentName = ""
    $studentName = ""
    $childClass = ""
    $leadSource = ""
    $callCount = 0
    $callTimes = ""

    if ($null -ne $existing) {
        $confirmationStatus = [string]$existing.ConfirmationStatus
        $confirmedAt = [string]$existing.ConfirmedAt
        $methodist = [string]$existing.Methodist
        $telegramTag = [string]$existing.TelegramTag
        $clientPhone = [string]$existing.ClientPhone
        $parentName = [string]$existing.ParentName
        $studentName = [string]$existing.StudentName
        $childClass = [string]$existing.ChildClass
        $leadSource = [string]$existing.LeadSource

        if ([string]$existing.ConsultationDate -eq [string]$consultDate -and
            [string]$existing.Slot -eq [string]$time) {
            $decisionStatus = [string]$existing.DecisionStatus
            $decisionTag = [string]$existing.DecisionTag
            $decisionAt = [string]$existing.DecisionAt
            $callCount = [int]$existing.CallCount
            $callTimes = [string]$existing.CallTimes
        }

        # При изменении даты/времени прежняя отметка "Передано" больше не считается актуальной.
        # Подтверждение сохраняем, но передачу методисту нужно выполнить заново.
        $handoffStatus = ""
        $handoffAt = ""
    }

    $record = [pscustomobject]@{
        CreatedAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm:ss")
        ConsultationDate = $consultDate
        Slot = $time
        End = (Get-EndTime $time)
        ID = $id
        URL = $url
        Status = $status
        ConfirmationStatus = $confirmationStatus
        ConfirmedAt = $confirmedAt
        Methodist = $methodist
        TelegramTag = $telegramTag
        HandoffStatus = $handoffStatus
        HandoffAt = $handoffAt
        DecisionStatus = $decisionStatus
        DecisionTag = $decisionTag
        DecisionAt = $decisionAt
        ClientPhone = $clientPhone
        ParentName = $parentName
        StudentName = $studentName
        ChildClass = $childClass
        LeadSource = $leadSource
        CallCount = $callCount
        CallTimes = $callTimes
        IsArchived = $false
    }

    # Аудит оставляем совместимым со старым форматом.
    $auditRecord = [pscustomobject]@{
        CreatedAt = $record.CreatedAt
        ConsultationDate = $record.ConsultationDate
        Slot = $record.Slot
        End = $record.End
        ID = $record.ID
        URL = $record.URL
        Status = $record.Status
    }

    Append-AuditRecord $auditRecord

    $script:history = @(
        $script:history |
        Where-Object { [string]$_.ID -ne [string]$id }
    )

    $script:history += $record
    Save-CurrentHistory
}

function Find-LatestHistoryById([string]$id) {
    if ([string]::IsNullOrWhiteSpace($id)) {
        return $null
    }

    foreach ($record in $script:history) {
        if ([string]$record.ID -eq [string]$id) {
            return $record
        }
    }

    return $null
}

Load-History
[void](Archive-PastHistory)
Load-ArchiveHistory

# ==================== Form ====================

$form = New-Object System.Windows.Forms.Form
$form.Text = $appWindowTitle
$form.StartPosition = "CenterScreen"
$form.Size = New-Object System.Drawing.Size(1260, 760)
$form.MinimumSize = New-Object System.Drawing.Size(1260, 760)
$form.MaximumSize = New-Object System.Drawing.Size(1260, 760)
$form.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$form.FormBorderStyle = "FixedSingle"
$form.MaximizeBox = $false
$form.AutoScroll = $false
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
$form.KeyPreview = $true

$title = New-Object System.Windows.Forms.Label
$title.Text = "KTalk Creator"
$title.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 20)
$title.AutoSize = $true
$title.Location = New-Object System.Drawing.Point(25, 18)
$form.Controls.Add($title)

$versionLabel = New-Object System.Windows.Forms.Label
$versionLabel.Text = "v9.14"
$versionLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$versionLabel.AutoSize = $true
$form.Controls.Add($versionLabel)

# ----- Mode / API / Theme -----

$apiStatus = New-Object System.Windows.Forms.Label
$apiStatus.Text = "API • проверка..."
$apiStatus.AutoSize = $true
$apiStatus.Location = New-Object System.Drawing.Point(455, 78)
$form.Controls.Add($apiStatus)

$refreshApi = New-Object System.Windows.Forms.Button
$refreshApi.Text = "↻"
$refreshApi.Location = New-Object System.Drawing.Point(625, 69)
$refreshApi.Size = New-Object System.Drawing.Size(40, 32)
$form.Controls.Add($refreshApi)

$themeLabel = New-Object System.Windows.Forms.Label
$themeLabel.Text = "Тема:"
$themeLabel.AutoSize = $true
$themeLabel.Location = New-Object System.Drawing.Point(720, 78)
$form.Controls.Add($themeLabel)

$lightButton = New-Object System.Windows.Forms.Button
$lightButton.Text = "Светлая"
$lightButton.Location = New-Object System.Drawing.Point(770, 68)
$lightButton.Size = New-Object System.Drawing.Size(105, 36)
$form.Controls.Add($lightButton)

$darkButton = New-Object System.Windows.Forms.Button
$darkButton.Text = "Тёмная"
$darkButton.Location = New-Object System.Drawing.Point(885, 68)
$darkButton.Size = New-Object System.Drawing.Size(105, 36)
$form.Controls.Add($darkButton)

$settingsButton = New-Object System.Windows.Forms.Button
$settingsButton.Text = "⚙"
$settingsButton.Location = New-Object System.Drawing.Point(1000, 68)
$settingsButton.Size = New-Object System.Drawing.Size(50, 36)
$form.Controls.Add($settingsButton)

# Старые элементы теперь настраиваются только через "Настройки".
$apiStatus.Visible = $false
$refreshApi.Visible = $false
$themeLabel.Visible = $false
$lightButton.Visible = $false
$darkButton.Visible = $false

# ----- Date -----

$dateTitle = New-Object System.Windows.Forms.Label
$dateTitle.Text = "Дата консультации"
$dateTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$dateTitle.AutoSize = $true
$dateTitle.Location = New-Object System.Drawing.Point(30, 128)
$form.Controls.Add($dateTitle)

$todayButton = New-Object System.Windows.Forms.Button
$todayButton.Text = "Сегодня"
$todayButton.Location = New-Object System.Drawing.Point(30, 156)
$todayButton.Size = New-Object System.Drawing.Size(110, 36)
$form.Controls.Add($todayButton)

$tomorrowButton = New-Object System.Windows.Forms.Button
$tomorrowButton.Text = "Завтра"
$tomorrowButton.Location = New-Object System.Drawing.Point(150, 156)
$tomorrowButton.Size = New-Object System.Drawing.Size(110, 36)
$form.Controls.Add($tomorrowButton)

$otherDateButton = New-Object System.Windows.Forms.Button
$otherDateButton.Text = "Другая дата"
$otherDateButton.Location = New-Object System.Drawing.Point(270, 156)
$otherDateButton.Size = New-Object System.Drawing.Size(120, 36)
$otherDateButton.Visible = $false

$datePicker = New-Object System.Windows.Forms.DateTimePicker
$datePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
$datePicker.CustomFormat = "dd.MM.yyyy"
$datePicker.Location = New-Object System.Drawing.Point(405, 159)
$datePicker.Size = New-Object System.Drawing.Size(150, 30)
$datePicker.Value = (Get-MoscowNow).Date
$form.Controls.Add($datePicker)

# ----- Standard slots -----

$slotTitle = New-Object System.Windows.Forms.Label
$slotTitle.Text = "Стандартные слоты"
$slotTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$slotTitle.AutoSize = $true
$slotTitle.Location = New-Object System.Drawing.Point(30, 215)
$form.Controls.Add($slotTitle)

$slotButtons = @()

for ($i = 0; $i -lt $standardSlots.Count; $i++) {
    $slot = $standardSlots[$i]

    $btn = New-Object System.Windows.Forms.Button
    $btn.Tag = $slot
    $btn.Size = New-Object System.Drawing.Size(245, 48)

    $col = $i % 4
    $row = [math]::Floor($i / 4)

    $btn.Location = New-Object System.Drawing.Point(
        (30 + $col * 265),
        (245 + $row * 56)
    )

    $btn.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $slotButtons += $btn
    $form.Controls.Add($btn)
}

# ----- Custom time -----

$customTitle = New-Object System.Windows.Forms.Label
$customTitle.Text = "Нестандартное время"
$customTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$customTitle.AutoSize = $true
$customTitle.Location = New-Object System.Drawing.Point(30, 365)
$form.Controls.Add($customTitle)

$customButton = New-Object System.Windows.Forms.Button
$customButton.Text = "Другое время"
$customButton.Location = New-Object System.Drawing.Point(30, 394)
$customButton.Size = New-Object System.Drawing.Size(130, 36)
$form.Controls.Add($customButton)

$customTimePicker = New-Object System.Windows.Forms.DateTimePicker
$customTimePicker.Format = [System.Windows.Forms.DateTimePickerFormat]::Custom
$customTimePicker.CustomFormat = "HH:mm"
$customTimePicker.ShowUpDown = $true
$customTimePicker.Location = New-Object System.Drawing.Point(175, 397)
$customTimePicker.Size = New-Object System.Drawing.Size(90, 30)
$customTimePicker.Enabled = $false
$form.Controls.Add($customTimePicker)

$minus30 = New-Object System.Windows.Forms.Button
$minus30.Text = "-30"
$minus30.Location = New-Object System.Drawing.Point(280, 394)
$minus30.Size = New-Object System.Drawing.Size(62, 36)
$form.Controls.Add($minus30)

$minus15 = New-Object System.Windows.Forms.Button
$minus15.Text = "-15"
$minus15.Location = New-Object System.Drawing.Point(350, 394)
$minus15.Size = New-Object System.Drawing.Size(62, 36)
$form.Controls.Add($minus15)

$plus15 = New-Object System.Windows.Forms.Button
$plus15.Text = "+15"
$plus15.Location = New-Object System.Drawing.Point(420, 394)
$plus15.Size = New-Object System.Drawing.Size(62, 36)
$form.Controls.Add($plus15)

$plus30 = New-Object System.Windows.Forms.Button
$plus30.Text = "+30"
$plus30.Location = New-Object System.Drawing.Point(490, 394)
$plus30.Size = New-Object System.Drawing.Size(62, 36)
$form.Controls.Add($plus30)

$customInfo = New-Object System.Windows.Forms.Label
$customInfo.Text = ""
$customInfo.AutoSize = $false
$customInfo.Size = New-Object System.Drawing.Size(500, 42)
$customInfo.Location = New-Object System.Drawing.Point(575, 394)
$form.Controls.Add($customInfo)

# ----- ID -----

$idTitle = New-Object System.Windows.Forms.Label
$idTitle.Text = "ID сделки"
$idTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$idTitle.AutoSize = $true
$idTitle.Location = New-Object System.Drawing.Point(30, 455)
$form.Controls.Add($idTitle)

$idBox = New-Object System.Windows.Forms.TextBox
$idBox.Location = New-Object System.Drawing.Point(30, 484)
$idBox.Size = New-Object System.Drawing.Size(310, 30)
$idBox.Enabled = $false
$form.Controls.Add($idBox)

# История ID вынесена на отдельную строку, чтобы текст не залезал на другие элементы.
$idHistoryLabel = New-Object System.Windows.Forms.Label
$idHistoryLabel.Text = ""
$idHistoryLabel.AutoSize = $false
$idHistoryLabel.Size = New-Object System.Drawing.Size(1030, 28)
$idHistoryLabel.Location = New-Object System.Drawing.Point(30, 519)
$form.Controls.Add($idHistoryLabel)

# ----- Preview -----

$previewTitle = New-Object System.Windows.Forms.Label
$previewTitle.Text = "Предпросмотр"
$previewTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$previewTitle.AutoSize = $true
$previewTitle.Location = New-Object System.Drawing.Point(30, 532)
$form.Controls.Add($previewTitle)

$previewBox = New-Object System.Windows.Forms.TextBox
$previewBox.Location = New-Object System.Drawing.Point(30, 560)
$previewBox.Size = New-Object System.Drawing.Size(640, 120)
$previewBox.Multiline = $true
$previewBox.ReadOnly = $true
$form.Controls.Add($previewBox)

$createButton = New-Object System.Windows.Forms.Button
$createButton.Text = "СОЗДАТЬ КОМНАТУ"
$createButton.Location = New-Object System.Drawing.Point(690, 532)
$createButton.Size = New-Object System.Drawing.Size(520, 48)
$createButton.Enabled = $true
$form.Controls.Add($createButton)

# ----- Message -----

$messageTitle = New-Object System.Windows.Forms.Label
$messageTitle.Text = "Готовое сообщение"
$messageTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)
$messageTitle.AutoSize = $true
$messageTitle.Location = New-Object System.Drawing.Point(690, 590)
$form.Controls.Add($messageTitle)

$messageBox = New-Object System.Windows.Forms.Label
$messageBox.Location = New-Object System.Drawing.Point(690, 620)
$messageBox.Size = New-Object System.Drawing.Size(500, 100)
$messageBox.AutoSize = $false
$messageBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$messageBox.Padding = New-Object System.Windows.Forms.Padding(10)
$messageBox.TextAlign = [System.Drawing.ContentAlignment]::TopLeft
$form.Controls.Add($messageBox)

$copyMessageButton = New-Object System.Windows.Forms.Button
$copyMessageButton.Text = "Копировать сообщение"
$copyMessageButton.Location = New-Object System.Drawing.Point(690, 730)
$copyMessageButton.Size = New-Object System.Drawing.Size(170, 36)
$copyMessageButton.Enabled = $true
$form.Controls.Add($copyMessageButton)

$copyLinkButton = New-Object System.Windows.Forms.Button
$copyLinkButton.Text = "Копировать ссылку"
$copyLinkButton.Location = New-Object System.Drawing.Point(860, 730)
$copyLinkButton.Size = New-Object System.Drawing.Size(165, 36)
$copyLinkButton.Enabled = $true
$form.Controls.Add($copyLinkButton)

$openButton = New-Object System.Windows.Forms.Button
$openButton.Text = "KTalk"
$openButton.Location = New-Object System.Drawing.Point(1025, 730)
$openButton.Size = New-Object System.Drawing.Size(190, 36)
$openButton.Enabled = $true
$form.Controls.Add($openButton)

# ----- History -----

$historyTitle = New-Object System.Windows.Forms.Label
$historyTitle.Text = "Актуальные сделки"
$historyTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$historyTitle.AutoSize = $true
$historyTitle.Location = New-Object System.Drawing.Point(30, 700)
$form.Controls.Add($historyTitle)

$customCountLabel = New-Object System.Windows.Forms.Label
$customCountLabel.Text = "Нестандартные: 0"
$customCountLabel.AutoSize = $true
$customCountLabel.Location = New-Object System.Drawing.Point(175, 703)
$form.Controls.Add($customCountLabel)

$totalCountLabel = New-Object System.Windows.Forms.Label
$totalCountLabel.Text = "Всего на дату: 0"
$totalCountLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$totalCountLabel.AutoSize = $true
$totalCountLabel.Location = New-Object System.Drawing.Point(340, 703)
$form.Controls.Add($totalCountLabel)

$historySearch = New-Object System.Windows.Forms.TextBox
$historySearch.Location = New-Object System.Drawing.Point(30, 730)
$historySearch.Size = New-Object System.Drawing.Size(210, 30)
$form.Controls.Add($historySearch)

$historySearchHint = New-Object System.Windows.Forms.Label
$historySearchHint.Text = "Поиск по ID..."
$historySearchHint.AutoSize = $false
$historySearchHint.Location = New-Object System.Drawing.Point(250, 735)
$form.Controls.Add($historySearchHint)

$exportButton = New-Object System.Windows.Forms.Button
$exportButton.Text = "Экспорт CSV"
$exportButton.Location = New-Object System.Drawing.Point(350, 728)
$exportButton.Size = New-Object System.Drawing.Size(95, 34)
$form.Controls.Add($exportButton)

$deleteHistoryButton = New-Object System.Windows.Forms.Button
$deleteHistoryButton.Text = "Удалить"
$deleteHistoryButton.Location = New-Object System.Drawing.Point(450, 728)
$deleteHistoryButton.Size = New-Object System.Drawing.Size(90, 34)
$deleteHistoryButton.Enabled = $true
$form.Controls.Add($deleteHistoryButton)

# Надёжная inline-панель Undo.
# ContextMenuStrip в v9.6 мог закрыться сразу после Refresh/Focus,
# поэтому теперь Undo живёт прямо в карточке истории.
$undoDeletePanel = New-Object System.Windows.Forms.Panel
$undoDeletePanel.Visible = $false
$undoDeletePanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None

$undoDeleteInfo = New-Object System.Windows.Forms.Label
$undoDeleteInfo.Text = "Сделка удалена"
$undoDeleteInfo.AutoSize = $false
$undoDeleteInfo.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$undoDeletePanel.Controls.Add($undoDeleteInfo)

$undoDeleteAction = New-Object System.Windows.Forms.Button
$undoDeleteAction.Text = "Отменить"
$undoDeletePanel.Controls.Add($undoDeleteAction)

$undoDeleteTimer = New-Object System.Windows.Forms.Timer
$undoDeleteTimer.Interval = 5000

$historyGrid = New-Object System.Windows.Forms.DataGridView
$historyGrid.Location = New-Object System.Drawing.Point(30, 770)
$historyGrid.Size = New-Object System.Drawing.Size(640, 165)
$historyGrid.ReadOnly = $true
$historyGrid.AllowUserToAddRows = $false
$historyGrid.AllowUserToDeleteRows = $false
$historyGrid.MultiSelect = $false
$historyGrid.SelectionMode = "FullRowSelect"
$historyGrid.RowHeadersVisible = $false
$historyGrid.AutoSizeColumnsMode = "Fill"
$form.Controls.Add($historyGrid)

[void]$historyGrid.Columns.Add("CreatedAt", "Изменено")
[void]$historyGrid.Columns.Add("ConsultationDate", "Дата")
[void]$historyGrid.Columns.Add("Slot", "Время")
[void]$historyGrid.Columns.Add("ID", "ID")
[void]$historyGrid.Columns.Add("Confirmation", "Подтв.")
[void]$historyGrid.Columns.Add("Handoff", "Передача")
[void]$historyGrid.Columns.Add("Status", "Статус")

$historyGrid.AutoSizeColumnsMode = "None"
$historyGrid.Columns["CreatedAt"].Width = 105
$historyGrid.Columns["ConsultationDate"].Width = 78
$historyGrid.Columns["Slot"].Width = 58
$historyGrid.Columns["ID"].Width = 86
$historyGrid.Columns["Confirmation"].Width = 58
$historyGrid.Columns["Handoff"].Width = 125
$historyGrid.Columns["Status"].Width = 95


$historyContextMenu = New-Object System.Windows.Forms.ContextMenuStrip
$ctxConfirm = $historyContextMenu.Items.Add("Подтвердить / снять подтверждение")
$ctxReassign = $historyContextMenu.Items.Add("Переназначить")
$ctxRefuse = $historyContextMenu.Items.Add("Отказ")
$ctxHandoffDone = $historyContextMenu.Items.Add("Передано методисту")
$historyContextMenu.Items.Add("-") | Out-Null
$ctxCopySms = $historyContextMenu.Items.Add("Копировать SMS")
$ctxCopyLink = $historyContextMenu.Items.Add("Копировать ссылку")
$ctxOpen = $historyContextMenu.Items.Add("Открыть KTalk")
$ctxCopySheets = $historyContextMenu.Items.Add("Копировать для таблицы")
$historyContextMenu.Items.Add("-") | Out-Null
$ctxDelete = $historyContextMenu.Items.Add("Удалить сделку")
$historyGrid.ContextMenuStrip = $historyContextMenu

$historyContextMenu.Add_Opening({
    $record=$null;if($historyGrid.SelectedRows.Count -gt 0){$record=$historyGrid.SelectedRows[0].Tag}
    $has=($null -ne $record);$archived=$(if($has){Is-ArchivedRecord $record}else{$false});$confirmed=$(if($has){[string]$record.ConfirmationStatus -eq "Подтверждено"}else{$false});$decision=$(if($has){-not [string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)}else{$false})
    $ctxConfirm.Enabled=($has -and -not $archived -and -not $decision);$ctxReassign.Enabled=($has -and -not $archived -and -not $confirmed);$ctxRefuse.Enabled=$ctxReassign.Enabled;$ctxHandoffDone.Enabled=($has -and -not $archived -and $confirmed -and -not $decision)
    $ctxCopySms.Enabled=$has;$ctxCopyLink.Enabled=($has -and -not [string]::IsNullOrWhiteSpace([string]$record.URL));$ctxOpen.Enabled=$ctxCopyLink.Enabled;$ctxCopySheets.Enabled=($has -and -not $archived -and $confirmed);$ctxDelete.Enabled=($has -and -not $archived)
})

$historyGrid.Add_CellMouseDown({
    if ($_.Button -eq [System.Windows.Forms.MouseButtons]::Right -and $_.RowIndex -ge 0) {
        $historyGrid.ClearSelection()
        $historyGrid.Rows[$_.RowIndex].Selected = $true
        $historyGrid.CurrentCell = $historyGrid.Rows[$_.RowIndex].Cells[0]
        $rightClickRecord=$historyGrid.Rows[$_.RowIndex].Tag
        if($null -ne $rightClickRecord){Activate-HistoryRecord $rightClickRecord}
    }
})

$ctxConfirm.Add_Click({Toggle-Confirmation})
$ctxReassign.Add_Click({Set-PreConfirmDecision "ПЕРЕНАЗНАЧИТЬ"})
$ctxRefuse.Add_Click({Set-PreConfirmDecision "ОТКАЗ ОТ ДИАГНОСТИКИ"})

$ctxCopySheets.Add_Click({
    Copy-ForGoogle
})

$ctxHandoffDone.Add_Click({
    Mark-HandoffDone
})

$ctxCopySms.Add_Click({
    if ($historyGrid.SelectedRows.Count -gt 0) {
        $record = $historyGrid.SelectedRows[0].Tag
        if ($null -ne $record) {
            Set-Clipboard -Value (Build-Message $record.ConsultationDate $record.Slot $record.URL)
            Notify-Success "SMS сделки $($record.ID) скопировано"
        }
    }
})

$ctxCopyLink.Add_Click({
    if ($historyGrid.SelectedRows.Count -gt 0) {
        $record = $historyGrid.SelectedRows[0].Tag
        if ($null -ne $record) { Set-Clipboard -Value $record.URL; Notify-Success "Ссылка сделки $($record.ID) скопирована" }
    }
})
$ctxOpen.Add_Click({if($historyGrid.SelectedRows.Count -gt 0){$record=$historyGrid.SelectedRows[0].Tag;if($null -ne $record -and -not [string]::IsNullOrWhiteSpace([string]$record.URL)){Start-Process ([string]$record.URL)}}})

$ctxDelete.Add_Click({
    Delete-SelectedHistoryRecord
})


# ----- Правая рабочая область -----

$workTabs = New-Object System.Windows.Forms.TabControl
$workTabs.Location = New-Object System.Drawing.Point(690, 590)
$workTabs.Size = New-Object System.Drawing.Size(520, 345)
$form.Controls.Add($workTabs)

$messageTab = New-Object System.Windows.Forms.TabPage
$messageTab.Text = "Сообщение"
$workTabs.TabPages.Add($messageTab)

$handoffTab = New-Object System.Windows.Forms.TabPage
$handoffTab.Text = "Передача"
$workTabs.TabPages.Add($handoffTab)

$googleTab = New-Object System.Windows.Forms.TabPage
$googleTab.Text = "Таблица"
$workTabs.TabPages.Add($googleTab)

$historyTab = New-Object System.Windows.Forms.TabPage
$historyTab.Text = "История"
$workTabs.TabPages.Add($historyTab)

# Переносим уже созданные элементы сообщения внутрь вкладки.
$messageTitle.Location = New-Object System.Drawing.Point(15, 15)
$messageBox.Location = New-Object System.Drawing.Point(15, 45)
$messageBox.Size = New-Object System.Drawing.Size(480, 190)

$copyMessageButton.Location = New-Object System.Drawing.Point(15, 250)
$copyMessageButton.Size = New-Object System.Drawing.Size(155, 36)

$copyLinkButton.Location = New-Object System.Drawing.Point(180, 250)
$copyLinkButton.Size = New-Object System.Drawing.Size(145, 36)

$openButton.Location = New-Object System.Drawing.Point(335, 250)
$openButton.Size = New-Object System.Drawing.Size(160, 36)

$messageTab.Controls.Add($messageTitle)
$messageTab.Controls.Add($messageBox)
$messageTab.Controls.Add($copyMessageButton)
$messageTab.Controls.Add($copyLinkButton)
$messageTab.Controls.Add($openButton)

# ----- Работа с подтверждённой консультацией -----

$handoffGroup = New-Object System.Windows.Forms.Panel
$handoffGroup.Location = New-Object System.Drawing.Point(26, 38)
$handoffGroup.Size = New-Object System.Drawing.Size(530, 258)
$handoffGroup.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$handoffTab.Controls.Add($handoffGroup)

# Заголовок вкладки "Передача" уже есть сверху, поэтому второй заголовок внутри
# карточки не нужен. Оставляем скрытый объект для совместимости с темизацией.
$handoffGroupTitle = New-Object System.Windows.Forms.Label
$handoffGroupTitle.Text = ""
$handoffGroupTitle.Visible = $false
$handoffGroup.Controls.Add($handoffGroupTitle)

$handoffSelectedLabel = New-Object System.Windows.Forms.Label
$handoffSelectedLabel.Text = "Сделка не выбрана"
$handoffSelectedLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)
$handoffSelectedLabel.AutoSize = $true
$handoffSelectedLabel.Location = New-Object System.Drawing.Point(24, 2)
$handoffGroup.Controls.Add($handoffSelectedLabel)

$handoffDueLabel = New-Object System.Windows.Forms.Label
$handoffDueLabel.Text = "Должно быть в таблице: —"
$handoffDueLabel.AutoSize = $true
$handoffDueLabel.Location = New-Object System.Drawing.Point(24, 30)
$handoffGroup.Controls.Add($handoffDueLabel)

$handoffSummaryLabel = New-Object System.Windows.Forms.Label
$handoffSummaryLabel.Text = "Все сделки"
$handoffSummaryLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$handoffSummaryLabel.AutoSize = $false
$handoffSummaryLabel.Size = New-Object System.Drawing.Size(480, 20)
$handoffSummaryLabel.Location = New-Object System.Drawing.Point(24, 56)
$handoffGroup.Controls.Add($handoffSummaryLabel)

# Статистика выбранного слота / всей даты.
$handoffTotalPanel = New-Object System.Windows.Forms.Panel
$handoffTotalPanel.Location = New-Object System.Drawing.Point(24, 80)
$handoffTotalPanel.Size = New-Object System.Drawing.Size(150, 60)
$handoffGroup.Controls.Add($handoffTotalPanel)

$handoffTotalTitle = New-Object System.Windows.Forms.Label
$handoffTotalTitle.Text = "Сделок"
$handoffTotalTitle.AutoSize = $false
$handoffTotalTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffTotalTitle.Location = New-Object System.Drawing.Point(0, 3)
$handoffTotalTitle.Size = New-Object System.Drawing.Size(150, 20)
$handoffTotalPanel.Controls.Add($handoffTotalTitle)

$handoffTotalValue = New-Object System.Windows.Forms.Label
$handoffTotalValue.Text = "0"
$handoffTotalValue.AutoSize = $false
$handoffTotalValue.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffTotalValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 14)
$handoffTotalValue.Location = New-Object System.Drawing.Point(0, 21)
$handoffTotalValue.Size = New-Object System.Drawing.Size(150, 32)
$handoffTotalPanel.Controls.Add($handoffTotalValue)

$handoffConfirmedPanel = New-Object System.Windows.Forms.Panel
$handoffConfirmedPanel.Location = New-Object System.Drawing.Point(190, 80)
$handoffConfirmedPanel.Size = New-Object System.Drawing.Size(150, 60)
$handoffGroup.Controls.Add($handoffConfirmedPanel)

$handoffConfirmedTitle = New-Object System.Windows.Forms.Label
$handoffConfirmedTitle.Text = "Подтверждено"
$handoffConfirmedTitle.AutoSize = $false
$handoffConfirmedTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffConfirmedTitle.Location = New-Object System.Drawing.Point(0, 3)
$handoffConfirmedTitle.Size = New-Object System.Drawing.Size(150, 20)
$handoffConfirmedPanel.Controls.Add($handoffConfirmedTitle)

$handoffConfirmedValue = New-Object System.Windows.Forms.Label
$handoffConfirmedValue.Text = "0"
$handoffConfirmedValue.AutoSize = $false
$handoffConfirmedValue.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffConfirmedValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 14)
$handoffConfirmedValue.Location = New-Object System.Drawing.Point(0, 21)
$handoffConfirmedValue.Size = New-Object System.Drawing.Size(150, 32)
$handoffConfirmedPanel.Controls.Add($handoffConfirmedValue)

$handoffPassedPanel = New-Object System.Windows.Forms.Panel
$handoffPassedPanel.Location = New-Object System.Drawing.Point(356, 80)
$handoffPassedPanel.Size = New-Object System.Drawing.Size(150, 60)
$handoffGroup.Controls.Add($handoffPassedPanel)

$handoffPassedTitle = New-Object System.Windows.Forms.Label
$handoffPassedTitle.Text = "Передано"
$handoffPassedTitle.AutoSize = $false
$handoffPassedTitle.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffPassedTitle.Location = New-Object System.Drawing.Point(0, 3)
$handoffPassedTitle.Size = New-Object System.Drawing.Size(150, 20)
$handoffPassedPanel.Controls.Add($handoffPassedTitle)

$handoffPassedValue = New-Object System.Windows.Forms.Label
$handoffPassedValue.Text = "0"
$handoffPassedValue.AutoSize = $false
$handoffPassedValue.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffPassedValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 14)
$handoffPassedValue.Location = New-Object System.Drawing.Point(0, 21)
$handoffPassedValue.Size = New-Object System.Drawing.Size(150, 32)
$handoffPassedPanel.Controls.Add($handoffPassedValue)

# Старый текстовый summary оставляем скрытым для совместимости с логикой.
$handoffOutcomeSummaryLabel = New-Object System.Windows.Forms.Label
$handoffOutcomeSummaryLabel.Text = ""
$handoffOutcomeSummaryLabel.Visible = $false
$handoffGroup.Controls.Add($handoffOutcomeSummaryLabel)

$handoffReassignStatPanel = New-Object System.Windows.Forms.Panel
$handoffReassignStatPanel.Location = New-Object System.Drawing.Point(24, 146)
$handoffReassignStatPanel.Size = New-Object System.Drawing.Size(230, 34)
$handoffGroup.Controls.Add($handoffReassignStatPanel)

$handoffReassignStatLabel = New-Object System.Windows.Forms.Label
$handoffReassignStatLabel.Text = "Переназначить  0"
$handoffReassignStatLabel.AutoSize = $false
$handoffReassignStatLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffReassignStatLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$handoffReassignStatLabel.Dock = [System.Windows.Forms.DockStyle]::Fill
$handoffReassignStatPanel.Controls.Add($handoffReassignStatLabel)

$handoffRefuseStatPanel = New-Object System.Windows.Forms.Panel
$handoffRefuseStatPanel.Location = New-Object System.Drawing.Point(274, 146)
$handoffRefuseStatPanel.Size = New-Object System.Drawing.Size(230, 34)
$handoffGroup.Controls.Add($handoffRefuseStatPanel)

$handoffRefuseStatLabel = New-Object System.Windows.Forms.Label
$handoffRefuseStatLabel.Text = "Отказ  0"
$handoffRefuseStatLabel.AutoSize = $false
$handoffRefuseStatLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$handoffRefuseStatLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)
$handoffRefuseStatLabel.Dock = [System.Windows.Forms.DockStyle]::Fill
$handoffRefuseStatPanel.Controls.Add($handoffRefuseStatLabel)

$confirmDealButton = New-Object System.Windows.Forms.Button
$confirmDealButton.Text = "Подтвердить"
$confirmDealButton.Location = New-Object System.Drawing.Point(24, 182)
$confirmDealButton.Size = New-Object System.Drawing.Size(150, 38)
$confirmDealButton.Enabled = $true
$handoffGroup.Controls.Add($confirmDealButton)

$handoffDoneButton = New-Object System.Windows.Forms.Button
$handoffDoneButton.Text = "Передано"
$handoffDoneButton.Location = New-Object System.Drawing.Point(356, 182)
$handoffDoneButton.Size = New-Object System.Drawing.Size(150, 38)
$handoffDoneButton.Enabled = $true
$handoffGroup.Controls.Add($handoffDoneButton)

$reassignDealButton = New-Object System.Windows.Forms.Button
$reassignDealButton.Text = "Переназначить"
$reassignDealButton.Size = New-Object System.Drawing.Size(150, 38)
$reassignDealButton.Enabled = $true
$handoffGroup.Controls.Add($reassignDealButton)

$refuseDealButton = New-Object System.Windows.Forms.Button
$refuseDealButton.Text = "Отказ"
$refuseDealButton.Size = New-Object System.Drawing.Size(150, 38)
$refuseDealButton.Enabled = $true
$handoffGroup.Controls.Add($refuseDealButton)

$clearDecisionButton = New-Object System.Windows.Forms.Button
$clearDecisionButton.Text = "Сбросить"
$clearDecisionButton.Size = New-Object System.Drawing.Size(150, 38)
$clearDecisionButton.Enabled = $true
$handoffGroup.Controls.Add($clearDecisionButton)

$handoffStatusLabel = New-Object System.Windows.Forms.Label
$handoffStatusLabel.Text = "Статус: —"
$handoffStatusLabel.AutoSize = $false
$handoffStatusLabel.Size = New-Object System.Drawing.Size(348, 48)
$handoffStatusLabel.Location = New-Object System.Drawing.Point(24, 222)
$handoffGroup.Controls.Add($handoffStatusLabel)

# ----- Данные для строки Google Sheets -----

$googleSelectedLabel = New-Object System.Windows.Forms.Label
$googleSelectedLabel.Text = "Сделка не выбрана"
$googleSelectedLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$googleSelectedLabel.AutoSize = $true
$googleSelectedLabel.Location = New-Object System.Drawing.Point(18, 20)
$googleTab.Controls.Add($googleSelectedLabel)

$mvlTagLabel = New-Object System.Windows.Forms.Label
$mvlTagLabel.Text = "МВЛ-тег"
$mvlTagLabel.AutoSize = $true
$mvlTagLabel.Location = New-Object System.Drawing.Point(18, 58)
$googleTab.Controls.Add($mvlTagLabel)

$mvlTagValue = New-Object System.Windows.Forms.Label
$mvlTagValue.Text = "не указан"
$mvlTagValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)
$mvlTagValue.AutoSize = $true
$mvlTagValue.Location = New-Object System.Drawing.Point(90, 58)
$googleTab.Controls.Add($mvlTagValue)

$phoneLabel = New-Object System.Windows.Forms.Label
$phoneLabel.Text = "Телефон"
$phoneLabel.AutoSize = $false
$phoneLabel.Size = New-Object System.Drawing.Size(170, 20)
$phoneLabel.Location = New-Object System.Drawing.Point(18, 88)
$googleTab.Controls.Add($phoneLabel)

$clientPhoneBox = New-Object System.Windows.Forms.TextBox
$clientPhoneBox.Location = New-Object System.Drawing.Point(18, 110)
$clientPhoneBox.Size = New-Object System.Drawing.Size(220, 30)
$clientPhoneBox.Enabled = $false
$googleTab.Controls.Add($clientPhoneBox)

$parentLabel = New-Object System.Windows.Forms.Label
$parentLabel.Text = "Родитель"
$parentLabel.AutoSize = $false
$parentLabel.Size = New-Object System.Drawing.Size(170, 20)
$parentLabel.Location = New-Object System.Drawing.Point(255, 88)
$googleTab.Controls.Add($parentLabel)

$parentNameBox = New-Object System.Windows.Forms.TextBox
$parentNameBox.Location = New-Object System.Drawing.Point(255, 110)
$parentNameBox.Size = New-Object System.Drawing.Size(235, 30)
$parentNameBox.Enabled = $false
$googleTab.Controls.Add($parentNameBox)

$studentLabel = New-Object System.Windows.Forms.Label
$studentLabel.Text = "Ученик"
$studentLabel.AutoSize = $false
$studentLabel.Size = New-Object System.Drawing.Size(170, 20)
$studentLabel.Location = New-Object System.Drawing.Point(18, 150)
$googleTab.Controls.Add($studentLabel)

$studentNameBox = New-Object System.Windows.Forms.TextBox
$studentNameBox.Location = New-Object System.Drawing.Point(18, 172)
$studentNameBox.Size = New-Object System.Drawing.Size(220, 30)
$studentNameBox.Enabled = $false
$googleTab.Controls.Add($studentNameBox)

$classLabel = New-Object System.Windows.Forms.Label
$classLabel.Text = "Класс"
$classLabel.AutoSize = $false
$classLabel.Size = New-Object System.Drawing.Size(78, 20)
$classLabel.Location = New-Object System.Drawing.Point(255, 150)
$googleTab.Controls.Add($classLabel)

$childClassBox = New-Object System.Windows.Forms.TextBox
$childClassBox.Location = New-Object System.Drawing.Point(255, 172)
$childClassBox.Size = New-Object System.Drawing.Size(110, 30)
$childClassBox.Enabled = $false
$googleTab.Controls.Add($childClassBox)

$sourceLabel = New-Object System.Windows.Forms.Label
$sourceLabel.Text = "Источник"
$sourceLabel.AutoSize = $false
$sourceLabel.Size = New-Object System.Drawing.Size(82, 20)
$sourceLabel.Location = New-Object System.Drawing.Point(380, 150)
$googleTab.Controls.Add($sourceLabel)

$leadSourceBox = New-Object System.Windows.Forms.TextBox
$leadSourceBox.Location = New-Object System.Drawing.Point(380, 172)
$leadSourceBox.Size = New-Object System.Drawing.Size(110, 30)
$leadSourceBox.Enabled = $false
$googleTab.Controls.Add($leadSourceBox)

$googleFormatLabel = New-Object System.Windows.Forms.Label
$googleFormatLabel.Text = "Вставка с ячейки «МВЛ»: МВЛ | Телефончик | Имя | Айди | [Статус] | [Сумма] | ЧТО ЗА ЛИД | [9 класс] | Ссылка"
$googleFormatLabel.AutoSize = $false
$googleFormatLabel.Size = New-Object System.Drawing.Size(472, 44)
$googleFormatLabel.Location = New-Object System.Drawing.Point(18, 212)
$googleTab.Controls.Add($googleFormatLabel)

$copySheetsButton = New-Object System.Windows.Forms.Button
$copySheetsButton.Text = "Скопировать строку для Google"
$copySheetsButton.Location = New-Object System.Drawing.Point(18, 260)
$copySheetsButton.Size = New-Object System.Drawing.Size(472, 38)
$copySheetsButton.Enabled = $false
$googleTab.Controls.Add($copySheetsButton)

# ==================== Modern visual layout ====================

# Основная идея v8:
# 1) верхняя панель управления;
# 2) большая карточка "Новая консультация";
# 3) отдельная карточка действий справа;
# 4) широкая карточка актуальных сделок снизу.
#
# Функциональность не меняется — меняется только композиция интерфейса.

$headerCard = New-Object System.Windows.Forms.Panel
$headerCard.Location = New-Object System.Drawing.Point(22, 18)
$headerCard.Size = New-Object System.Drawing.Size(1195, 82)
$headerCard.Anchor = "Top,Left,Right"
$form.Controls.Add($headerCard)

# Две основные страницы:
# Главная = Новая консультация + Таблица + Готовое сообщение.
# Сделки  = Актуальные сделки + Передача + История действий.
$mainPagePanel = New-Object System.Windows.Forms.Panel
$mainPagePanel.Location = New-Object System.Drawing.Point(22, 112)
$mainPagePanel.Size = New-Object System.Drawing.Size(1195, 592)
$mainPagePanel.Anchor = "Top,Left"
$form.Controls.Add($mainPagePanel)

$dealsPagePanel = New-Object System.Windows.Forms.Panel
$dealsPagePanel.Location = New-Object System.Drawing.Point(22, 112)
$dealsPagePanel.Size = New-Object System.Drawing.Size(1195, 592)
$dealsPagePanel.Anchor = "Top,Left"
$dealsPagePanel.Visible = $false
$form.Controls.Add($dealsPagePanel)

# Главная — левая большая карточка.
$plannerCard = New-Object System.Windows.Forms.Panel
$plannerCard.Location = New-Object System.Drawing.Point(0, 14)
$plannerCard.Size = New-Object System.Drawing.Size(725, 578)
$plannerCard.Anchor = "Top,Left"
$mainPagePanel.Controls.Add($plannerCard)

# Главная — справа Таблица и Готовое сообщение одновременно.
$mainTableCard = New-Object System.Windows.Forms.Panel
$mainTableCard.Location = New-Object System.Drawing.Point(743, 14)
$mainTableCard.Size = New-Object System.Drawing.Size(452, 338)
$mainTableCard.Anchor = "Top,Left"
$mainPagePanel.Controls.Add($mainTableCard)

$mainMessageCard = New-Object System.Windows.Forms.Panel
$mainMessageCard.Location = New-Object System.Drawing.Point(743, 360)
$mainMessageCard.Size = New-Object System.Drawing.Size(452, 218)
$mainMessageCard.Anchor = "Top,Left"
$mainPagePanel.Controls.Add($mainMessageCard)

# Старый actionCard остаётся скрытым только как совместимый контейнер
# для внутреннего TabControl. Пользователь его больше не видит.
$actionCard = New-Object System.Windows.Forms.Panel
$actionCard.Location = New-Object System.Drawing.Point(0, 0)
$actionCard.Size = New-Object System.Drawing.Size(1, 1)
$actionCard.Visible = $false
$form.Controls.Add($actionCard)

# Сделки — широкий список сверху.
$historyCard = New-Object System.Windows.Forms.Panel
$historyCard.Location = New-Object System.Drawing.Point(0, 0)
$historyCard.Size = New-Object System.Drawing.Size(1195, 258)
$historyCard.Anchor = "Top,Left"
$dealsPagePanel.Controls.Add($historyCard)

# Сделки — два рабочих блока снизу.
$dealsHandoffCard = New-Object System.Windows.Forms.Panel
$dealsHandoffCard.Location = New-Object System.Drawing.Point(0, 274)
$dealsHandoffCard.Size = New-Object System.Drawing.Size(585, 310)
$dealsHandoffCard.Anchor = "Top,Left"
$dealsPagePanel.Controls.Add($dealsHandoffCard)

$dealsTimelineCard = New-Object System.Windows.Forms.Panel
$dealsTimelineCard.Location = New-Object System.Drawing.Point(603, 274)
$dealsTimelineCard.Size = New-Object System.Drawing.Size(592, 310)
$dealsTimelineCard.Anchor = "Top,Left"
$dealsPagePanel.Controls.Add($dealsTimelineCard)

# ---- Header ----
$headerCard.Controls.Add($title)
$headerCard.Controls.Add($versionLabel)
$headerCard.Controls.Add($apiStatus)
$headerCard.Controls.Add($refreshApi)
$headerCard.Controls.Add($themeLabel)
$headerCard.Controls.Add($lightButton)
$headerCard.Controls.Add($darkButton)
$headerCard.Controls.Add($settingsButton)

$shiftStatsLabel = New-Object System.Windows.Forms.Label
$shiftStatsLabel.Text = ""
$shiftStatsLabel.AutoSize = $false
$shiftStatsLabel.Visible = $false
$shiftStatsLabel.Size = New-Object System.Drawing.Size(1, 1)

$pageNavPanel = New-Object System.Windows.Forms.Panel
$pageNavPanel.Location = New-Object System.Drawing.Point(512, 18)
$pageNavPanel.Size = New-Object System.Drawing.Size(258, 40)
$headerCard.Controls.Add($pageNavPanel)

$mainPageButton = New-Object System.Windows.Forms.Button
$mainPageButton.Text = "Главная"
$mainPageButton.Location = New-Object System.Drawing.Point(2, 2)
$mainPageButton.Size = New-Object System.Drawing.Size(122, 34)
$pageNavPanel.Controls.Add($mainPageButton)

$dealsPageButton = New-Object System.Windows.Forms.Button
$dealsPageButton.Text = "Сделки"
$dealsPageButton.Location = New-Object System.Drawing.Point(134, 2)
$dealsPageButton.Size = New-Object System.Drawing.Size(122, 34)
$pageNavPanel.Controls.Add($dealsPageButton)

$title.Location = New-Object System.Drawing.Point(20, 18)
$title.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 18)

$versionLabel.Location = New-Object System.Drawing.Point(205, 20)
$versionLabel.AutoSize = $false
$versionLabel.Size = New-Object System.Drawing.Size(82, 28)
$versionLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter

# В шапке остаются только навигация и настройки.
$title.Visible = $true
$versionLabel.Visible = $true

# Верхний бар: навигация по центру, настройки справа.
# Основные элементы управления темой/API теперь внутри окна настроек.
$apiStatus.Visible = $false
$refreshApi.Visible = $false
$themeLabel.Visible = $false
$lightButton.Visible = $false
$darkButton.Visible = $false

$settingsButton.Location = New-Object System.Drawing.Point(1127, 22)
$settingsButton.Size = New-Object System.Drawing.Size(48, 38)
$settingsButton.Text = "⚙"

# ---- Planner card ----
$plannerHeader = New-Object System.Windows.Forms.Label
$plannerHeader.Text = "Новая консультация"
$plannerHeader.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$plannerHeader.AutoSize = $true
$plannerHeader.Location = New-Object System.Drawing.Point(34, 16)
$plannerCard.Controls.Add($plannerHeader)

$plannerSubheader = New-Object System.Windows.Forms.Label
$plannerSubheader.Text = "Создайте комнату для онлайн-консультации"
$plannerSubheader.Font = New-Object System.Drawing.Font("Segoe UI", 10)
$plannerSubheader.AutoSize = $true
$plannerSubheader.Location = New-Object System.Drawing.Point(34, 46)
$plannerCard.Controls.Add($plannerSubheader)

$plannerAccent = New-Object System.Windows.Forms.Panel
$plannerAccent.Location = New-Object System.Drawing.Point(20, 17)
$plannerAccent.Size = New-Object System.Drawing.Size(4, 24)
$plannerCard.Controls.Add($plannerAccent)

$plannerFooterLine = New-Object System.Windows.Forms.Panel
$plannerFooterLine.Location = New-Object System.Drawing.Point(20, 504)
$plannerFooterLine.Size = New-Object System.Drawing.Size(685, 1)
$plannerCard.Controls.Add($plannerFooterLine)

$plannerCard.Controls.Add($dateTitle)
$plannerCard.Controls.Add($todayButton)
$plannerCard.Controls.Add($tomorrowButton)
$plannerCard.Controls.Add($otherDateButton)
$plannerCard.Controls.Add($datePicker)
$plannerCard.Controls.Add($slotTitle)

foreach ($btn in $slotButtons) {
    $plannerCard.Controls.Add($btn)
}

$plannerCard.Controls.Add($customTitle)
$plannerCard.Controls.Add($customButton)
$plannerCard.Controls.Add($customTimePicker)
$plannerCard.Controls.Add($minus30)
$plannerCard.Controls.Add($minus15)
$plannerCard.Controls.Add($plus15)
$plannerCard.Controls.Add($plus30)
$plannerCard.Controls.Add($customInfo)
$plannerCard.Controls.Add($idTitle)
$plannerCard.Controls.Add($idBox)
$plannerCard.Controls.Add($idHistoryLabel)
$plannerCard.Controls.Add($previewTitle)
$plannerCard.Controls.Add($previewBox)

$dateTitle.Location = New-Object System.Drawing.Point(20, 74)
$dateTitle.Text = "Дата"

$todayButton.Location = New-Object System.Drawing.Point(20, 110)
$todayButton.Size = New-Object System.Drawing.Size(100, 36)
$tomorrowButton.Visible = $false
$tomorrowButton.Size = New-Object System.Drawing.Size(1, 1)
$otherDateButton.Visible = $false
$otherDateButton.Size = New-Object System.Drawing.Size(1, 1)
$datePicker.Location = New-Object System.Drawing.Point(128, 108)
$datePicker.Size = New-Object System.Drawing.Size(165, 36)
$datePicker.Visible = $false

$dateSelectButton = New-Object System.Windows.Forms.Button
$dateSelectButton.Text = $datePicker.Value.ToString("dd.MM.yyyy")
$dateSelectButton.Location = New-Object System.Drawing.Point(128, 110)
$dateSelectButton.Size = New-Object System.Drawing.Size(165, 36)
$dateSelectButton.TextAlign = [System.Drawing.ContentAlignment]::MiddleLeft
$dateSelectButton.Padding = New-Object System.Windows.Forms.Padding(10,0,36,0)
$plannerCard.Controls.Add($dateSelectButton)

$dateChevronLabel = New-Object System.Windows.Forms.Label
$dateChevronLabel.Text = "▼"
$dateChevronLabel.AutoSize = $false
$dateChevronLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$dateChevronLabel.Location = New-Object System.Drawing.Point(132, 1)
$dateChevronLabel.Size = New-Object System.Drawing.Size(31, 33)
$dateSelectButton.Controls.Add($dateChevronLabel)

$slotTitle.Location = New-Object System.Drawing.Point(20, 165)
$slotTitle.Text = "Время"

for ($i = 0; $i -lt $slotButtons.Count; $i++) {
    $btn = $slotButtons[$i]
    $col = $i % 4
    $row = [math]::Floor($i / 4)

    $btn.Location = New-Object System.Drawing.Point(
        (20 + $col * 171),
        (191 + $row * 58)
    )
    $btn.Size = New-Object System.Drawing.Size(160, 50)
}

$customTitle.Location = New-Object System.Drawing.Point(20, 310)
$customTitle.Text = "Точное время"

$customButton.Location = New-Object System.Drawing.Point(20, 344)
$customButton.Size = New-Object System.Drawing.Size(122, 36)
$customButton.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$customButton.FlatAppearance.BorderSize = 1
$customButton.UseVisualStyleBackColor = $false
$customTimePicker.Location = New-Object System.Drawing.Point(145, 347)
$customTimePicker.Size = New-Object System.Drawing.Size(85, 30)
$customTimePicker.Visible = $false
$customTimePicker.Enabled = $false

$customTimeShell = New-Object System.Windows.Forms.Panel
$customTimeShell.Location = New-Object System.Drawing.Point(154, 344)
$customTimeShell.Size = New-Object System.Drawing.Size(90, 36)
$customTimeShell.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$plannerCard.Controls.Add($customTimeShell)

$customTimeText = New-Object System.Windows.Forms.TextBox
$customTimeText.Text = "11:00"
$customTimeText.Location = New-Object System.Drawing.Point(10, 8)
$customTimeText.Size = New-Object System.Drawing.Size(70, 20)
$customTimeText.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$customTimeText.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center
$customTimeText.MaxLength = 5
$customTimeText.Enabled = $true
$customTimeText.ReadOnly = $true
$customTimeShell.Controls.Add($customTimeText)

# The HH:mm field uses the same native TextBox geometry as the fields in «Таблица».
# Re-parenting removes the extra inner shell look.
$customTimeShell.Visible = $false
$plannerCard.Controls.Add($customTimeText)
$customTimeText.Location = New-Object System.Drawing.Point(154, 344)
$customTimeText.AutoSize = $false
$customTimeText.Size = New-Object System.Drawing.Size(165, 36)
$customTimeText.Multiline = $false

$minus30.Location = New-Object System.Drawing.Point(330, 344)
$minus30.Size = New-Object System.Drawing.Size(54, 36)
$minus15.Location = New-Object System.Drawing.Point(388, 344)
$minus15.Size = New-Object System.Drawing.Size(54, 36)
$plus15.Location = New-Object System.Drawing.Point(446, 344)
$plus15.Size = New-Object System.Drawing.Size(54, 36)
$plus30.Location = New-Object System.Drawing.Point(504, 344)
$plus30.Size = New-Object System.Drawing.Size(54, 36)

$customInfo.Location = New-Object System.Drawing.Point(490, 348)
$customInfo.Size = New-Object System.Drawing.Size(210, 34)
$customInfo.Visible = $false

$idTitle.Location = New-Object System.Drawing.Point(20, 404)
$idBox.Location = New-Object System.Drawing.Point(20, 434)
$idBox.AutoSize = $false
$idBox.Size = New-Object System.Drawing.Size(165, 36)

$idHistoryLabel.Location = New-Object System.Drawing.Point(20, 474)
$idHistoryLabel.Size = New-Object System.Drawing.Size(680, 38)
$idHistoryLabel.AutoEllipsis = $false

$previewTitle.Visible = $false
$previewBox.Visible = $false
$previewBox.Text = ""
$previewBox.ReadOnly = $true
$previewBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$previewBox.TabStop = $false

# ---- Action card ----
$actionHeader = New-Object System.Windows.Forms.Label
$actionHeader.Text = "Работа со сделкой"
$actionHeader.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 15)
$actionHeader.AutoSize = $true
$actionHeader.Location = New-Object System.Drawing.Point(20, 16)
$actionHeader.Visible = $false
$actionCard.Controls.Add($actionHeader)

$plannerCard.Controls.Add($createButton)
$actionCard.Controls.Add($workTabs)

$createButton.Location = New-Object System.Drawing.Point(20, 524)
$createButton.Size = New-Object System.Drawing.Size(685, 44)

$workNavPanel = New-Object System.Windows.Forms.Panel
$workNavPanel.Location = New-Object System.Drawing.Point(20, 120)
$workNavPanel.Size = New-Object System.Drawing.Size(412, 38)
$workNavPanel.Visible = $false
$actionCard.Controls.Add($workNavPanel)

$messageNavButton = New-Object System.Windows.Forms.Button
$messageNavButton.Text = "Сообщение"
$messageNavButton.Location = New-Object System.Drawing.Point(0, 0)
$messageNavButton.Size = New-Object System.Drawing.Size(97, 36)
$workNavPanel.Controls.Add($messageNavButton)

$handoffNavButton = New-Object System.Windows.Forms.Button
$handoffNavButton.Text = "Передача"
$handoffNavButton.Location = New-Object System.Drawing.Point(103, 0)
$handoffNavButton.Size = New-Object System.Drawing.Size(97, 36)
$workNavPanel.Controls.Add($handoffNavButton)

$googleNavButton = New-Object System.Windows.Forms.Button
$googleNavButton.Text = "Таблица"
$googleNavButton.Location = New-Object System.Drawing.Point(206, 0)
$googleNavButton.Size = New-Object System.Drawing.Size(97, 36)
$workNavPanel.Controls.Add($googleNavButton)

$timelineNavButton = New-Object System.Windows.Forms.Button
$timelineNavButton.Text = "История"
$timelineNavButton.Location = New-Object System.Drawing.Point(309, 0)
$timelineNavButton.Size = New-Object System.Drawing.Size(103, 36)
$workNavPanel.Controls.Add($timelineNavButton)

# Системные заголовки TabControl прячем почти полностью.
# Переключение вкладок теперь идёт через три нормальные кнопки выше.
$workTabs.Location = New-Object System.Drawing.Point(20, 164)
$workTabs.Size = New-Object System.Drawing.Size(412, 322)
$workTabs.Appearance = [System.Windows.Forms.TabAppearance]::FlatButtons
$workTabs.DrawMode = [System.Windows.Forms.TabDrawMode]::Normal
$workTabs.SizeMode = [System.Windows.Forms.TabSizeMode]::Fixed
$workTabs.ItemSize = New-Object System.Drawing.Size(0, 1)
$workTabs.Multiline = $true
$workTabs.Padding = New-Object System.Drawing.Point(0, 0)

# v8.3: системный TabControl больше не рисуется.
# Именно он давал белую рамку в тёмной теме.
# Оставляем его скрытым только как внутренний переключатель состояния.
$workTabs.Visible = $false

$workContentHost = New-Object System.Windows.Forms.Panel
$workContentHost.Location = New-Object System.Drawing.Point(20, 156)
$workContentHost.Size = New-Object System.Drawing.Size(412, 330)
$workContentHost.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$workContentHost.Visible = $false
$actionCard.Controls.Add($workContentHost)

$messageContentPanel = New-Object System.Windows.Forms.Panel
$messageContentPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$messageContentPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$mainMessageCard.Controls.Add($messageContentPanel)

$messageAccent = New-Object System.Windows.Forms.Panel
$messageAccent.Location = New-Object System.Drawing.Point(14, 15)
$messageAccent.Size = New-Object System.Drawing.Size(4, 22)
$messageContentPanel.Controls.Add($messageAccent)

$handoffContentPanel = New-Object System.Windows.Forms.Panel
$handoffContentPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$handoffContentPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$dealsHandoffCard.Controls.Add($handoffContentPanel)

$handoffCardAccent = New-Object System.Windows.Forms.Panel
$handoffCardAccent.Location = New-Object System.Drawing.Point(24, 16)
$handoffCardAccent.Size = New-Object System.Drawing.Size(4, 22)
$handoffContentPanel.Controls.Add($handoffCardAccent)

$handoffCardTitle = New-Object System.Windows.Forms.Label
$handoffCardTitle.Text = "Передача"
$handoffCardTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)
$handoffCardTitle.AutoSize = $true
$handoffCardTitle.Location = New-Object System.Drawing.Point(38, 14)
$handoffContentPanel.Controls.Add($handoffCardTitle)

$googleContentPanel = New-Object System.Windows.Forms.Panel
$googleContentPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$googleContentPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$mainTableCard.Controls.Add($googleContentPanel)

$googleAccent = New-Object System.Windows.Forms.Panel
$googleAccent.Location = New-Object System.Drawing.Point(14, 13)
$googleAccent.Size = New-Object System.Drawing.Size(4, 22)
$googleContentPanel.Controls.Add($googleAccent)

$timelineContentPanel = New-Object System.Windows.Forms.Panel
$timelineContentPanel.Dock = [System.Windows.Forms.DockStyle]::Fill
$timelineContentPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$dealsTimelineCard.Controls.Add($timelineContentPanel)

$timelineTitle = New-Object System.Windows.Forms.Label
$timelineTitle.Text = "История действий"
$timelineTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)
$timelineTitle.AutoSize = $true
$timelineTitle.Location = New-Object System.Drawing.Point(38, 14)
$timelineContentPanel.Controls.Add($timelineTitle)

$timelineAccent = New-Object System.Windows.Forms.Panel
$timelineAccent.Location = New-Object System.Drawing.Point(24, 16)
$timelineAccent.Size = New-Object System.Drawing.Size(4, 22)
$timelineContentPanel.Controls.Add($timelineAccent)

$timelineDealLabel = New-Object System.Windows.Forms.Label
$timelineDealLabel.Text = "Сделка не выбрана"
$timelineDealLabel.AutoSize = $false
$timelineDealLabel.Location = New-Object System.Drawing.Point(28, 48)
$timelineDealLabel.Size = New-Object System.Drawing.Size(536, 22)
$timelineContentPanel.Controls.Add($timelineDealLabel)

$timelineList = New-Object System.Windows.Forms.ListBox
$timelineList.Location = New-Object System.Drawing.Point(28, 72)
$timelineList.Size = New-Object System.Drawing.Size(536, 206)
$timelineList.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$timelineList.IntegralHeight = $false
$timelineList.Font = New-Object System.Drawing.Font("Segoe UI", 9)
$timelineContentPanel.Controls.Add($timelineList)

# Message tab
$messageTitle.Location = New-Object System.Drawing.Point(30, 14)
$messageTitle.Text = "Готовое сообщение"
$messageTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 12)

$messageBox.Location = New-Object System.Drawing.Point(14, 45)
$messageBox.Size = New-Object System.Drawing.Size(396, 118)
$messageBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle

$copyMessageButton.Location = New-Object System.Drawing.Point(14, 171)
$copyMessageButton.Size = New-Object System.Drawing.Size(188, 38)
$copyMessageButton.Text = "SMS"

$copyLinkButton.Visible = $false
$copyLinkButton.Enabled = $false

$openButton.Location = New-Object System.Drawing.Point(222, 171)
$openButton.Size = New-Object System.Drawing.Size(162, 38)
$openButton.Text = "KTalk"

$messageContentPanel.Controls.Add($messageTitle)
$messageContentPanel.Controls.Add($messageBox)
$messageContentPanel.Controls.Add($copyMessageButton)
$messageContentPanel.Controls.Add($copyLinkButton)
$messageContentPanel.Controls.Add($openButton)

# Handoff tab — плоская карточка без лишней внутренней рамки.
$handoffGroup.Location = New-Object System.Drawing.Point(26, 38)
$handoffGroup.Size = New-Object System.Drawing.Size(530, 258)

$handoffSelectedLabel.Location = New-Object System.Drawing.Point(24, 2)
$handoffSelectedLabel.MaximumSize = New-Object System.Drawing.Size(500, 0)

$handoffDueLabel.Location = New-Object System.Drawing.Point(24, 30)
$handoffSummaryLabel.Location = New-Object System.Drawing.Point(24, 56)

$handoffTotalPanel.Location = New-Object System.Drawing.Point(24, 80)
$handoffConfirmedPanel.Location = New-Object System.Drawing.Point(190, 80)
$handoffPassedPanel.Location = New-Object System.Drawing.Point(356, 80)

$handoffReassignStatPanel.Location = New-Object System.Drawing.Point(24, 146)
$handoffRefuseStatPanel.Location = New-Object System.Drawing.Point(274, 146)

$confirmDealButton.Location = New-Object System.Drawing.Point(24, 182)
$confirmDealButton.Size = New-Object System.Drawing.Size(110, 36)
$confirmDealButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$reassignDealButton.Location = New-Object System.Drawing.Point(190, 182)
$reassignDealButton.Size = New-Object System.Drawing.Size(110, 36)
$reassignDealButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8.5)

$refuseDealButton.Location = New-Object System.Drawing.Point(356, 182)
$refuseDealButton.Size = New-Object System.Drawing.Size(110, 36)
$refuseDealButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$handoffDoneButton.Location = New-Object System.Drawing.Point(356, 182)
$handoffDoneButton.Size = New-Object System.Drawing.Size(110, 36)
$handoffDoneButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$clearDecisionButton.Location = New-Object System.Drawing.Point(24, 182)
$clearDecisionButton.Size = New-Object System.Drawing.Size(110, 36)
$clearDecisionButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$handoffStatusLabel.Location = New-Object System.Drawing.Point(24, 222)
$handoffStatusLabel.Size = New-Object System.Drawing.Size(482, 34)

$handoffContentPanel.Controls.Add($handoffGroup)

# Table tab
$googleSelectedLabel.Location = New-Object System.Drawing.Point(30, 12)
$googleSelectedLabel.MaximumSize = New-Object System.Drawing.Size(368, 0)
$googleSelectedLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)

$googleStateHint = New-Object System.Windows.Forms.Label
$googleStateHint.Text = ""
$googleStateHint.AutoSize = $false
$googleStateHint.Location = New-Object System.Drawing.Point(14, 41)
$googleStateHint.Size = New-Object System.Drawing.Size(360, 20)
$googleStateHint.Font = New-Object System.Drawing.Font("Segoe UI", 9)

$mvlTagLabel.Location = New-Object System.Drawing.Point(14, 68)
$mvlTagLabel.Text = "МВЛ:"
$mvlTagValue.Location = New-Object System.Drawing.Point(58, 68)
$mvlTagValue.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 10)

$phoneLabel.Location = New-Object System.Drawing.Point(14, 98)
$clientPhoneBox.Location = New-Object System.Drawing.Point(14, 124)
$clientPhoneBox.Size = New-Object System.Drawing.Size(170, 32)
$clientPhoneBox.AutoSize = $false

$parentLabel.Location = New-Object System.Drawing.Point(204, 98)
$parentNameBox.Location = New-Object System.Drawing.Point(204, 124)
$parentNameBox.Size = New-Object System.Drawing.Size(170, 32)
$parentNameBox.AutoSize = $false

$studentLabel.Location = New-Object System.Drawing.Point(14, 166)
$studentNameBox.Location = New-Object System.Drawing.Point(14, 192)
$studentNameBox.Size = New-Object System.Drawing.Size(155, 32)
$studentNameBox.AutoSize = $false

$classLabel.Text = "Класс"
$classLabel.Location = New-Object System.Drawing.Point(185, 166)
$childClassBox.Location = New-Object System.Drawing.Point(185, 192)
$childClassBox.Size = New-Object System.Drawing.Size(65, 32)
$childClassBox.AutoSize = $false

$sourceLabel.Text = "Источник"
$sourceLabel.Location = New-Object System.Drawing.Point(260, 166)
$leadSourceBox.Location = New-Object System.Drawing.Point(260, 192)
$leadSourceBox.Size = New-Object System.Drawing.Size(114, 32)
$leadSourceBox.AutoSize = $false

$googleFormatLabel.Text = ""
$googleFormatLabel.Location = New-Object System.Drawing.Point(14, 224)
$googleFormatLabel.Size = New-Object System.Drawing.Size(1, 1)
$googleFormatLabel.Visible = $false

$clipboardImportButton = New-Object System.Windows.Forms.Button
$clipboardImportButton.Location = New-Object System.Drawing.Point(14, 240)
$clipboardImportButton.Size = New-Object System.Drawing.Size(360, 36)
$clipboardImportButton.Text = "Заполнить из буфера amoCRM"

$copySheetsButton.Location = New-Object System.Drawing.Point(14, 284)
$copySheetsButton.Size = New-Object System.Drawing.Size(360, 36)
$copySheetsButton.Text = "Скопировать в таблицу"

foreach ($ctrl in @(
    $googleSelectedLabel,
    $googleStateHint,
    $mvlTagLabel,
    $mvlTagValue,
    $phoneLabel,
    $clientPhoneBox,
    $parentLabel,
    $parentNameBox,
    $studentLabel,
    $studentNameBox,
    $classLabel,
    $childClassBox,
    $sourceLabel,
    $leadSourceBox,
    $googleFormatLabel,
    $clipboardImportButton,
    $copySheetsButton
)) {
    $googleContentPanel.Controls.Add($ctrl)
}

# Истинное центрирование значений:
# внешний Panel сохраняет высоту/рамку поля, а сам TextBox внутри
# центрируется и по горизонтали, и по вертикали.
$clientPhoneShell = Install-CenteredTextBoxShell $clientPhoneBox $googleContentPanel
$parentNameShell = Install-CenteredTextBoxShell $parentNameBox $googleContentPanel
$studentNameShell = Install-CenteredTextBoxShell $studentNameBox $googleContentPanel
$childClassShell = Install-CenteredTextBoxShell $childClassBox $googleContentPanel
$leadSourceShell = Install-CenteredTextBoxShell $leadSourceBox $googleContentPanel

# Labels must always stay above the field shells.
$studentLabel.BringToFront()
$classLabel.BringToFront()
$sourceLabel.BringToFront()

$customTimeValueShell = Install-DateStyleTextField $customTimeText $plannerCard
$idValueShell = Install-DateStyleTextField $idBox $plannerCard

foreach ($centeredBox in @(
    $clientPhoneBox,
    $parentNameBox,
    $studentNameBox,
    $childClassBox,
    $leadSourceBox
)) {
    $centeredBox.Add_TextChanged({
        Update-CenteredTextBox $this
    })

    $centeredBox.Add_FontChanged({
        Update-CenteredTextBox $this
    })

    Update-CenteredTextBox $centeredBox
}

# ---- History card ----
$historyCard.Controls.Add($historyTitle)
$historyCard.Controls.Add($totalCountLabel)
$historyCard.Controls.Add($historySearch)
$historyCard.Controls.Add($historySearchHint)
$historyCard.Controls.Add($deleteHistoryButton)
$historyCard.Controls.Add($undoDeletePanel)
$historyCard.Controls.Add($historyGrid)

$historyAccent = New-Object System.Windows.Forms.Panel
$historyAccent.Location = New-Object System.Drawing.Point(20, 19)
$historyAccent.Size = New-Object System.Drawing.Size(4, 24)
$historyCard.Controls.Add($historyAccent)

$historyTitle.Location = New-Object System.Drawing.Point(34, 18)
$historyTitle.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 15)

$totalCountLabel.AutoSize = $false
$totalCountLabel.Visible = $false
$totalCountLabel.Location = New-Object System.Drawing.Point(220, 18)
$totalCountLabel.Size = New-Object System.Drawing.Size(170, 28)
$totalCountLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
$totalCountLabel.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 11)
$customCountLabel.Visible = $false

$slotFilterButton = New-Object System.Windows.Forms.Button
$slotFilterButton.Text = ""
$slotFilterButton.Location = New-Object System.Drawing.Point(405, 17)
$slotFilterButton.Size = New-Object System.Drawing.Size(500, 30)
$slotFilterButton.Visible = $false
$historyCard.Controls.Add($slotFilterButton)

$stateFilterPanel = New-Object System.Windows.Forms.Panel
$stateFilterPanel.Location = New-Object System.Drawing.Point(310, 55)
$stateFilterPanel.Size = New-Object System.Drawing.Size(845, 32)
$stateFilterPanel.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$historyCard.Controls.Add($stateFilterPanel)

$stateFilterButtons = @{}
$stateFilterSpecs = @(
    @("Все", 0, 68),
    @("Не подтверждены", 74, 122),
    @("Подтверждены", 202, 112),
    @("Передано", 320, 94),
    @("Переназначить", 420, 122),
    @("Отказ", 548, 78)
)

foreach ($spec in $stateFilterSpecs) {
    $name = [string]$spec[0]
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $name
    $button.Tag = $name
    $button.Location = New-Object System.Drawing.Point([int]$spec[1], 0)
    $button.Size = New-Object System.Drawing.Size([int]$spec[2], 32)
    $button.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
    $stateFilterPanel.Controls.Add($button)
    $stateFilterButtons[$name] = $button
}

# Поиск находится прямо под заголовком "Актуальные сделки".
$historySearchShell = New-Object System.Windows.Forms.Panel
$historySearchShell.Location = New-Object System.Drawing.Point(20, 54)
$historySearchShell.Size = New-Object System.Drawing.Size(274, 34)
$historySearchShell.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$historyCard.Controls.Add($historySearchShell)

$historySearch.Location = New-Object System.Drawing.Point(12, 7)
$historySearch.Size = New-Object System.Drawing.Size(248, 20)
$historySearch.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$historySearch.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Left
$historySearchShell.Controls.Add($historySearch)

$historySearchHint.Visible = $false
$historySearchHint.Location = New-Object System.Drawing.Point(1, 1)
$historySearchHint.Size = New-Object System.Drawing.Size(272, 32)
$historySearchHint.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter

$exportButton.Visible = $false

# Красная минималистичная кнопка без проблемного emoji-шрифта.
$deleteHistoryButton.Location = New-Object System.Drawing.Point(310, 53)
$deleteHistoryButton.Size = New-Object System.Drawing.Size(44, 35)
$deleteHistoryButton.Text = ""
$deleteHistoryButton.Enabled = $true
$deleteHistoryButton.Visible = $false
$deleteHistoryButton.UseVisualStyleBackColor = $false

$undoDeletePanel.Location = New-Object System.Drawing.Point(370, 52)
$undoDeletePanel.Size = New-Object System.Drawing.Size(330, 37)

$undoDeleteInfo.Location = New-Object System.Drawing.Point(12, 4)
$undoDeleteInfo.Size = New-Object System.Drawing.Size(205, 29)
$undoDeleteInfo.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$undoDeleteAction.Location = New-Object System.Drawing.Point(220, 3)
$undoDeleteAction.Size = New-Object System.Drawing.Size(104, 31)
$undoDeleteAction.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

$deleteHistoryButton.Add_Paint({
    $g = $_.Graphics
    $pen = New-Object System.Drawing.Pen($deleteHistoryButton.ForeColor, 1.6)

    try {
        $cx = [int]($deleteHistoryButton.ClientSize.Width / 2)
        $top = 8

        # lid
        $g.DrawLine($pen, $cx - 8, $top + 3, $cx + 8, $top + 3)
        $g.DrawLine($pen, $cx - 4, $top, $cx + 4, $top)

        # body
        $g.DrawRectangle($pen, $cx - 6, $top + 6, 12, 13)

        # inner slots
        $g.DrawLine($pen, $cx - 2, $top + 9, $cx - 2, $top + 16)
        $g.DrawLine($pen, $cx + 2, $top + 9, $cx + 2, $top + 16)
    } finally {
        $pen.Dispose()
    }
})

$historyGrid.Location = New-Object System.Drawing.Point(20, 100)
$historyGrid.Size = New-Object System.Drawing.Size(1135, 138)
$historyGrid.Anchor = "Top,Bottom,Left,Right"

# Сделки читаются лучше без горизонтального визуального шума.
$historyGrid.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$historyGrid.CellBorderStyle = [System.Windows.Forms.DataGridViewCellBorderStyle]::SingleHorizontal
$historyGrid.ColumnHeadersBorderStyle = [System.Windows.Forms.DataGridViewHeaderBorderStyle]::None
$historyGrid.RowTemplate.Height = 28
$historyGrid.ColumnHeadersHeight = 32
$historyGrid.ColumnHeadersHeightSizeMode = [System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode]::DisableResizing
$historyGrid.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical

# Чуть больше ширины важным колонкам.
$historyGrid.AutoSizeColumnsMode = [System.Windows.Forms.DataGridViewAutoSizeColumnsMode]::Fill

$historyGrid.Columns["CreatedAt"].FillWeight = 150
$historyGrid.Columns["ConsultationDate"].FillWeight = 100
$historyGrid.Columns["Slot"].FillWeight = 80
$historyGrid.Columns["ID"].FillWeight = 105
$historyGrid.Columns["Confirmation"].FillWeight = 80
$historyGrid.Columns["Handoff"].FillWeight = 150
$historyGrid.Columns["Status"].FillWeight = 110

# Текст подсказки поиска выглядит как placeholder, а не как отдельный элемент.
$historySearchHint.Text = ""
$historySearchHint.Font = New-Object System.Drawing.Font("Segoe UI", 9)

# Панели должны находиться под дочерними элементами.
$headerCard.SendToBack()
$mainPagePanel.SendToBack()
$dealsPagePanel.SendToBack()
$plannerCard.SendToBack()
$mainTableCard.SendToBack()
$mainMessageCard.SendToBack()
$historyCard.SendToBack()
$dealsHandoffCard.SendToBack()
$dealsTimelineCard.SendToBack()
$actionCard.SendToBack()

# Тонкие линии по краям ключевых карточек — спокойнее, чем стандартный FixedSingle.
$mainTableTopLine = New-Object System.Windows.Forms.Panel
$mainTableTopLine.Dock = [System.Windows.Forms.DockStyle]::Top
$mainTableTopLine.Height = 1
$mainTableCard.Controls.Add($mainTableTopLine)

$mainMessageTopLine = New-Object System.Windows.Forms.Panel
$mainMessageTopLine.Dock = [System.Windows.Forms.DockStyle]::Top
$mainMessageTopLine.Height = 1
$mainMessageCard.Controls.Add($mainMessageTopLine)

$dealsHandoffTopLine = New-Object System.Windows.Forms.Panel
$dealsHandoffTopLine.Dock = [System.Windows.Forms.DockStyle]::Top
$dealsHandoffTopLine.Height = 1
$dealsHandoffCard.Controls.Add($dealsHandoffTopLine)

$dealsTimelineTopLine = New-Object System.Windows.Forms.Panel
$dealsTimelineTopLine.Dock = [System.Windows.Forms.DockStyle]::Top
$dealsTimelineTopLine.Height = 1
$dealsTimelineCard.Controls.Add($dealsTimelineTopLine)

# ==================== Theme ====================

$script:uiFontCache = @{}
$script:centeredTextShells = @{}

function Get-CachedUiFont(
    [string]$family,
    [single]$size,
    [System.Drawing.FontStyle]$style = [System.Drawing.FontStyle]::Regular
) {
    $key = "{0}|{1:0.0}|{2}" -f $family, $size, [int]$style

    if (-not $script:uiFontCache.ContainsKey($key)) {
        $script:uiFontCache[$key] = New-Object System.Drawing.Font($family, $size, $style)
    }

    return $script:uiFontCache[$key]
}


function New-CenteredTextLayout(
    [System.Windows.Forms.TextBox]$box,
    [System.Windows.Forms.Control]$parent
) {
    if ($null -eq $box -or $null -eq $parent) {
        return $null
    }

    $originalLocation = $box.Location
    $originalSize = $box.Size

    # Keep the exact outer geometry of the existing field.
    $shell = New-Object System.Windows.Forms.Panel
    $shell.Location = $originalLocation
    $shell.Size = $originalSize
    $shell.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $shell.Padding = New-Object System.Windows.Forms.Padding(1)
    $shell.TabStop = $false

    $shell.Add_Paint({
        param($sender, $e)

        $darkNow = ([string]$script:settings.Theme -eq "Dark")
        $paletteNow = Get-UiPalette $darkNow
        $pen = New-Object System.Drawing.Pen($paletteNow.Border)

        try {
            $e.Graphics.DrawRectangle(
                $pen,
                0,
                0,
                [Math]::Max(0, $sender.ClientSize.Width - 1),
                [Math]::Max(0, $sender.ClientSize.Height - 1)
            )
        } finally {
            $pen.Dispose()
        }
    })

    # 50% free space / native TextBox height / 50% free space.
    # This gives real vertical centering using normal WinForms layout.
    $layout = New-Object System.Windows.Forms.TableLayoutPanel
    $layout.Dock = [System.Windows.Forms.DockStyle]::Fill
    $layout.Margin = New-Object System.Windows.Forms.Padding(0)
    $layout.Padding = New-Object System.Windows.Forms.Padding(0)
    $layout.ColumnCount = 1
    $layout.RowCount = 3
    $layout.BackColor = [System.Drawing.Color]::Transparent

    [void]$layout.ColumnStyles.Add(
        (New-Object System.Windows.Forms.ColumnStyle(
            [System.Windows.Forms.SizeType]::Percent,
            100
        ))
    )

    [void]$layout.RowStyles.Add(
        (New-Object System.Windows.Forms.RowStyle(
            [System.Windows.Forms.SizeType]::Percent,
            50
        ))
    )
    [void]$layout.RowStyles.Add(
        (New-Object System.Windows.Forms.RowStyle(
            [System.Windows.Forms.SizeType]::AutoSize
        ))
    )
    [void]$layout.RowStyles.Add(
        (New-Object System.Windows.Forms.RowStyle(
            [System.Windows.Forms.SizeType]::Percent,
            50
        ))
    )

    $parent.Controls.Add($shell)
    $shell.Controls.Add($layout)

    # Important: this is still the ORIGINAL normal TextBox.
    $layout.Controls.Add($box, 0, 1)

    $box.Multiline = $false
    $box.AutoSize = $true
    $box.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    $box.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center
    $box.Dock = [System.Windows.Forms.DockStyle]::Fill
    $box.Margin = New-Object System.Windows.Forms.Padding(4, 0, 4, 0)

    return $shell
}

function Update-CenteredTextBox([System.Windows.Forms.TextBox]$box) {
    if ($null -eq $box) {
        return
    }

    $textValue = [string]$box.Text
    $baseSize = [single]9.0
    $minSize = [single]7.5
    $targetSize = $baseSize

    $availableWidth = [Math]::Max(24, $box.ClientSize.Width - 4)

    if (-not [string]::IsNullOrWhiteSpace($textValue)) {
        $measureFont = Get-CachedUiFont "Segoe UI" $baseSize
        $measured = [System.Windows.Forms.TextRenderer]::MeasureText(
            $textValue,
            $measureFont,
            (New-Object System.Drawing.Size(10000, 100)),
            [System.Windows.Forms.TextFormatFlags]::NoPadding
        ).Width

        if ($measured -gt $availableWidth -and $measured -gt 0) {
            $scaled = $baseSize * ($availableWidth / [double]$measured)
            $targetSize = [single](
                [Math]::Max(
                    $minSize,
                    [Math]::Floor($scaled * 2.0) / 2.0
                )
            )
        }
    }

    $box.Font = Get-CachedUiFont "Segoe UI" $targetSize
    $box.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center

    if ($null -ne $box.Parent) {
        $box.Parent.PerformLayout()
    }
}

function Install-CenteredTextBoxShell(
    [System.Windows.Forms.TextBox]$box,
    [System.Windows.Forms.Control]$parent
) {
    $shell = New-CenteredTextLayout $box $parent

    if ($null -ne $shell) {
        $box.Add_TextChanged({
            Update-CenteredTextBox $this
        })
        $box.Add_FontChanged({
            if ($null -ne $this.Parent) {
                $this.Parent.PerformLayout()
            }
        })

        Update-CenteredTextBox $box
    }

    return $shell
}

function Update-DateStyleTextFieldLayout(
    [System.Windows.Forms.Panel]$shell,
    [System.Windows.Forms.TextBox]$box
) {
    if ($null -eq $shell -or $null -eq $box) {
        return
    }

    $box.Font = Get-CachedUiFont "Segoe UI" 9
    $box.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center

    if ($null -ne $box.Parent) {
        $box.Parent.PerformLayout()
    }
}

function Install-DateStyleTextField(
    [System.Windows.Forms.TextBox]$box,
    [System.Windows.Forms.Control]$parent
) {
    $shell = New-CenteredTextLayout $box $parent

    if ($null -ne $shell) {
        $box.Font = Get-CachedUiFont "Segoe UI" 9
        $box.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center

        $box.Add_TextChanged({
            if ($null -ne $this.Parent) {
                $this.Parent.PerformLayout()
            }
        })

        Update-DateStyleTextFieldLayout $shell $box
    }

    return $shell
}

function Get-UiPalette([bool]$dark) {
    if ($dark) {
        return @{
            Bg = [System.Drawing.Color]::FromArgb(10, 14, 22)
            Card = [System.Drawing.Color]::FromArgb(16, 23, 36)
            CardAlt = [System.Drawing.Color]::FromArgb(20, 29, 45)
            Input = [System.Drawing.Color]::FromArgb(24, 34, 52)
            Border = [System.Drawing.Color]::FromArgb(45, 64, 96)
            Text = [System.Drawing.Color]::FromArgb(242, 245, 249)
            Muted = [System.Drawing.Color]::FromArgb(150, 165, 188)
            Accent = [System.Drawing.Color]::FromArgb(72, 128, 255)
            AccentHover = [System.Drawing.Color]::FromArgb(96, 149, 255)
            Success = [System.Drawing.Color]::FromArgb(48, 197, 110)
            Warning = [System.Drawing.Color]::FromArgb(255, 176, 32)
            Danger = [System.Drawing.Color]::FromArgb(239, 83, 80)
            Selected = [System.Drawing.Color]::FromArgb(46, 90, 170)
        }
    }

    return @{
        Bg = [System.Drawing.Color]::FromArgb(244, 247, 251)
        Card = [System.Drawing.Color]::White
        CardAlt = [System.Drawing.Color]::FromArgb(249, 251, 254)
        Input = [System.Drawing.Color]::White
        Border = [System.Drawing.Color]::FromArgb(217, 224, 234)
        Text = [System.Drawing.Color]::FromArgb(28, 34, 44)
        Muted = [System.Drawing.Color]::FromArgb(104, 114, 128)
        Accent = [System.Drawing.Color]::FromArgb(58, 120, 242)
        AccentHover = [System.Drawing.Color]::FromArgb(75, 133, 245)
        Success = [System.Drawing.Color]::FromArgb(35, 164, 90)
        Warning = [System.Drawing.Color]::FromArgb(213, 137, 0)
        Danger = [System.Drawing.Color]::FromArgb(214, 66, 66)
        Selected = [System.Drawing.Color]::FromArgb(218, 231, 255)
    }
}

function Set-FlatButtonStyle($button, $palette) {
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.UseVisualStyleBackColor = $false
    $button.FlatAppearance.BorderSize = 1
    $button.FlatAppearance.BorderColor = $palette.Border
    $button.FlatAppearance.MouseOverBackColor = $palette.Selected
    $button.FlatAppearance.MouseDownBackColor = $palette.Accent
    $button.BackColor = $palette.CardAlt
    $button.ForeColor = $palette.Text
    $button.Cursor = $(if ($button.Enabled) {
        [System.Windows.Forms.Cursors]::Hand
    } else {
        [System.Windows.Forms.Cursors]::Default
    })
}

function Update-ButtonStateStyles {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    foreach ($button in @(
        $createButton,
        $copyMessageButton,
        $copyLinkButton,
        $openButton,
        $confirmDealButton,
        $handoffDoneButton,
        $reassignDealButton,
        $refuseDealButton,
        $clearDecisionButton,
        $copySheetsButton,
        $clipboardImportButton
    )) {
        if ($null -eq $button) {
            continue
        }

        if (-not $button.Enabled) {
            $button.BackColor = $palette.Input
            $button.ForeColor = $palette.Muted
            $button.FlatAppearance.BorderColor = $palette.Border
            $button.FlatAppearance.MouseOverBackColor = $palette.Input
            $button.FlatAppearance.MouseDownBackColor = $palette.Input
            $button.Cursor = [System.Windows.Forms.Cursors]::Default
        } else {
            $button.Cursor = [System.Windows.Forms.Cursors]::Hand
        }
    }

    # Завершённая передача остаётся визуально читаемой даже в disabled-состоянии.
    if (
        $null -ne $script:selectedHistoryRecord -and
        [string]$script:selectedHistoryRecord.HandoffStatus -eq "Передано"
    ) {
        $handoffDoneButton.BackColor = $palette.CardAlt
        $handoffDoneButton.ForeColor = $palette.Success
        $handoffDoneButton.FlatAppearance.BorderColor = $palette.Success

        $confirmDealButton.BackColor = $palette.CardAlt
        $confirmDealButton.ForeColor = $palette.Accent
        $confirmDealButton.FlatAppearance.BorderColor = $palette.Accent
    }
}

function Apply-ThemeToControl($control, [bool]$dark, $palette) {
    if ($control -is [System.Windows.Forms.DataGridView]) {
        $control.BackgroundColor = $palette.Card
        $control.GridColor = $palette.Border
        $control.DefaultCellStyle.BackColor = $palette.Card
        $control.DefaultCellStyle.ForeColor = $palette.Text
        $control.DefaultCellStyle.SelectionBackColor = $palette.Selected
        $control.DefaultCellStyle.SelectionForeColor = $palette.Text
        $control.DefaultCellStyle.Font = Get-CachedUiFont "Segoe UI" 9
        $control.DefaultCellStyle.Padding = New-Object System.Windows.Forms.Padding(4, 0, 4, 0)
        $control.DefaultCellStyle.Alignment = [System.Windows.Forms.DataGridViewContentAlignment]::MiddleLeft
        $control.AlternatingRowsDefaultCellStyle.BackColor = $palette.CardAlt
        $control.ColumnHeadersDefaultCellStyle.BackColor = $palette.CardAlt
        $control.ColumnHeadersDefaultCellStyle.ForeColor = $palette.Muted
        $control.ColumnHeadersDefaultCellStyle.Font = Get-CachedUiFont "Segoe UI Semibold" 9
        $control.EnableHeadersVisualStyles = $false
        return
    }

    if ($control -is [System.Windows.Forms.TabControl]) {
        $control.BackColor = $palette.Card
        $control.ForeColor = $palette.Text
        $control.Padding = New-Object System.Drawing.Point(12, 6)
    }
    elseif ($control -is [System.Windows.Forms.TabPage]) {
        $control.BackColor = $palette.Card
        $control.ForeColor = $palette.Text
        $control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    }
    elseif ($control -is [System.Windows.Forms.TextBox]) {
        $control.BackColor = $palette.Input
        $control.ForeColor = $palette.Text
        $control.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
    }
    elseif ($control -is [System.Windows.Forms.ComboBox] -or
            $control -is [System.Windows.Forms.DateTimePicker] -or
            $control -is [System.Windows.Forms.NumericUpDown]) {
        $control.BackColor = $palette.Input
        $control.ForeColor = $palette.Text
    }
    elseif ($control -is [System.Windows.Forms.Button]) {
        Set-FlatButtonStyle $control $palette
    }
    elseif ($control -is [System.Windows.Forms.GroupBox]) {
        $control.BackColor = $palette.Card
        $control.ForeColor = $palette.Muted
    }
    elseif ($control -is [System.Windows.Forms.Panel]) {
        $control.BackColor = $palette.Card
        $control.ForeColor = $palette.Text
    }
    else {
        $control.BackColor = $palette.Card
        $control.ForeColor = $palette.Text
    }

    foreach ($child in $control.Controls) {
        Apply-ThemeToControl $child $dark $palette
    }
}

function Set-HistorySearchPlaceholder {
    if (-not [string]::IsNullOrWhiteSpace($historySearch.Text)) {
        return
    }

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $script:historySearchPlaceholderActive = $true
    $historySearch.ForeColor = $palette.Muted
    $historySearch.Text = "Поиск по ID"
    $historySearch.SelectionStart = 0
    $historySearch.SelectionLength = 0
}

function Clear-HistorySearchPlaceholder {
    if ($script:historySearchPlaceholderActive) {
        $script:historySearchPlaceholderActive = $false
        $historySearch.Clear()
    }

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark
    $historySearch.ForeColor = $palette.Text
}

function Get-AppPageName {
    return [string]$script:appPage
}

function Update-AppPageStyles {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    foreach ($button in @($mainPageButton,$dealsPageButton)) {
        Set-FlatButtonStyle $button $palette
        $button.BackColor = $palette.Input
        $button.ForeColor = $palette.Muted
        $button.FlatAppearance.BorderSize = 0
        $button.Font = New-Object System.Drawing.Font("Segoe UI", 9.5)
    }

    if ([string]$script:appPage -eq "Deals") {
        $selectedPageButton = $dealsPageButton
    } else {
        $selectedPageButton = $mainPageButton
    }

    $selectedPageButton.BackColor = $palette.Selected
    $selectedPageButton.ForeColor = $palette.Text
    $selectedPageButton.FlatAppearance.BorderSize = 1
    $selectedPageButton.FlatAppearance.BorderColor = $palette.Accent
    $selectedPageButton.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9.5)
}

function Set-AppPage([string]$page) {
    if ($page -ne "Deals") {
        $page = "Main"
    }

    $script:appPage = $page

    $mainPagePanel.Visible = ($page -eq "Main")
    $dealsPagePanel.Visible = ($page -eq "Deals")

    if ($mainPagePanel.Visible) {
        $mainPagePanel.BringToFront()
    } else {
        $dealsPagePanel.BringToFront()
    }

    # Шапка всегда остаётся поверх страницы.
    $headerCard.BringToFront()
    Update-AppPageStyles

    if (-not $script:restoringUiState) {
        Save-UiState
    }
}

function Get-WorkTabName {
    if ($workTabs.SelectedTab -eq $handoffTab) { return "Handoff" }
    if ($workTabs.SelectedTab -eq $googleTab) { return "Google" }
    if ($workTabs.SelectedTab -eq $historyTab) { return "History" }
    return "Message"
}

function Save-UiState {
    if ($script:restoringUiState) { return }
    $script:settings.LastDate = $datePicker.Value.ToString("dd.MM.yyyy")
    $script:settings.LastSlotFilter = [string]$script:slotFilter
    $script:settings.LastStateFilter = [string]$script:stateFilter
    $script:settings.LastSelectedId = $(if ($null -ne $script:selectedHistoryRecord) { [string]$script:selectedHistoryRecord.ID } else { "" })
    $script:settings.LastWorkTab = Get-WorkTabName
    $script:settings.LastAppPage = Get-AppPageName
    Save-Settings $script:settings
}

function Restore-UiState {
    $script:restoringUiState = $true
    try {
        $today = (Get-MoscowNow).Date
        $savedDate = $null
        if (-not [string]::IsNullOrWhiteSpace([string]$script:settings.LastDate)) {
            try { $savedDate = [DateTime]::ParseExact([string]$script:settings.LastDate,"dd.MM.yyyy",$culture).Date } catch {}
        }
        if ($null -eq $savedDate -or $savedDate -lt $today) {
            $savedDate = $today
            $script:settings.LastSlotFilter = ""
            $script:settings.LastStateFilter = "Все"
            $script:settings.LastSelectedId = ""
        }
        $datePicker.Value = $savedDate
        $savedSlot = [string]$script:settings.LastSlotFilter
        if ($standardSlots -contains $savedSlot) { $script:slotFilter = $savedSlot } else { $script:slotFilter = $null }

        $savedState = [string]$script:settings.LastStateFilter
        if (@("Все","Не подтверждены","Подтверждены","Передано","Переназначить","Отказ") -contains $savedState) {
            $script:stateFilter = $savedState
        } else {
            $script:stateFilter = "Все"
        }

        Update-DateButtonStyles
        Update-SlotCounters
        Update-SlotFilterUi
        Update-StateFilterButtons
        Refresh-HistoryGrid
        Update-HandoffSummary
        $savedId = [string]$script:settings.LastSelectedId
        if (-not [string]::IsNullOrWhiteSpace($savedId)) {
            for ($i=0; $i -lt $historyGrid.Rows.Count; $i++) {
                $r=$historyGrid.Rows[$i].Tag
                if ($null -ne $r -and [string]$r.ID -eq $savedId) { Select-HistoryRow $i; break }
            }
        }
        switch ([string]$script:settings.LastWorkTab) {
            "Handoff" { $workTabs.SelectedTab = $handoffTab }
            "Google" { $workTabs.SelectedTab = $googleTab }
            "History" { $workTabs.SelectedTab = $historyTab }
            default { $workTabs.SelectedTab = $messageTab }
        }
        Update-WorkNavStyles

        $savedPage = [string]$script:settings.LastAppPage
        if ($savedPage -ne "Deals") {
            $savedPage = "Main"
        }

        Set-AppPage $savedPage
    } finally { $script:restoringUiState = $false }
}

function Update-WorkSectionVisibility {
    # Старые внутренние вкладки больше не переключают видимость.
    # На Главной одновременно видны Сообщение и Таблица.
    # На Сделках одновременно видны Передача и История.
    $messageContentPanel.Visible = $true
    $handoffContentPanel.Visible = $true
    $googleContentPanel.Visible = $true
    $timelineContentPanel.Visible = $true
}

function Update-WorkNavStyles {
    # Оставлено для совместимости со старыми вызовами.
    Update-WorkSectionVisibility
}

function Apply-Theme {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $form.BackColor = $palette.Bg
    $form.ForeColor = $palette.Text

    foreach ($control in $form.Controls) {
        Apply-ThemeToControl $control $dark $palette
    }

    # Карточки.
    foreach ($card in @(
        $headerCard,
        $plannerCard,
        $mainTableCard,
        $mainMessageCard,
        $historyCard,
        $dealsHandoffCard,
        $dealsTimelineCard
    )) {
        $card.BackColor = $palette.Card
    }

    $mainPagePanel.BackColor = $palette.Bg
    $dealsPagePanel.BackColor = $palette.Bg
    $pageNavPanel.BackColor = $palette.Input

    foreach ($accentLine in @(
        $plannerAccent,
        $googleAccent,
        $messageAccent,
        $historyAccent,
        $handoffCardAccent,
        $timelineAccent
    )) {
        $accentLine.BackColor = $palette.Accent
    }

    $plannerFooterLine.BackColor = $palette.Border

    foreach ($cardLine in @(
        $mainTableTopLine,
        $mainMessageTopLine,
        $dealsHandoffTopLine,
        $dealsTimelineTopLine
    )) {
        $cardLine.BackColor = $palette.Border
    }

    $handoffCardTitle.ForeColor = $palette.Text
    $handoffCardTitle.BackColor = $palette.Card

    # Заголовки секций.
    foreach ($label in @($plannerHeader,$actionHeader,$historyTitle,$title)) {
        $label.ForeColor = $palette.Text
    }

    if ($null -ne $plannerSubheader) {
        $plannerSubheader.ForeColor = $palette.Muted
        $plannerSubheader.BackColor = $palette.Card
    }

    $totalCountLabel.ForeColor = $palette.Accent
    $customCountLabel.Visible = $false

    $versionLabel.ForeColor = $palette.Text
    $versionLabel.BackColor = $palette.CardAlt
    $versionLabel.TextAlign = [System.Drawing.ContentAlignment]::MiddleCenter
    $shiftStatsLabel.ForeColor = $palette.Muted
    $shiftStatsLabel.BackColor = $palette.Card
    $themeLabel.ForeColor = $palette.Muted
    $historySearchShell.BackColor = $palette.Input
    $stateFilterPanel.BackColor = $palette.Card
    $historySearch.BackColor = $palette.Input
    if (-not $script:historySearchPlaceholderActive) { $historySearch.ForeColor = $palette.Text }

    $dateSelectButton.BackColor = $palette.CardAlt
    $dateSelectButton.ForeColor = $palette.Text
    $dateSelectButton.FlatAppearance.BorderColor = $palette.Border

    $customTimeShell.BackColor = $palette.CardAlt
    $customTimeText.BackColor = $palette.Input
    if ($script:isCustomTime) { $customTimeText.ForeColor = $palette.Text } else { $customTimeText.ForeColor = $palette.Text }

    $tableFieldFill = $(if ($dark) { $palette.Input } else { $palette.CardAlt })

    foreach ($centerShell in @(
        $clientPhoneShell,
        $parentNameShell,
        $studentNameShell,
        $childClassShell,
        $leadSourceShell
    )) {
        if ($null -ne $centerShell) {
            $centerShell.BackColor = $tableFieldFill
            $centerShell.Invalidate()
        }
    }

    foreach ($dateStyleShell in @($customTimeValueShell, $idValueShell)) {
        if ($null -ne $dateStyleShell) {
            $dateStyleShell.BackColor = $palette.CardAlt
            $dateStyleShell.Invalidate()
        }
    }

    foreach ($dateStyleBox in @($customTimeText, $idBox)) {
        if ($null -ne $dateStyleBox) {
            $dateStyleBox.BackColor = $palette.CardAlt
            $dateStyleBox.ForeColor = $palette.Text
            $dateStyleBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None
            $dateStyleBox.Font = Get-CachedUiFont "Segoe UI" 9
            $dateStyleBox.TextAlign = [System.Windows.Forms.HorizontalAlignment]::Center

            $shell = $(if ($dateStyleBox -eq $customTimeText) {
                $customTimeValueShell
            } else {
                $idValueShell
            })

            if ($null -ne $shell) {
                Update-DateStyleTextFieldLayout $shell $dateStyleBox
            }
        }
    }

    foreach ($centerBox in @(
        $clientPhoneBox,
        $parentNameBox,
        $studentNameBox,
        $childClassBox,
        $leadSourceBox
    )) {
        if ($null -ne $centerBox) {
            $centerBox.BackColor = $tableFieldFill
            $centerBox.ForeColor = $palette.Text
            $centerBox.BorderStyle = [System.Windows.Forms.BorderStyle]::None
            Update-CenteredTextBox $centerBox
        }
    }

    $studentLabel.BringToFront()
    $classLabel.BringToFront()
    $sourceLabel.BringToFront()

    $customInfo.ForeColor = $palette.Muted
    $previewTitle.ForeColor = $palette.Muted
    $previewTitle.BackColor = $palette.Card
    $previewBox.BackColor = $palette.CardAlt
    $previewBox.ForeColor = $palette.Text

    $workNavPanel.BackColor = $palette.Card
    $workContentHost.BackColor = $palette.Card
    $messageContentPanel.BackColor = $palette.Card
    $handoffContentPanel.BackColor = $palette.Card
    $googleContentPanel.BackColor = $palette.Card
    $timelineContentPanel.BackColor = $palette.Card
    $timelineTitle.BackColor = $palette.Card
    $timelineTitle.ForeColor = $palette.Text
    $timelineDealLabel.BackColor = $palette.Card
    $timelineDealLabel.ForeColor = $palette.Muted
    $googleStateHint.BackColor = $palette.Card
    $googleStateHint.ForeColor = $palette.Muted
    $timelineList.BackColor = $palette.CardAlt
    $timelineList.ForeColor = $palette.Text

    $messageBox.BackColor = $palette.Input
    $messageBox.ForeColor = $palette.Text

    $handoffGroup.BackColor = $palette.Card

    foreach ($metricPanel in @(
        $handoffTotalPanel,
        $handoffConfirmedPanel,
        $handoffPassedPanel,
        $handoffReassignStatPanel,
        $handoffRefuseStatPanel
    )) {
        $metricPanel.BackColor = $palette.CardAlt
    }

    foreach ($metricTitle in @($handoffTotalTitle,$handoffConfirmedTitle,$handoffPassedTitle)) {
        $metricTitle.BackColor = $palette.CardAlt
        $metricTitle.ForeColor = $palette.Muted
    }

    $handoffTotalValue.BackColor = $palette.CardAlt
    $handoffTotalValue.ForeColor = $palette.Text
    $handoffConfirmedValue.BackColor = $palette.CardAlt
    $handoffConfirmedValue.ForeColor = $palette.Accent
    $handoffPassedValue.BackColor = $palette.CardAlt
    $handoffPassedValue.ForeColor = $palette.Success
    $handoffSummaryLabel.ForeColor = $palette.Muted
    $handoffDueLabel.ForeColor = $palette.Muted
    $handoffOutcomeSummaryLabel.ForeColor = $palette.Muted
    $handoffOutcomeSummaryLabel.BackColor = $palette.Card
    $handoffGroupTitle.ForeColor = $palette.Muted
    $handoffGroupTitle.BackColor = $palette.Card

    $handoffReassignStatLabel.BackColor = $palette.CardAlt
    $handoffReassignStatLabel.ForeColor = $palette.Warning
    $handoffRefuseStatLabel.BackColor = $palette.CardAlt
    $handoffRefuseStatLabel.ForeColor = $palette.Danger

    $mvlTagValue.ForeColor = $palette.Accent
    $googleFormatLabel.ForeColor = $palette.Muted

    $workTabs.BackColor = $palette.Card
    $workTabs.ForeColor = $palette.Text

    foreach ($tp in $workTabs.TabPages) {
        $tp.BackColor = $palette.Card
        $tp.ForeColor = $palette.Text
        $tp.UseVisualStyleBackColor = $false
        $tp.BorderStyle = [System.Windows.Forms.BorderStyle]::None
    }

    Update-WorkNavStyles
    Update-AppPageStyles

    foreach ($picker in @($datePicker,$customTimePicker)) {
        try {
            $picker.CalendarMonthBackground = $palette.Card
            $picker.CalendarForeColor = $palette.Text
            $picker.CalendarTitleBackColor = $palette.Accent
            $picker.CalendarTitleForeColor = [System.Drawing.Color]::White
            $picker.CalendarTrailingForeColor = $palette.Muted
        } catch {}
    }

    # API.
    if ($apiStatus.Text -like "*доступен*") {
        $apiStatus.ForeColor = $palette.Success
    }

    # Выбранная тема.
    Set-FlatButtonStyle $lightButton $palette
    Set-FlatButtonStyle $darkButton $palette

    if ($dark) {
        $darkButton.BackColor = $palette.Selected
        $darkButton.FlatAppearance.BorderColor = $palette.Accent
    } else {
        $lightButton.BackColor = $palette.Selected
        $lightButton.FlatAppearance.BorderColor = $palette.Accent
    }

    # Кнопки действий.
    foreach ($button in @($createButton,$copyMessageButton,$copyLinkButton,$openButton,
                          $confirmDealButton,$handoffDoneButton,$copySheetsButton,
                          $deleteHistoryButton,$settingsButton,$refreshApi,$dateSelectButton,$slotFilterButton,
                          $reassignDealButton,$refuseDealButton,$clearDecisionButton,
                          $clipboardImportButton)) {
        Set-FlatButtonStyle $button $palette
    }

    Set-FlatButtonStyle $dateSelectButton $palette
    $dateSelectButton.BackColor = $palette.CardAlt
    $dateSelectButton.ForeColor = $palette.Text
    $dateSelectButton.FlatAppearance.BorderColor = $palette.Border

    $createButton.BackColor = $palette.Accent
    $createButton.ForeColor = [System.Drawing.Color]::White
    $createButton.FlatAppearance.BorderColor = $palette.Accent
    $createButton.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    $deleteHistoryButton.FlatAppearance.BorderSize = 1
    $deleteHistoryButton.FlatAppearance.BorderColor = $palette.Danger
    $deleteHistoryButton.ForeColor = $palette.Danger
    $deleteHistoryButton.BackColor = $palette.CardAlt
    $deleteHistoryButton.FlatAppearance.MouseOverBackColor = $palette.Card
    $deleteHistoryButton.FlatAppearance.MouseDownBackColor = $palette.Selected

    $historyContextMenu.BackColor = $palette.CardAlt
    $historyContextMenu.ForeColor = $palette.Text
    $undoDeletePanel.BackColor = $palette.CardAlt
    $undoDeleteInfo.BackColor = $palette.CardAlt
    $undoDeleteInfo.ForeColor = $palette.Text

    Set-FlatButtonStyle $undoDeleteAction $palette
    $undoDeleteAction.BackColor = $palette.Accent
    $undoDeleteAction.ForeColor = [System.Drawing.Color]::White
    $undoDeleteAction.FlatAppearance.BorderColor = $palette.Accent
    $undoDeleteAction.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    Set-FlatButtonStyle $slotFilterButton $palette
    $slotFilterButton.BackColor = $palette.CardAlt
    $slotFilterButton.ForeColor = $palette.Muted
    $slotFilterButton.FlatAppearance.BorderSize = 1
    $slotFilterButton.FlatAppearance.BorderColor = $palette.Border
    $slotFilterButton.FlatAppearance.MouseOverBackColor = $palette.Selected

    Update-HandoffActionStyles

    $copyMessageButton.BackColor = $palette.Accent
    $copyMessageButton.ForeColor = [System.Drawing.Color]::White
    $copyMessageButton.FlatAppearance.BorderColor = $palette.Accent
    $copyMessageButton.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    foreach ($secondary in @($copyLinkButton,$openButton)) {
        $secondary.BackColor = $palette.CardAlt
        $secondary.ForeColor = $palette.Text
        $secondary.FlatAppearance.BorderColor = $palette.Border
    }

    $copySheetsButton.BackColor = $palette.Accent
    $copySheetsButton.ForeColor = [System.Drawing.Color]::White
    $copySheetsButton.FlatAppearance.BorderColor = $palette.Accent
    $copySheetsButton.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    Update-CreateButtonStyles
    Update-DateButtonStyles
    Update-TimeStyles
    Update-IdHistoryInfo
    Update-WorkNavStyles
    Update-ButtonStateStyles

    # Системная строка заголовка теперь тоже следует теме приложения.
    Set-NativeTitleBarTheme $form $dark
}

# ==================== UI state ====================

function Update-CreateButtonStyles {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    Set-FlatButtonStyle $createButton $palette
    $createButton.Text = "СОЗДАТЬ КОМНАТУ"
    $createButton.BackColor = $palette.Accent
    $createButton.ForeColor = [System.Drawing.Color]::White
    $createButton.FlatAppearance.BorderColor = $palette.Accent
    $createButton.FlatAppearance.MouseOverBackColor = $palette.AccentHover
}

function Show-DateCalendar {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $popup = New-Object System.Windows.Forms.Form
    $popup.Text = "Выбор даты"
    $popup.StartPosition = "CenterParent"
    $popup.FormBorderStyle = "FixedToolWindow"
    $popup.MaximizeBox = $false
    $popup.MinimizeBox = $false
    $popup.Size = New-Object System.Drawing.Size(280, 245)
    $popup.BackColor = $palette.Card
    $popup.ForeColor = $palette.Text

    $calendar = New-Object System.Windows.Forms.MonthCalendar
    $calendar.Location = New-Object System.Drawing.Point(18, 16)
    $calendar.MaxSelectionCount = 1
    $calendar.SelectionStart = $datePicker.Value.Date
    $calendar.SelectionEnd = $datePicker.Value.Date
    $calendar.CalendarDimensions = New-Object System.Drawing.Size(1,1)
    $popup.Controls.Add($calendar)

    $calendar.Add_DateSelected({
        $datePicker.Value = $_.Start.Date
        $popup.Close()
    })

    Set-NativeTitleBarTheme $popup $dark
    [void]$popup.ShowDialog($form)
}

function Apply-CustomTimeText {
    $value = $customTimeText.Text.Trim()

    try {
        $parsed = [DateTime]::ParseExact($value, "HH:mm", $culture)
        Set-SelectedTime $parsed.ToString("HH:mm") $true
        return $true
    } catch {
        if ($script:selectedTime -ne $null) {
            $customTimeText.Text = $script:selectedTime
        }
        return $false
    }
}

function Update-DateButtonStyles {
    $today = (Get-MoscowNow).Date
    $selected = $datePicker.Value.Date
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    foreach ($b in @($todayButton, $tomorrowButton, $otherDateButton)) {
        Set-FlatButtonStyle $b $palette
    }

    if ($selected -eq $today) {
        $todayButton.BackColor = $palette.Selected
        $todayButton.FlatAppearance.BorderColor = $palette.Accent
    } elseif ($selected -eq $today.AddDays(1)) {
        $tomorrowButton.BackColor = $palette.Selected
        $tomorrowButton.FlatAppearance.BorderColor = $palette.Accent
    } else {
        $otherDateButton.BackColor = $palette.Selected
        $otherDateButton.FlatAppearance.BorderColor = $palette.Accent
    }
}

function Update-TimeStyles {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    foreach ($btn in $slotButtons) {
        Set-FlatButtonStyle $btn $palette
        $btn.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 9)

        if ([string]$btn.Tag -eq $script:selectedTime -and -not $script:isCustomTime) {
            $btn.BackColor = $palette.Selected
            $btn.FlatAppearance.BorderColor = $palette.Accent
        }
    }

    Set-FlatButtonStyle $customButton $palette

    foreach ($b in @($minus30,$minus15,$plus15,$plus30)) {
        Set-FlatButtonStyle $b $palette
    }

    if ($script:isCustomTime) {
        $customButton.BackColor = $palette.Accent
        $customButton.ForeColor = [System.Drawing.Color]::White
        $customButton.FlatAppearance.BorderColor = $palette.Accent
        $customButton.FlatAppearance.MouseOverBackColor = $palette.AccentHover

        $customTimeText.ReadOnly = $false
        $customTimeText.ForeColor = $palette.Text
        $customTimeShell.BackColor = $palette.CardAlt
    } else {
        $customButton.BackColor = $palette.CardAlt
        $customButton.ForeColor = $palette.Text
        $customButton.FlatAppearance.BorderColor = $palette.Border

        $customTimeText.ReadOnly = $true
        $customTimeText.ForeColor = $palette.Text
        $customTimeShell.BackColor = $palette.CardAlt
    }


    $customInfo.Visible = $false
}

function Set-SelectedTime([string]$time, [bool]$custom) {
    $script:selectedTime = $time
    $script:isCustomTime = $custom

    try {
        $customTimePicker.Value = [DateTime]::ParseExact($time, "HH:mm", $culture)
    } catch {}

    if ($null -ne $customTimeText) {
        $customTimeText.Text = $time
    }

    $idBox.Enabled = $true
    Update-TimeStyles
    Update-Preview
    Update-CreateEnabled

    # Выбор времени больше не меняет рабочую вкладку.
    # Пользователь остаётся в текущем контексте.

    if (-not (Apply-ClipboardDealId)) {
        Focus-IdInput
    }
}

function Shift-Time([int]$minutes) {
    if ($script:selectedTime -eq $null) {
        Set-SelectedTime "11:00" $true
    }

    try {
        $dt = [DateTime]::ParseExact($script:selectedTime, "HH:mm", $culture)
        $newTime = $dt.AddMinutes($minutes).ToString("HH:mm")
        Set-SelectedTime $newTime $true
    } catch {
        Show-Error "Не удалось изменить время."
    }
}

function Focus-IdInput([bool]$selectAll = $false) {
    if (-not $idBox.Enabled) {
        return
    }

    $form.Activate()
    $idBox.Focus()

    if ($selectAll -and -not [string]::IsNullOrWhiteSpace($idBox.Text)) {
        $idBox.SelectAll()
    } else {
        $idBox.SelectionStart = $idBox.Text.Length
        $idBox.SelectionLength = 0
    }
}

function Test-AmoPlaceholderValue([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value)) {
        return $true
    }

    $v = $value.Trim()

    return (
        $v -eq "..." -or
        $v -eq "Выбрать" -or
        $v -eq "—" -or
        $v -eq "-" -or
        $v -eq "Нет данных"
    )
}

function Get-NextAmoValue($lines, [int]$startIndex, [int]$maxLookAhead = 6) {
    $last = [Math]::Min($lines.Count - 1, $startIndex + $maxLookAhead)

    for ($i = $startIndex + 1; $i -le $last; $i++) {
        $candidate = ([string]$lines[$i]).Trim()

        if ([string]::IsNullOrWhiteSpace($candidate)) {
            continue
        }

        if (Test-AmoPlaceholderValue $candidate) {
            continue
        }

        return $candidate
    }

    return ""
}

function Get-ExactAmoFieldValue($lines, [string[]]$labels, [int]$maxLookAhead = 6) {
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $current = ([string]$lines[$i]).Trim()

        foreach ($label in $labels) {
            if ($current.Equals($label, [System.StringComparison]::OrdinalIgnoreCase)) {
                return (Get-NextAmoValue $lines $i $maxLookAhead)
            }

            $escaped = [regex]::Escape($label)

            if ($current -match ("(?i)^\s*" + $escaped + "\s*[:\-–—]\s*(.+?)\s*$")) {
                $value = $matches[1].Trim()

                if (-not (Test-AmoPlaceholderValue $value)) {
                    return $value
                }
            }
        }
    }

    return ""
}

function Get-DirectAmoFieldValue($lines, [string[]]$labels, [int]$maxLookAhead = 2) {
    # Для имени нельзя "прыгать" через несколько полей.
    # Иначе при пустом поле ученика amoCRM мог подставить следующий статус
    # вроде "Готов к консультации".
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $current = ([string]$lines[$i]).Trim()

        foreach ($label in $labels) {
            if (-not $current.Equals($label, [System.StringComparison]::OrdinalIgnoreCase)) {
                continue
            }

            $last = [Math]::Min($lines.Count - 1, $i + $maxLookAhead)

            for ($j = $i + 1; $j -le $last; $j++) {
                $candidate = ([string]$lines[$j]).Trim()

                if ([string]::IsNullOrWhiteSpace($candidate)) {
                    continue
                }

                if (Test-AmoPlaceholderValue $candidate) {
                    return ""
                }

                return $candidate
            }

            return ""
        }
    }

    return ""
}

function Test-AmoPersonValue([string]$value) {
    if ([string]::IsNullOrWhiteSpace($value) -or (Test-AmoPlaceholderValue $value)) {
        return $false
    }

    $v = $value.Trim()

    if ($v -match '(?i)^(готов(?:а|о)?\s+к\s+консультации|консультация\s+подтверждена|не\s+подтверждено|подтверждено|передано|создано|обновлено|переназначить|отказ|ученик|родитель|выбрать|да|нет|егэ|огэ|поле|поля|формы?|заявка|консультация|консультации|профориентация|профориентации|источник|класс)$') {
        return $false
    }

    if ($v -match '^\d+$') {
        return $false
    }

    return ($v -match '^[А-Яа-яЁёA-Za-z][А-Яа-яЁёA-Za-z\-\s]{1,59}$')
}

function Get-AmoContactName($lines) {
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $current = ([string]$lines[$i]).Trim()

        if (-not $current.Equals("Контакт", [System.StringComparison]::OrdinalIgnoreCase)) {
            continue
        }

        # В реальном копировании amoCRM после "Контакт" может идти:
        # Выбрать / Сергей / Сергей / [WABA]... / ...
        # Берём первое осмысленное имя до следующего технического блока.
        $last = [Math]::Min($lines.Count - 1, $i + 12)

        for ($j = $i + 1; $j -le $last; $j++) {
            $candidate = ([string]$lines[$j]).Trim()

            if ([string]::IsNullOrWhiteSpace($candidate) -or
                (Test-AmoPlaceholderValue $candidate)) {
                continue
            }

            if ($candidate -match '^\[WABA\]' -or
                $candidate -eq "Компания" -or
                $candidate -eq "Раб. тел." -or
                $candidate -eq "Телефон") {
                continue
            }

            # Имя/ФИО: буквы, пробел, дефис; без длинных служебных фраз.
            if ($candidate -match '^[А-Яа-яЁёA-Za-z][А-Яа-яЁёA-Za-z\-\s]{1,60}$') {
                return $candidate
            }
        }
    }

    return ""
}

function Get-AmoSourceFromTitle($lines) {
    foreach ($line in $lines) {
        $value = ([string]$line).Trim()

        # Пример:
        # Автосделка: Заявка MAX Булат 10 мес.
        if ($value -match '(?i)^Автосделка:\s*Заявка\s+([^\s]+)') {
            return $matches[1].Trim()
        }
    }

    return ""
}

function Get-AmoStudentFromTitle($lines, [string]$source) {
    foreach ($line in $lines) {
        $value = ([string]$line).Trim()

        if ($value -match '(?i)^Автосделка:\s*Заявка\s+([^\s]+)\s+([А-Яа-яЁёA-Za-z\-]+)') {
            $titleSource = $matches[1].Trim()
            $candidate = $matches[2].Trim()

            if (
                ([string]::IsNullOrWhiteSpace($source) -or
                 $titleSource.Equals($source, [System.StringComparison]::OrdinalIgnoreCase)) -and
                (Test-AmoPersonValue $candidate)
            ) {
                return $candidate
            }
        }
    }

    return ""
}

function Normalize-ClientPhone([string]$phone) {
    if ([string]::IsNullOrWhiteSpace($phone)) {
        return ""
    }

    # Оставляем только цифры:
    # +7 918 467-71-13 -> 79184677113
    # 8 950 062-88-16 -> 79500628816
    $digits = [regex]::Replace($phone, '\D', '')

    if ([string]::IsNullOrWhiteSpace($digits)) {
        return ""
    }

    # Российский номер через 8 приводим к формату 7XXXXXXXXXX.
    if ($digits.Length -eq 11 -and $digits.StartsWith("8")) {
        $digits = "7" + $digits.Substring(1)
    }

    return $digits
}

function Parse-AmoClipboard([string]$raw) {
    if ([string]::IsNullOrWhiteSpace($raw)) {
        return $null
    }

    # PowerShell НЕ экранирует обратный слеш как C#/Python.
    # Regex должен получать именно \r?\n, \d, \s — с ОДНИМ слешем.
    $lines = @($raw -split "\r?\n")

    # --- ID ---
    $id = ""

    $idMatch = [regex]::Match($raw, '(?m)^\s*#(\d{6,10})\s*$')
    if ($idMatch.Success) {
        $id = $idMatch.Groups[1].Value
    }

    if ([string]::IsNullOrWhiteSpace($id)) {
        $id = Get-ExactAmoFieldValue $lines @("ID сделки","Айди","ID") 3

        if ($id -match '#?(\d{6,10})') {
            $id = $matches[1]
        }
    }

    # --- Класс ---
    # В вашем формате есть ровно:
    # Класс
    # 9
    $class = Get-ExactAmoFieldValue $lines @("Класс") 3

    if ($class -match '(\d{1,2})') {
        $class = $matches[1]
    }

    # --- Телефон ---
    # В вашем формате:
    # Раб. тел.
    # 8 950 062-88-16
    $phone = Get-ExactAmoFieldValue $lines @(
        "Раб. тел.",
        "Раб. тел",
        "Телефончик",
        "Телефон клиента",
        "Телефон",
        "Phone"
    ) 4

    if ([string]::IsNullOrWhiteSpace($phone)) {
        $phoneMatch = [regex]::Match(
            $raw,
            '(?<!\d)(?:\+7|8)[\s\-\(\)]*\d{3}[\s\-\(\)]*\d{3}[\s\-]*\d{2}[\s\-]*\d{2}(?!\d)'
        )

        if ($phoneMatch.Success) {
            $phone = $phoneMatch.Value.Trim()
        }
    }

    # Всегда приводим телефон к цифровому виду для таблицы.
    $phone = Normalize-ClientPhone $phone

    # --- Источник ---
    $source = Get-ExactAmoFieldValue $lines @(
        "Источник сделки",
        "Источник",
        "Что за лид"
    ) 4

    if ([string]::IsNullOrWhiteSpace($source)) {
        $source = Get-AmoSourceFromTitle $lines
    }

    # --- Ученик ---
    # Не используем одиночную метку "Ученик":
    # в amoCRM она часто является значением поля "Кто обратился".
    $student = Get-DirectAmoFieldValue $lines @(
        "КАК_ЗОВУТ_УЧЕНИКА_",
        "КАК ЗОВУТ УЧЕНИКА",
        "Имя ученика"
    ) 2

    if (-not (Test-AmoPersonValue $student)) {
        $student = ""
    }

    # Если отдельное поле имени пустое, пробуем взять имя из заголовка:
    # "Автосделка: Заявка MAX Булат 10 мес." -> "Булат".
    if ([string]::IsNullOrWhiteSpace($student)) {
        $titleStudent = Get-AmoStudentFromTitle $lines $source

        if (Test-AmoPersonValue $titleStudent) {
            $student = $titleStudent
        }
    }

    # --- Родитель / контакт ---
    # Одиночное "Родитель" тоже бывает значением поля роли,
    # поэтому ищем только явные поля имени родителя.
    $parent = Get-DirectAmoFieldValue $lines @(
        "Имя родителя",
        "ФИО родителя"
    ) 2

    if (-not (Test-AmoPersonValue $parent)) {
        $parent = ""
    }

    $role = Get-ExactAmoFieldValue $lines @(
        "Родитель / ученик",
        "Кто обратился"
    ) 4

    $contactName = Get-AmoContactName $lines

    # Если amoCRM сообщает, что контакт — родитель,
    # первое имя из блока "Контакт" считаем именем родителя.
    if ([string]::IsNullOrWhiteSpace($parent) -and
        $role -match '(?i)родител' -and
        (Test-AmoPersonValue $contactName)) {
        $parent = $contactName
    }

    # Если контакт — ученик, используем имя контакта только когда отдельное
    # поле ученика не заполнено.
    if ([string]::IsNullOrWhiteSpace($student) -and
        $role -match '(?i)ученик' -and
        (Test-AmoPersonValue $contactName)) {
        $student = $contactName
    }

    $recognized = 0
    foreach ($value in @($id,$phone,$parent,$student,$class,$source)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            $recognized++
        }
    }

    if ($recognized -eq 0) {
        return $null
    }

    # Для автоматического импорта считаем профильными данными
    # телефон/родителя/ученика/класс/источник.
    $profileCount = 0
    foreach ($value in @($phone,$parent,$student,$class,$source)) {
        if (-not [string]::IsNullOrWhiteSpace([string]$value)) {
            $profileCount++
        }
    }

    return [pscustomobject]@{
        ID = [string]$id
        ClientPhone = [string]$phone
        ParentName = [string]$parent
        StudentName = [string]$student
        ChildClass = [string]$class
        LeadSource = [string]$source
        Recognized = $recognized
        LabeledCount = $profileCount
    }
}

function Apply-AmoDataToRecord($record,$data) {
    if($null -eq $record -or $null -eq $data){return 0}
    $count=0
    foreach($pair in @(@("ClientPhone","ClientPhone"),@("ParentName","ParentName"),@("StudentName","StudentName"),@("ChildClass","ChildClass"),@("LeadSource","LeadSource"))){
        $rp=$pair[0];$dp=$pair[1];$value=[string]$data.$dp

        if($rp -eq "ClientPhone"){
            $value = Normalize-ClientPhone $value
        }

        if($rp -eq "StudentName" -or $rp -eq "ParentName"){
            if(-not [string]::IsNullOrWhiteSpace($value) -and -not (Test-AmoPersonValue $value)){
                $value = ""
            }

            $existingPerson = [string]$record.$rp
            if(
                [string]::IsNullOrWhiteSpace($value) -and
                -not [string]::IsNullOrWhiteSpace($existingPerson) -and
                -not (Test-AmoPersonValue $existingPerson)
            ){
                $record.$rp = ""
                $count++
            }
        }

        if(-not [string]::IsNullOrWhiteSpace($value)){ $record.$rp=$value.Trim();$count++ }
    }
    Save-CurrentHistory
    if($null -ne $script:selectedHistoryRecord -and [string]$script:selectedHistoryRecord.ID -eq [string]$record.ID){Update-WorkflowPanel $record}
    return $count
}

function Import-AmoClipboard([bool]$silent=$false) {
    try{$raw=[string](Get-Clipboard -Raw -ErrorAction Stop)}catch{if(-not $silent){Show-Info "Не удалось прочитать буфер обмена."};return $false}
    if([string]::IsNullOrWhiteSpace($raw)){if(-not $silent){Show-Info "Буфер обмена пуст."};return $false}
    $data=Parse-AmoClipboard $raw
    if($null -eq $data){
        if(-not $silent){
            Show-Info "Не удалось распознать данные amoCRM.`r`nСкопируйте карточку целиком — поддерживается формат с #ID, «Класс», «Раб. тел.», «Контакт» и заголовком «Автосделка: Заявка ...»."
        }
        return $false
    }
    if($silent -and $data.LabeledCount -eq 0){return $false}
    $record=$null
    if(-not [string]::IsNullOrWhiteSpace([string]$data.ID)){$record=Find-LatestHistoryById ([string]$data.ID)}
    if($null -eq $record -and $null -ne $script:selectedHistoryRecord -and -not (Is-ArchivedRecord $script:selectedHistoryRecord)){$record=Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)}
    if($null -eq $record){$script:pendingAmoData=$data;if(-not [string]::IsNullOrWhiteSpace([string]$data.ID)){$script:clipboardDealIdCandidate=[string]$data.ID;[void](Apply-ClipboardDealId)};if(-not $silent){Show-Info "Данные распознаны. Они применятся после создания комнаты с этим ID."};return $true}
    Clear-HistorySearchPlaceholder;$historySearch.Text=[string]$record.ID;Refresh-HistoryGrid
    $updated=Find-LatestHistoryById ([string]$record.ID);$count=Apply-AmoDataToRecord $updated $data
    if($count -gt 0){Add-WorkflowAudit $updated "Данные amoCRM из буфера"}
    if(-not $silent){
        Set-AppPage "Main"
        $parts = @()
        if(-not [string]::IsNullOrWhiteSpace([string]$data.ClientPhone)){ $parts += "телефон" }
        if(-not [string]::IsNullOrWhiteSpace([string]$data.ParentName)){ $parts += "родитель" }
        if(-not [string]::IsNullOrWhiteSpace([string]$data.StudentName)){ $parts += "ученик" }
        if(-not [string]::IsNullOrWhiteSpace([string]$data.ChildClass)){ $parts += "класс" }
        if(-not [string]::IsNullOrWhiteSpace([string]$data.LeadSource)){ $parts += "источник" }

        Notify-Success "amoCRM: " + ($parts -join ", ")
    }

    return ($count -gt 0)
}

function Apply-PendingAmoData([string]$id) {
    if($null -eq $script:pendingAmoData){return}
    $pendingId=[string]$script:pendingAmoData.ID
    if(-not [string]::IsNullOrWhiteSpace($pendingId) -and $pendingId -ne $id){return}
    $record=Find-LatestHistoryById $id;if($null -eq $record){return}
    $count=Apply-AmoDataToRecord $record $script:pendingAmoData
    if($count -gt 0){Add-WorkflowAudit $record "Данные amoCRM из буфера"}
    $script:pendingAmoData=$null
}

function Detect-ClipboardContent {
    try{$raw=[string](Get-Clipboard -Raw -ErrorAction Stop)}catch{return}
    if([string]::IsNullOrWhiteSpace($raw)){return}
    $signature=[Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($raw))
    if($signature -eq $script:lastClipboardSignature){return}
    $script:lastClipboardSignature=$signature
    if(Import-AmoClipboard $true){return}
    Detect-ClipboardDealId
}

function Get-ClipboardDealId {
    try {
        $value = [string](Get-Clipboard -Raw -ErrorAction Stop)
        $value = $value.Trim()

        # Текущие amoCRM ID — короткие цифровые номера.
        # Верхняя граница 10 цифр специально не захватывает обычные номера телефонов.
        if ($value -match '^\d{6,10}$') {
            return $value
        }
    } catch {}

    return $null
}

function Apply-ClipboardDealId {
    if (-not [string]::IsNullOrWhiteSpace($idBox.Text)) {
        return $false
    }

    $candidate = [string]$script:clipboardDealIdCandidate

    if ([string]::IsNullOrWhiteSpace($candidate)) {
        $candidate = Get-ClipboardDealId
    }

    if ([string]::IsNullOrWhiteSpace($candidate)) {
        return $false
    }

    $script:clipboardDealIdCandidate = $candidate

    if (-not $idBox.Enabled) {
        return $false
    }

    $idBox.Text = $candidate
    $script:clipboardDealIdCandidate = $null
    Focus-IdInput
    return $true
}

function Detect-ClipboardDealId {
    $candidate = Get-ClipboardDealId

    if ([string]::IsNullOrWhiteSpace($candidate)) {
        return
    }

    $script:clipboardDealIdCandidate = $candidate
    [void](Apply-ClipboardDealId)
}

function Update-CreateEnabled {
    # Кнопка остаётся визуально активной и контрастной.
    # Валидность ID/времени проверяется внутри Invoke-MeetingCreate.
    $createButton.Enabled = $true
}

function Update-Preview {
    $date = $datePicker.Value.ToString("dd.MM.yyyy")

    if ($script:selectedTime -eq $null -or $idBox.Text -notmatch '^\d+$') {
        $previewBox.Text = "Дата: $date`r`nВремя и ID ещё не выбраны"
        return
    }

    $id = $idBox.Text.Trim()
    $end = Get-EndTime $script:selectedTime

    $mappedRoom = Find-RoomMapById $id
    if ($null -ne $mappedRoom) {
        $roomState = "комната уже существует"
    } else {
        $roomState = "комната будет создана"
    }

    $timeCaption = "Слот"
    if ($script:isCustomTime) {
        $timeCaption = "Нестандартно"
    }

    $previewBox.Text = "Дата: $date`r`n$($timeCaption): $($script:selectedTime)–$end    •    ID: $id    •    $roomState"
}

function Update-IdHistoryInfo {
    $id = $idBox.Text.Trim()
    $dark = ([string]$script:settings.Theme -eq "Dark")

    if ($id -notmatch '^\d+$') {
        $idHistoryLabel.Text = ""
        return
    }

    $record = Find-LatestHistoryById $id

    if ($null -eq $record) {
        $idHistoryLabel.Text = "Ранее не создавалась"
        $idHistoryLabel.ForeColor = [System.Drawing.Color]::ForestGreen
    } else {
        $mapped = Find-RoomMapById $id

        if ($null -ne $mapped) {
            $idHistoryLabel.Text = "Ранее: $($record.CreatedAt) • $($record.ConsultationDate) $($record.Slot) • ссылка сохранена"
        } else {
            $idHistoryLabel.Text = "Ранее: $($record.CreatedAt) • $($record.ConsultationDate) $($record.Slot) • старая ссылка"
        }

        $idHistoryLabel.ForeColor = [System.Drawing.Color]::DarkOrange
    }
}

function Update-SlotCounters {
    $date = $datePicker.Value.ToString("dd.MM.yyyy")

    # Начиная с v6.4 $script:history содержит только актуальную запись по каждому ID.
    $currentForDate = @(
        $script:history |
        Where-Object { $_.ConsultationDate -eq $date }
    )

    foreach ($btn in $slotButtons) {
        $slot = [string]$btn.Tag

        $count = @(
            $currentForDate |
            Where-Object { Test-TimeInSlotBucket $_.Slot $slot }
        ).Count

        $btn.Text = "$slot → $(Get-EndTime $slot)`r`n($count)"
    }

    $customCount = @(
        $currentForDate |
        Where-Object { -not (Is-StandardTime $_.Slot) }
    ).Count

        $totalCountLabel.Text = "Всего сделок: $($currentForDate.Count)"
    Update-SlotFilterUi
}

function Get-ConsultationDateTime($record) {
    try {
        return [DateTime]::ParseExact(
            "$($record.ConsultationDate) $($record.Slot)",
            "dd.MM.yyyy HH:mm",
            $culture
        )
    } catch {
        return $null
    }
}

function Get-HandoffDue($record) {
    $dt = Get-ConsultationDateTime $record
    if ($null -eq $dt) {
        return $null
    }
    return $dt.AddMinutes(-30)
}

function Get-HandoffDueDisplayText($record) {
    $due = Get-HandoffDue $record

    if ($null -eq $due) {
        return "Должно быть в таблице: —"
    }

    $now = Get-MoscowNow
    $deltaMinutes = [int][Math]::Ceiling(($due - $now).TotalMinutes)

    if ($deltaMinutes -gt 0) {
        $relativeText = "через $deltaMinutes мин"
    }
    elseif ($deltaMinutes -lt 0) {
        $minutesAgo = [Math]::Abs($deltaMinutes)
        $relativeText = "$minutesAgo мин назад"
    }
    else {
        $relativeText = "сейчас"
    }

    return "Должно быть в таблице: $($due.ToString('HH:mm')) МСК • $relativeText"
}

function Update-HandoffDueLabel($record) {
    if ($null -eq $record) {
        $handoffDueLabel.Text = "Должно быть в таблице: —"
        return
    }

    $handoffDueLabel.Text = Get-HandoffDueDisplayText $record
}

function Get-WorkflowState($record) {
    if ([string]$record.DecisionStatus -eq "ПЕРЕНАЗНАЧИТЬ") {
        if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionTag)) {
            return "Переназначить · $($record.DecisionTag)"
        }
        return "Переназначить"
    }

    if ([string]$record.DecisionStatus -eq "ОТКАЗ ОТ ДИАГНОСТИКИ") {
        if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionTag)) {
            return "Отказ · $($record.DecisionTag)"
        }
        return "Отказ"
    }

    if ([string]$record.HandoffStatus -eq "Передано") {
        return "Передано"
    }

    if ([string]$record.ConfirmationStatus -ne "Подтверждено") {
        return "Не подтверждено"
    }

    $due = Get-HandoffDue $record
    if ($null -eq $due) {
        return "Подтверждено"
    }

    if ((Get-MoscowNow) -ge $due) {
        return "К передаче"
    }

    return "Подтверждено"
}

function Test-RecordStateFilter($record, [string]$filter) {
    if ($null -eq $record) {
        return $false
    }

    switch ($filter) {
        "Не подтверждены" {
            return (
                [string]$record.ConfirmationStatus -ne "Подтверждено" -and
                [string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)
            )
        }
        "Подтверждены" {
            return (
                [string]$record.ConfirmationStatus -eq "Подтверждено" -and
                [string]$record.HandoffStatus -ne "Передано"
            )
        }
        "Передано" {
            return ([string]$record.HandoffStatus -eq "Передано")
        }
        "Переназначить" {
            return ([string]$record.DecisionStatus -eq "ПЕРЕНАЗНАЧИТЬ")
        }
        "Отказ" {
            return ([string]$record.DecisionStatus -eq "ОТКАЗ ОТ ДИАГНОСТИКИ")
        }
        default {
            return $true
        }
    }
}

function Update-StateFilterButtons {
    if ($null -eq $stateFilterButtons) {
        return
    }

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark
    $dateText = $datePicker.Value.ToString("dd.MM.yyyy")

    $scope = @(
        $script:history |
        Where-Object {
            $_.ConsultationDate -eq $dateText -and
            (
                [string]::IsNullOrWhiteSpace([string]$script:slotFilter) -or
                (Test-TimeInSlotBucket $_.Slot ([string]$script:slotFilter))
            )
        }
    )

    foreach ($name in @("Все","Не подтверждены","Подтверждены","Передано","Переназначить","Отказ")) {
        $button = $stateFilterButtons[$name]
        if ($null -eq $button) { continue }

        Set-FlatButtonStyle $button $palette

        if ($name -eq "Все") {
            $count = $scope.Count
        } else {
            $count = @($scope | Where-Object { Test-RecordStateFilter $_ $name }).Count
        }

        $caption = switch ($name) {
            "Не подтверждены" { "Не подтв." }
            "Подтверждены" { "Подтв." }
            default { $name }
        }

        $button.Text = "$caption  $count"

        if ([string]$script:stateFilter -eq $name) {
            $button.BackColor = $palette.Selected
            $button.ForeColor = $palette.Text
            $button.FlatAppearance.BorderSize = 1
            $button.FlatAppearance.BorderColor = $palette.Accent
            $button.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 8.5)
        } else {
            $button.BackColor = $palette.Card
            $button.ForeColor = $palette.Muted
            $button.FlatAppearance.BorderSize = 0
            $button.Font = New-Object System.Drawing.Font("Segoe UI", 8.5)
        }
    }
}

function Set-StateFilter([string]$filter) {
    $allowed = @("Все","Не подтверждены","Подтверждены","Передано","Переназначить","Отказ")
    if ($allowed -notcontains $filter) {
        $filter = "Все"
    }

    $script:stateFilter = $filter
    Update-StateFilterButtons
    Update-SlotFilterUi
    Refresh-HistoryGrid
    Save-UiState
}

function Update-SlotFilterUi {
    if ($null -eq $slotFilterButton) {
        return
    }

    $parts = @()

    if (-not [string]::IsNullOrWhiteSpace([string]$script:slotFilter)) {
        $parts += "$($script:slotFilter)–$(Get-EndTime ([string]$script:slotFilter))"
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$script:stateFilter) -and
        [string]$script:stateFilter -ne "Все") {
        $parts += [string]$script:stateFilter
    }

    if ($parts.Count -eq 0) {
        $slotFilterButton.Visible = $false
        return
    }

    $slotFilterButton.Text = "Фильтр: " + ($parts -join " · ") + "   ×"
    $slotFilterButton.Visible = $true
}

function Clear-HistoryFilters {
    $script:slotFilter = $null
    $script:stateFilter = "Все"

    Update-SlotFilterUi
    Update-StateFilterButtons
    Refresh-HistoryGrid
    Update-HandoffSummary
    Save-UiState
}

function Set-SlotFilter([string]$slot) {
    $script:slotFilter = $slot
    Update-SlotFilterUi
    Refresh-HistoryGrid
    Update-HandoffSummary
    Save-UiState

    # Refresh-HistoryGrid уже выбирает и активирует первую сделку.
    # Если сделок нет — правая панель останется в пустом состоянии.
}

function Clear-SlotFilter {
    $script:slotFilter = $null
    Update-SlotFilterUi
    Refresh-HistoryGrid
    Update-HandoffSummary
    Save-UiState
}

function Move-HistorySelection([int]$delta) {
    if ($historyGrid.Rows.Count -eq 0) {
        return
    }

    $current = -1
    if ($historyGrid.SelectedRows.Count -gt 0) {
        $current = $historyGrid.SelectedRows[0].Index
    }

    if ($current -lt 0) {
        $target = $(if ($delta -ge 0) { 0 } else { $historyGrid.Rows.Count - 1 })
    } else {
        $target = [Math]::Max(
            0,
            [Math]::Min($historyGrid.Rows.Count - 1, $current + $delta)
        )
    }

    Select-HistoryRow $target
}

function Refresh-ActionTimeline($record) {
    $timelineList.Items.Clear()

    if ($null -eq $record) {
        $timelineDealLabel.Text = "Выберите сделку выше"
        [void]$timelineList.Items.Add("Выберите сделку выше")
        return
    }

    $timelineDealLabel.Text="ID $($record.ID) • $($record.ConsultationDate) $($record.Slot)"

    try {
        $items=@(
            Get-AuditHistory |
            Where-Object {
                [string]$_.ID -eq [string]$record.ID -and
                [string]$_.Status -notlike "Звонок #*"
            }
        )
        if ($items.Count -eq 0) { [void]$timelineList.Items.Add("У этой сделки пока нет действий"); return }
        foreach ($item in @($items | Select-Object -Last 30)) {
            $stamp=[string]$item.CreatedAt; $displayTime=$stamp
            try { $dt=[DateTime]::ParseExact($stamp,"dd.MM.yyyy HH:mm:ss",$culture); $displayTime=$dt.ToString("HH:mm") } catch {}
            [void]$timelineList.Items.Add("$displayTime — $([string]$item.Status)")
        }
        if ($timelineList.Items.Count -gt 0) { $timelineList.TopIndex=$timelineList.Items.Count-1 }
    } catch { [void]$timelineList.Items.Add("Не удалось прочитать историю действий") }
}

function Activate-HistoryRecord($record) {
    Refresh-ActionTimeline $record

    if ($null -eq $record) {
        Update-WorkflowPanel $null
        Update-ButtonStateStyles
        return
    }

    $script:lastUrl = [string]$record.URL
    $script:lastMessage = Build-Message $record.ConsultationDate $record.Slot $record.URL
    $messageBox.Text = $script:lastMessage

    $copyMessageButton.Enabled = $true
    $copyLinkButton.Enabled = $true
    $openButton.Enabled = $true

    if (Is-ArchivedRecord $record) {
        Update-WorkflowPanel $null
        $deleteHistoryButton.Enabled = $true
        Update-ButtonStateStyles
        return
    }

    Update-WorkflowPanel $record

    if (-not $script:restoringUiState) {
        Save-UiState
    }

    # Активация данных сделки больше не меняет вкладку сама по себе.
    # Так Refresh, фильтры, правый клик и clipboard не перебрасывают пользователя.
    Update-ButtonStateStyles
}

function Open-HandoffForSelectedRecord {
    if ($historyGrid.SelectedRows.Count -eq 0) {
        return
    }

    $record = $historyGrid.SelectedRows[0].Tag

    if ($null -eq $record -or (Is-ArchivedRecord $record)) {
        return
    }

    Set-AppPage "Deals"
}

function Select-HistoryRow([int]$index) {
    if ($historyGrid.Rows.Count -eq 0) {
        Update-WorkflowPanel $null
        return
    }

    $index = [Math]::Max(0, [Math]::Min($historyGrid.Rows.Count - 1, $index))

    $historyGrid.ClearSelection()
    $historyGrid.Rows[$index].Selected = $true

    if ($historyGrid.Rows[$index].Cells.Count -gt 0) {
        $historyGrid.CurrentCell = $historyGrid.Rows[$index].Cells[0]
    }

    try {
        $historyGrid.FirstDisplayedScrollingRowIndex = $index
    } catch {}

    # Важно: DataGridView может визуально выбрать первую строку ещё ДО того,
    # как мы успели записать объект сделки в Row.Tag. Поэтому не полагаемся
    # только на SelectionChanged и активируем запись явно.
    $record = $historyGrid.Rows[$index].Tag
    if ($null -ne $record) {
        Activate-HistoryRecord $record
    }
}

function Refresh-HistoryGrid {
    $historyGrid.Rows.Clear()
    $deleteHistoryButton.Enabled = $true

    $search = $(if ($script:historySearchPlaceholderActive) { "" } else { $historySearch.Text.Trim() })
    $selectedDateText = $datePicker.Value.ToString("dd.MM.yyyy")

    if ([string]::IsNullOrWhiteSpace($search)) {
        $items = @(
            $script:history | Where-Object {
                $_.ConsultationDate -eq $selectedDateText -and
                (
                    [string]::IsNullOrWhiteSpace([string]$script:slotFilter) -or
                    (Test-TimeInSlotBucket $_.Slot ([string]$script:slotFilter))
                ) -and
                (Test-RecordStateFilter $_ ([string]$script:stateFilter))
            }
        )
    } else {
        # Поиск по ID работает и по текущим, и по архивным сделкам.
        # Приоритет всегда у текущей сделки: если этот ID ещё есть в рабочей
        # history, архивный дубль с тем же ID не показываем.
        $activeMatches = @(
            $script:history |
            Where-Object {
                $_.ID -like "*$search*"
            }
        )

        $activeIds = @{}
        foreach ($activeRecord in $activeMatches) {
            $activeIds[[string]$activeRecord.ID] = $true
        }

        $archiveMatches = @(
            $script:archiveHistory |
            Where-Object {
                $_.ID -like "*$search*" -and
                -not $activeIds.ContainsKey([string]$_.ID)
            }
        )

        # Текущие сделки идут первыми; архив нужен только если активной
        # записи с таким ID уже нет.
        $items = @($activeMatches) + @($archiveMatches)
    }

    if ([string]::IsNullOrWhiteSpace($search)) {
        $items = @($items | Sort-Object Slot, ID)
    }

    foreach ($item in $items) {
        $archived = Is-ArchivedRecord $item
        $workflow = $(if ($archived) { "Архив" } else { Get-WorkflowState $item })
        $confirmation = $(if ([string]$item.ConfirmationStatus -eq "Подтверждено") { "Да" } else { "Нет" })
        $statusText = $(if ($archived) { "Архив" } else { [string]$item.Status })

        $idx = $historyGrid.Rows.Add(
            $item.CreatedAt,
            $item.ConsultationDate,
            $item.Slot,
            $item.ID,
            $confirmation,
            $workflow,
            $statusText
        )

        $row = $historyGrid.Rows[$idx]
        $row.Tag = $item

        if ($archived) {
            $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::DimGray
        }
        elseif ([string]$item.DecisionStatus -eq "ПЕРЕНАЗНАЧИТЬ") {
            $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 237, 190)
            $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
        elseif ([string]$item.DecisionStatus -eq "ОТКАЗ ОТ ДИАГНОСТИКИ") {
            $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::FromArgb(255, 218, 218)
            $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
        elseif ($workflow -eq "К передаче") {
            $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::Moccasin
            $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
        elseif ($workflow -eq "Передано") {
            $row.DefaultCellStyle.BackColor = [System.Drawing.Color]::Honeydew
            $row.DefaultCellStyle.ForeColor = [System.Drawing.Color]::Black
        }
    }

    # DataGridView сам визуально выделяет первую строку после Rows.Add().
    # Это выделение ненадёжно: SelectionChanged может сработать до присвоения Row.Tag.
    # В пакетном режиме делаем выбор сами ПОСЛЕ полной загрузки строк.
    if (-not [string]::IsNullOrWhiteSpace($search) -and
        $historyGrid.Rows.Count -gt 0) {
        # Тот же фикс, который уже используется для слот-фильтра:
        # DataGridView может визуально подсветить строку раньше, чем Row.Tag
        # готов. Поэтому после полной загрузки явно выбираем первую запись.
        Select-HistoryRow 0
    }
    elseif (
        (
            -not [string]::IsNullOrWhiteSpace([string]$script:slotFilter) -or
            [string]$script:stateFilter -ne "Все"
        ) -and
        [string]::IsNullOrWhiteSpace($search) -and
        $historyGrid.Rows.Count -gt 0
    ) {
        Select-HistoryRow 0
    }
    elseif ($historyGrid.Rows.Count -eq 0) {
        Update-WorkflowPanel $null
    }
}

function Update-ShiftStats {
    if ($null -eq $shiftStatsLabel) { return }
    $dateText = $datePicker.Value.ToString("dd.MM.yyyy")
    $scope=@($script:history | Where-Object { $_.ConsultationDate -eq $dateText -and ([string]::IsNullOrWhiteSpace([string]$script:slotFilter) -or (Test-TimeInSlotBucket $_.Slot ([string]$script:slotFilter))) })
    $confirmed=@(
        $scope |
        Where-Object {
            [string]$_.ConfirmationStatus -eq "Подтверждено" -and
            [string]$_.HandoffStatus -ne "Передано"
        }
    ).Count
    $passed=@($scope | Where-Object { [string]$_.HandoffStatus -eq "Передано" }).Count
    $reassigned=@($scope | Where-Object { [string]$_.DecisionStatus -eq "ПЕРЕНАЗНАЧИТЬ" }).Count
    $refused=@($scope | Where-Object { [string]$_.DecisionStatus -eq "ОТКАЗ ОТ ДИАГНОСТИКИ" }).Count
    $prefix=""
    if (-not [string]::IsNullOrWhiteSpace([string]$script:slotFilter)) { $prefix="$($script:slotFilter)–$(Get-EndTime ([string]$script:slotFilter)) • " }
    $shiftStatsLabel.Text = "${prefix}$($scope.Count) сделок • $confirmed подтв. • $passed перед. • $reassigned перен. • $refused отказ"
}

function Update-HandoffSummary {
    $selectedDateText = $datePicker.Value.ToString("dd.MM.yyyy")

    $scopeItems = @(
        $script:history |
        Where-Object {
            $_.ConsultationDate -eq $selectedDateText -and
            (
                [string]::IsNullOrWhiteSpace([string]$script:slotFilter) -or
                (Test-TimeInSlotBucket $_.Slot ([string]$script:slotFilter))
            )
        }
    )

    $confirmedItems = @(
        $scopeItems |
        Where-Object {
            [string]$_.ConfirmationStatus -eq "Подтверждено" -and
            [string]$_.HandoffStatus -ne "Передано"
        }
    )

    $passedItems = @(
        $scopeItems |
        Where-Object {
            [string]$_.HandoffStatus -eq "Передано"
        }
    )

    $reassignedItems = @(
        $scopeItems |
        Where-Object {
            [string]$_.DecisionStatus -eq "ПЕРЕНАЗНАЧИТЬ"
        }
    )

    $refusedItems = @(
        $scopeItems |
        Where-Object {
            [string]$_.DecisionStatus -eq "ОТКАЗ ОТ ДИАГНОСТИКИ"
        }
    )

    if ([string]::IsNullOrWhiteSpace([string]$script:slotFilter)) {
        $handoffSummaryLabel.Text = "Все сделки • $selectedDateText"
    } else {
        $handoffSummaryLabel.Text = "Слот $($script:slotFilter)–$(Get-EndTime ([string]$script:slotFilter)) • $selectedDateText"
    }

    $handoffTotalValue.Text = [string]$scopeItems.Count
    $handoffConfirmedValue.Text = [string]$confirmedItems.Count
    $handoffPassedValue.Text = [string]$passedItems.Count
    $handoffOutcomeSummaryLabel.Text = ""
    $handoffReassignStatLabel.Text = "Переназначить  $($reassignedItems.Count)"
    $handoffRefuseStatLabel.Text = "Отказ  $($refusedItems.Count)"
    Update-StateFilterButtons
    Update-ShiftStats
}

function Show-DecisionTagDialog([string]$decisionType) {
    $tags = @()

    if ($decisionType -eq "ПЕРЕНАЗНАЧИТЬ") {
        $tags = @(
            "игнор",
            "плохая связь",
            "не получается",
            "не дома",
            "реб не хочет",
            "сброс",
            "болеют"
        )
        $dialogTitle = "ПЕРЕНАЗНАЧИТЬ"
    } else {
        $tags = @(
            "реб не хочет",
            "без причины",
            "выбрали других",
            "бесплатники",
            "негатив"
        )
        $dialogTitle = "ОТКАЗ ОТ ДИАГНОСТИКИ"
    }

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $dialog = New-Object System.Windows.Forms.Form
    $dialog.Text = $dialogTitle
    $dialog.StartPosition = "CenterParent"
    $dialog.FormBorderStyle = "FixedDialog"
    $dialog.MaximizeBox = $false
    $dialog.MinimizeBox = $false
    $dialog.Size = New-Object System.Drawing.Size(410, 430)
    $dialog.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $dialog.BackColor = $palette.Card
    $dialog.ForeColor = $palette.Text
    Set-NativeTitleBarTheme $dialog $dark

    $title = New-Object System.Windows.Forms.Label
    $title.Text = "Выберите один тег"
    $title.Font = New-Object System.Drawing.Font("Segoe UI Semibold", 13)
    $title.AutoSize = $true
    $title.Location = New-Object System.Drawing.Point(24, 20)
    $title.ForeColor = $palette.Text
    $dialog.Controls.Add($title)

    $subtitle = New-Object System.Windows.Forms.Label
    $subtitle.Text = "Сделка: $([string]$script:selectedHistoryRecord.ID)"
    $subtitle.AutoSize = $true
    $subtitle.Location = New-Object System.Drawing.Point(24, 50)
    $subtitle.ForeColor = $palette.Muted
    $dialog.Controls.Add($subtitle)

    $radioButtons = @()
    $y = 88

    foreach ($tag in $tags) {
        $radio = New-Object System.Windows.Forms.RadioButton
        $radio.Text = $tag
        $radio.AutoSize = $true
        $radio.Location = New-Object System.Drawing.Point(28, $y)
        $radio.BackColor = $palette.Card
        $radio.ForeColor = $palette.Text
        $dialog.Controls.Add($radio)
        $radioButtons += $radio
        $y += 34
    }

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = "Отмена"
    $cancel.Location = New-Object System.Drawing.Point(150, 350)
    $cancel.Size = New-Object System.Drawing.Size(100, 38)
    Set-FlatButtonStyle $cancel $palette
    $dialog.Controls.Add($cancel)

    $apply = New-Object System.Windows.Forms.Button
    $apply.Text = "Применить"
    $apply.Location = New-Object System.Drawing.Point(265, 350)
    $apply.Size = New-Object System.Drawing.Size(105, 38)
    Set-FlatButtonStyle $apply $palette

    if ($decisionType -eq "ПЕРЕНАЗНАЧИТЬ") {
        $apply.BackColor = $palette.Warning
        $apply.ForeColor = [System.Drawing.Color]::Black
        $apply.FlatAppearance.BorderColor = $palette.Warning
    } else {
        $apply.BackColor = $palette.Danger
        $apply.ForeColor = [System.Drawing.Color]::White
        $apply.FlatAppearance.BorderColor = $palette.Danger
    }

    $dialog.Controls.Add($apply)

    $dialog.Tag = $null

    $cancel.Add_Click({
        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
        $dialog.Close()
    })

    $apply.Add_Click({
        $selected = $null

        foreach ($radio in $radioButtons) {
            if ($radio.Checked) {
                $selected = [string]$radio.Text
                break
            }
        }

        if ([string]::IsNullOrWhiteSpace($selected)) {
            [System.Windows.Forms.MessageBox]::Show(
                "Сначала выберите тег.",
                $dialogTitle,
                [System.Windows.Forms.MessageBoxButtons]::OK,
                [System.Windows.Forms.MessageBoxIcon]::Information
            ) | Out-Null
            return
        }

        $dialog.Tag = $selected
        $dialog.DialogResult = [System.Windows.Forms.DialogResult]::OK
        $dialog.Close()
    })

    $result = $dialog.ShowDialog($form)

    if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
        return [string]$dialog.Tag
    }

    return $null
}

function Set-PreConfirmDecision([string]$decisionType) {
    if ($null -eq $script:selectedHistoryRecord) {
        Show-Info "Сначала выберите сделку в списке."
        return
    }

    Save-WorkflowFields
    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)

    if ($null -eq $record) {
        return
    }

    if ([string]$record.ConfirmationStatus -eq "Подтверждено") {
        Show-Info "Сделка уже подтверждена. Сначала снимите подтверждение."
        return
    }

    $tag = Show-DecisionTagDialog $decisionType
    if ([string]::IsNullOrWhiteSpace($tag)) {
        return
    }

    $record.DecisionStatus = $decisionType
    $record.DecisionTag = $tag
    $record.DecisionAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm")

    # Такой исход несовместим с подтверждением/передачей.
    $record.ConfirmationStatus = ""
    $record.ConfirmedAt = ""
    $record.HandoffStatus = ""
    $record.HandoffAt = ""

    Add-WorkflowAudit $record "$decisionType · $tag"
    Save-CurrentHistory

    Refresh-HistoryGrid
    Update-SlotCounters
    Update-HandoffSummary

    $updated = Find-LatestHistoryById ([string]$record.ID)
    Update-WorkflowPanel $updated

    Notify-Success "${decisionType}: $tag"
}

function Clear-PreConfirmDecision {
    if ($null -eq $script:selectedHistoryRecord) {
        return
    }

    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)
    if ($null -eq $record) {
        return
    }

    if ([string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)) {
        return
    }

    $old = "$($record.DecisionStatus) · $($record.DecisionTag)"

    $record.DecisionStatus = ""
    $record.DecisionTag = ""
    $record.DecisionAt = ""

    Add-WorkflowAudit $record "Сброшен исход: $old"
    Save-CurrentHistory

    Refresh-HistoryGrid
    Update-HandoffSummary

    $updated = Find-LatestHistoryById ([string]$record.ID)
    Update-WorkflowPanel $updated
}

function Update-HandoffActionStyles {
    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    foreach ($button in @(
        $confirmDealButton,
        $handoffDoneButton,
        $reassignDealButton,
        $refuseDealButton,
        $clearDecisionButton
    )) {
        Set-FlatButtonStyle $button $palette
    }

    # Базовые цвета.
    $confirmDealButton.BackColor = $palette.CardAlt
    $confirmDealButton.ForeColor = $palette.Accent
    $confirmDealButton.FlatAppearance.BorderColor = $palette.Accent

    $handoffDoneButton.BackColor = $palette.CardAlt
    $handoffDoneButton.ForeColor = $palette.Success
    $handoffDoneButton.FlatAppearance.BorderColor = $palette.Success

    # Все три варианта до подтверждения выглядят как полноценные action-кнопки.
    $reassignDealButton.BackColor = $palette.Warning
    $reassignDealButton.ForeColor = [System.Drawing.Color]::Black
    $reassignDealButton.FlatAppearance.BorderColor = $palette.Warning
    $reassignDealButton.FlatAppearance.MouseOverBackColor = $palette.Warning

    $refuseDealButton.BackColor = $palette.Danger
    $refuseDealButton.ForeColor = [System.Drawing.Color]::White
    $refuseDealButton.FlatAppearance.BorderColor = $palette.Danger
    $refuseDealButton.FlatAppearance.MouseOverBackColor = $palette.Danger

    $clearDecisionButton.BackColor = $palette.CardAlt
    $clearDecisionButton.ForeColor = $palette.Muted
    $clearDecisionButton.FlatAppearance.BorderColor = $palette.Border

    if ($null -eq $script:selectedHistoryRecord) {
        return
    }

    $record = $script:selectedHistoryRecord
    $isConfirmed = ([string]$record.ConfirmationStatus -eq "Подтверждено")
    $decision = [string]$record.DecisionStatus

    if ($isConfirmed) {
        $confirmDealButton.BackColor = $palette.Accent
        $confirmDealButton.ForeColor = [System.Drawing.Color]::White
        $confirmDealButton.FlatAppearance.BorderColor = $palette.Accent

        if ([string]$record.HandoffStatus -ne "Передано") {
            $handoffDoneButton.BackColor = $palette.Success
            $handoffDoneButton.ForeColor = [System.Drawing.Color]::White
            $handoffDoneButton.FlatAppearance.BorderColor = $palette.Success
        } else {
            $handoffDoneButton.BackColor = $palette.CardAlt
            $handoffDoneButton.ForeColor = $palette.Success
            $handoffDoneButton.FlatAppearance.BorderColor = $palette.Success
        }

        return
    }

    if ([string]::IsNullOrWhiteSpace($decision)) {
        $confirmDealButton.BackColor = $palette.Accent
        $confirmDealButton.ForeColor = [System.Drawing.Color]::White
        $confirmDealButton.FlatAppearance.BorderColor = $palette.Accent
        return
    }

    if ($decision -eq "ПЕРЕНАЗНАЧИТЬ") {
        $reassignDealButton.BackColor = $palette.Warning
        $reassignDealButton.ForeColor = [System.Drawing.Color]::Black
        $reassignDealButton.FlatAppearance.BorderColor = $palette.Warning
    }
    elseif ($decision -eq "ОТКАЗ ОТ ДИАГНОСТИКИ") {
        $refuseDealButton.BackColor = $palette.Danger
        $refuseDealButton.ForeColor = [System.Drawing.Color]::White
        $refuseDealButton.FlatAppearance.BorderColor = $palette.Danger
    }
}

function Update-WorkflowPanel($record) {
    $script:selectedHistoryRecord = $record

    if ($null -eq $record) {
        $handoffGroup.Size = New-Object System.Drawing.Size(530, 174)
        $handoffSelectedLabel.Text = "Выберите сделку выше"
        $handoffSelectedLabel.Location = New-Object System.Drawing.Point(24, 2)

        $handoffDueLabel.Visible = $false
        $handoffStatusLabel.Visible = $false
        $confirmDealButton.Visible = $false
        $handoffDoneButton.Visible = $false
        $reassignDealButton.Visible = $false
        $refuseDealButton.Visible = $false
        $clearDecisionButton.Visible = $false

        $handoffSummaryLabel.Visible = $true
        $handoffSummaryLabel.Location = New-Object System.Drawing.Point(24, 40)
        $handoffTotalPanel.Visible = $true
        $handoffConfirmedPanel.Visible = $true
        $handoffPassedPanel.Visible = $true
        $handoffTotalPanel.Location = New-Object System.Drawing.Point(24, 66)
        $handoffConfirmedPanel.Location = New-Object System.Drawing.Point(190, 66)
        $handoffPassedPanel.Location = New-Object System.Drawing.Point(356, 66)
        $handoffOutcomeSummaryLabel.Visible = $false
        $handoffReassignStatPanel.Visible = $true
        $handoffRefuseStatPanel.Visible = $true
        $handoffReassignStatPanel.Location = New-Object System.Drawing.Point(24, 132)
        $handoffRefuseStatPanel.Location = New-Object System.Drawing.Point(274, 132)
        $confirmDealButton.Enabled = $true
        $copySheetsButton.Enabled = $false
        $handoffDoneButton.Enabled = $true

        $googleSelectedLabel.Text = "Таблица"
        $googleStateHint.Text = ""

        $messageBox.Text = "После создания комнаты здесь появится готовое сообщение для клиента."
        $script:lastMessage = ""
        $script:lastUrl = ""
        $copyMessageButton.Enabled = $false
        $copyLinkButton.Enabled = $false
        $openButton.Enabled = $false

        $clientPhoneBox.Text = ""
        $parentNameBox.Text = ""
        $studentNameBox.Text = ""
        $childClassBox.Text = ""
        $leadSourceBox.Text = ""

        foreach ($box in @($clientPhoneBox,$parentNameBox,$studentNameBox,$childClassBox,$leadSourceBox)) {
            $box.Enabled = $false
        }

        if ([string]::IsNullOrWhiteSpace([string]$script:settings.MvlTag)) {
            $mvlTagValue.Text = "не указан"
        } else {
            $mvlTagValue.Text = [string]$script:settings.MvlTag
        }

        Update-HandoffSummary
        Update-HandoffActionStyles
        Update-ButtonStateStyles
        return
    }

    $handoffGroup.Size = New-Object System.Drawing.Size(530, 258)
    $handoffSelectedLabel.Location = New-Object System.Drawing.Point(24, 2)
    $handoffDueLabel.Visible = $true
    $handoffStatusLabel.Visible = $true
    $handoffSummaryLabel.Visible = $true
    $handoffSummaryLabel.Location = New-Object System.Drawing.Point(24, 56)
    $handoffTotalPanel.Visible = $true
    $handoffConfirmedPanel.Visible = $true
    $handoffPassedPanel.Visible = $true
    $handoffTotalPanel.Location = New-Object System.Drawing.Point(24, 80)
    $handoffConfirmedPanel.Location = New-Object System.Drawing.Point(190, 80)
    $handoffPassedPanel.Location = New-Object System.Drawing.Point(356, 80)
    $handoffOutcomeSummaryLabel.Visible = $false
    $handoffReassignStatPanel.Visible = $true
    $handoffRefuseStatPanel.Visible = $true
    $handoffReassignStatPanel.Location = New-Object System.Drawing.Point(24, 146)
    $handoffRefuseStatPanel.Location = New-Object System.Drawing.Point(274, 146)

    $confirmDealButton.Location = New-Object System.Drawing.Point(24, 182)
    $handoffDoneButton.Location = New-Object System.Drawing.Point(356, 182)
    $reassignDealButton.Location = New-Object System.Drawing.Point(190, 182)
    $refuseDealButton.Location = New-Object System.Drawing.Point(356, 182)
    $clearDecisionButton.Location = New-Object System.Drawing.Point(24, 182)
    $handoffStatusLabel.Location = New-Object System.Drawing.Point(24, 222)

    $handoffSelectedLabel.Text = "ID $($record.ID) • $($record.ConsultationDate) $($record.Slot)"

    Update-HandoffDueLabel $record

    $googleSelectedLabel.Text = "Таблица"

    $googleStateHint.Text = "ID $($record.ID) • данные готовы"

    foreach ($box in @($clientPhoneBox,$parentNameBox,$studentNameBox,$childClassBox,$leadSourceBox)) {
        $box.Enabled = $true
    }

    $clientPhoneBox.Text = [string]$record.ClientPhone
    $parentNameBox.Text = [string]$record.ParentName
    $studentNameBox.Text = [string]$record.StudentName
    $childClassBox.Text = [string]$record.ChildClass
    $leadSourceBox.Text = [string]$record.LeadSource

    if ([string]::IsNullOrWhiteSpace([string]$script:settings.MvlTag)) {
        $mvlTagValue.Text = "не указан"
    } else {
        $mvlTagValue.Text = [string]$script:settings.MvlTag
    }

    $workflow = Get-WorkflowState $record
    $handoffStatusLabel.Text = "Статус: $workflow"

    $timeParts = @()
    if ([string]$record.ConfirmedAt) {
        $timeParts += "Подтверждено: $($record.ConfirmedAt)"
    }
    if ([string]$record.HandoffAt) {
        $timeParts += "Передано: $($record.HandoffAt)"
    }

    if ($timeParts.Count -gt 0) {
        $handoffStatusLabel.Text += "`r`n" + ($timeParts -join "  •  ")
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)) {
        $handoffStatusLabel.Text += "`r`nТег: $($record.DecisionTag)"
        if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionAt)) {
            $handoffStatusLabel.Text += "  •  $($record.DecisionAt)"
        }
    }

    $confirmDealButton.Enabled = $true
    $confirmDealButton.Text = $(if ([string]$record.ConfirmationStatus -eq "Подтверждено") { "Снять подтверждение" } else { "Подтвердить" })

    $isConfirmed = ([string]$record.ConfirmationStatus -eq "Подтверждено")
    $decision = [string]$record.DecisionStatus
    $hasDecision = -not [string]::IsNullOrWhiteSpace($decision)

    $copySheetsButton.Enabled = $true

    if ($isConfirmed) {
        $confirmDealButton.Visible = $true
        $handoffDoneButton.Visible = $true
        $reassignDealButton.Visible = $false
        $refuseDealButton.Visible = $false
        $clearDecisionButton.Visible = $false

        $confirmDealButton.Location = New-Object System.Drawing.Point(24, 182)
        $confirmDealButton.Size = New-Object System.Drawing.Size(228, 36)
        $handoffDoneButton.Location = New-Object System.Drawing.Point(274, 182)
        $handoffDoneButton.Size = New-Object System.Drawing.Size(230, 36)
    }
    elseif ($hasDecision) {
        $confirmDealButton.Visible = $false
        $handoffDoneButton.Visible = $false
        $reassignDealButton.Visible = $true
        $refuseDealButton.Visible = $true
        $clearDecisionButton.Visible = $true

        $clearDecisionButton.Location = New-Object System.Drawing.Point(24, 182)
        $clearDecisionButton.Size = New-Object System.Drawing.Size(150, 36)
        $reassignDealButton.Location = New-Object System.Drawing.Point(190, 182)
        $reassignDealButton.Size = New-Object System.Drawing.Size(150, 36)
        $refuseDealButton.Location = New-Object System.Drawing.Point(356, 182)
        $refuseDealButton.Size = New-Object System.Drawing.Size(150, 36)
    }
    else {
        $confirmDealButton.Visible = $true
        $handoffDoneButton.Visible = $false
        $reassignDealButton.Visible = $true
        $refuseDealButton.Visible = $true
        $clearDecisionButton.Visible = $false

        $confirmDealButton.Location = New-Object System.Drawing.Point(24, 182)
        $confirmDealButton.Size = New-Object System.Drawing.Size(150, 36)
        $reassignDealButton.Location = New-Object System.Drawing.Point(190, 182)
        $reassignDealButton.Size = New-Object System.Drawing.Size(150, 36)
        $refuseDealButton.Location = New-Object System.Drawing.Point(356, 182)
        $refuseDealButton.Size = New-Object System.Drawing.Size(150, 36)
    }

    $alreadyHandedOff = ([string]$record.HandoffStatus -eq "Передано")

    if ($alreadyHandedOff) {
        $confirmDealButton.Text = "Подтверждено ✓"
        $confirmDealButton.Enabled = $false
        $handoffDoneButton.Text = "Передано ✓"
        $handoffDoneButton.Enabled = $false
    } else {
        $confirmDealButton.Enabled = $true
        $handoffDoneButton.Text = "Передать"
        $handoffDoneButton.Enabled = $isConfirmed
    }

    Update-HandoffSummary
    Update-HandoffActionStyles
    Update-ButtonStateStyles
}

function Save-WorkflowFields {
    if ($null -eq $script:selectedHistoryRecord) {
        return
    }

    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)
    if ($null -eq $record) {
        return
    }

    $record.ClientPhone = Normalize-ClientPhone $clientPhoneBox.Text
    $record.ParentName = $parentNameBox.Text.Trim()
    $record.StudentName = $studentNameBox.Text.Trim()
    $record.ChildClass = $childClassBox.Text.Trim()
    $record.LeadSource = $leadSourceBox.Text.Trim()

    Save-CurrentHistory
    $script:selectedHistoryRecord = $record
}

function Add-WorkflowAudit($record, [string]$action) {
    $auditRecord = [pscustomobject]@{
        CreatedAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm:ss")
        ConsultationDate = [string]$record.ConsultationDate
        Slot = [string]$record.Slot
        End = [string]$record.End
        ID = [string]$record.ID
        URL = [string]$record.URL
        Status = $action
    }

    Append-AuditRecord $auditRecord
    if ($null -ne $script:selectedHistoryRecord -and [string]$script:selectedHistoryRecord.ID -eq [string]$record.ID) { Refresh-ActionTimeline $record }
}

function Toggle-Confirmation {
    if ($null -eq $script:selectedHistoryRecord) {
        Show-Info "Сначала выберите сделку в списке."
        return
    }

    Save-WorkflowFields
    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)
    if ($null -eq $record) {
        return
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)) {
        Show-Info "У сделки уже установлен исход: $($record.DecisionStatus) · $($record.DecisionTag).`r`nСначала нажмите «Сбросить»."
        return
    }

    if ([string]$record.ConfirmationStatus -eq "Подтверждено") {
        $record.ConfirmationStatus = ""
        $record.ConfirmedAt = ""
        $record.HandoffStatus = ""
        $record.HandoffAt = ""
        Add-WorkflowAudit $record "Снято подтверждение"
    } else {
        $record.ConfirmationStatus = "Подтверждено"
        $record.ConfirmedAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm")
        $record.HandoffStatus = ""
        $record.HandoffAt = ""
        Add-WorkflowAudit $record "Подтверждено"
    }

    Save-CurrentHistory
    Refresh-HistoryGrid
    Update-HandoffSummary

    $updated = Find-LatestHistoryById ([string]$record.ID)
    Update-WorkflowPanel $updated
}

function Build-ClientName($record) {
    $parts = @()

    if (-not [string]::IsNullOrWhiteSpace([string]$record.ParentName)) {
        $parts += "р.$([string]$record.ParentName)"
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$record.StudentName)) {
        $parts += "уч.$([string]$record.StudentName)"
    }

    return ($parts -join " ")
}

function Build-LeadInfo($record) {
    $parts = @()

    if (-not [string]::IsNullOrWhiteSpace([string]$record.ChildClass)) {
        $parts += [string]$record.ChildClass
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$record.LeadSource)) {
        $parts += [string]$record.LeadSource
    }

    return ($parts -join " | ")
}

function Copy-ForGoogle {
    if ($null -eq $script:selectedHistoryRecord) {
        return
    }

    Save-WorkflowFields
    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)

    $mvl = ([string]$script:settings.MvlTag).Trim()
    $phone = ([string]$record.ClientPhone).Trim()
    $clientName = Build-ClientName $record
    $leadInfo = Build-LeadInfo $record

    $missing = @()

    if ([string]::IsNullOrWhiteSpace($mvl)) {
        $missing += "МВЛ-тег (Настройки)"
    }
    if ([string]::IsNullOrWhiteSpace($phone)) {
        $missing += "телефон клиента"
    }
    if ([string]::IsNullOrWhiteSpace($clientName)) {
        $missing += "имя родителя/ученика"
    }
    if ([string]::IsNullOrWhiteSpace($leadInfo)) {
        $missing += "класс/источник"
    }

    if ($missing.Count -gt 0) {
        Show-Info ("Не хватает данных для Google:`r`n• " + ($missing -join "`r`n• "))
        return
    }

    # ВАЖНО: вставлять нужно начиная с ячейки столбца "МВЛ".
    #
    # Порядок колонок в вашей таблице:
    # 1 МВЛ
    # 2 Телефончик
    # 3 Имя
    # 4 Айди
    # 5 Статус       -> оставляем пустым
    # 6 Сумма        -> оставляем пустым
    # 7 ЧТО ЗА ЛИД
    # 8 9 класс      -> оставляем пустым
    # 9 Ссылка
    #
    # Три пустых значения нужны специально, чтобы Google Sheets
    # сохранил правильное выравнивание по колонкам.
    $row = "$mvl`t$phone`t$clientName`t$($record.ID)`t`t`t$leadInfo`t`t$($record.URL)"

    Set-Clipboard -Value $row

    # Значения уже сохранены в записи сделки перед копированием.
    # После успешного копирования очищаем только видимые поля формы,
    # чтобы они не остались от предыдущего клиента.
    $clientPhoneBox.Text = ""
    $parentNameBox.Text = ""
    $studentNameBox.Text = ""
    $childClassBox.Text = ""
    $leadSourceBox.Text = ""

    $copySheetsButton.Focus()
    Notify-Success "Строка для Google Sheets скопирована. Поля очищены."
}

function Mark-HandoffDone {
    if ($null -eq $script:selectedHistoryRecord) {
        Show-Info "Сначала выберите сделку в списке."
        return
    }

    Save-WorkflowFields
    $record = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)

    if (-not [string]::IsNullOrWhiteSpace([string]$record.DecisionStatus)) {
        Show-Info "Для сделки установлен исход: $($record.DecisionStatus) · $($record.DecisionTag)."
        return
    }

    if ([string]$record.ConfirmationStatus -ne "Подтверждено") {
        Show-Info "Сначала подтвердите консультацию."
        return
    }

    if ([string]$record.HandoffStatus -eq "Передано") {
        return
    }

    $record.HandoffStatus = "Передано"
    $record.HandoffAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm")
    Add-WorkflowAudit $record "Передано методисту"
    Save-CurrentHistory

    Refresh-HistoryGrid
    Update-HandoffSummary

    $updated = Find-LatestHistoryById ([string]$record.ID)
    Update-WorkflowPanel $updated
    Notify-Success "Сделка $($record.ID) отмечена как переданная"
}

function Check-HandoffReminders {
    $now = Get-MoscowNow

    foreach ($record in $script:history) {
        if ([string]$record.ConfirmationStatus -ne "Подтверждено") {
            continue
        }

        if ([string]$record.HandoffStatus -eq "Передано") {
            continue
        }

        $due = Get-HandoffDue $record
        $consultation = Get-ConsultationDateTime $record

        if ($null -eq $due -or $null -eq $consultation) {
            continue
        }

        # Не напоминаем о очень старых консультациях.
        if ($now -gt $consultation.AddHours(2)) {
            continue
        }

        if ($now -ge $due) {
            $key = "$($record.ID)|$($record.ConsultationDate)|$($record.Slot)"

            if (-not $script:remindedHandoffs.ContainsKey($key)) {
                $script:remindedHandoffs[$key] = $true

                if ([bool]$script:settings.Notifications) {
                    $notify.BalloonTipTitle = "Пора передать методисту"
                    $notify.BalloonTipText = "ID $($record.ID) • консультация $($record.Slot). Передача должна быть за 30 минут."
                    $notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Warning
                    $notify.ShowBalloonTip(5000)
                }

                # Статус в таблице обновляем независимо от настройки уведомлений.
                Refresh-HistoryGrid
            }
        }
    }

    Update-HandoffSummary

    # Не перерисовываем таблицу каждые 30 секунд:
    # иначе выделение строки сбрасывается прямо во время работы пользователя.
    if ($null -ne $script:selectedHistoryRecord) {
        $updated = Find-LatestHistoryById ([string]$script:selectedHistoryRecord.ID)
        Update-WorkflowPanel $updated
    }
}

# ==================== Manual history deletion ====================

function Add-DeletionAudit($record) {
    if ($null -eq $record) {
        return
    }

    $auditRecord = [pscustomobject]@{
        CreatedAt = (Get-MoscowNow).ToString("dd.MM.yyyy HH:mm:ss")
        ConsultationDate = [string]$record.ConsultationDate
        Slot = [string]$record.Slot
        End = [string]$record.End
        ID = [string]$record.ID
        URL = [string]$record.URL
        Status = "Удалено из истории"
    }

    Append-AuditRecord $auditRecord
}

function Hide-DeleteUndo {
    $undoDeleteTimer.Stop()
    $undoDeletePanel.Visible = $false
    $stateFilterPanel.Visible = $true
    $script:lastDeletedRecord = $null
}

function Show-DeleteUndo($record) {
    if ($null -eq $record) {
        return
    }

    $script:lastDeletedRecord = Convert-ToHistoryRecord $record $false

    $undoDeleteInfo.Text = "Удалено: $($record.ID)"
    $undoDeleteAction.Text = "Отменить"

    $undoDeleteTimer.Stop()

    $stateFilterPanel.Visible = $false
    $undoDeletePanel.Visible = $true
    $undoDeletePanel.BringToFront()

    # Возвращаем фокус приложению после MessageBox/Refresh, чтобы Undo
    # гарантированно оставался виден.
    $form.Activate()

    $undoDeleteTimer.Start()
}

function Undo-LastDeletion {
    $record = $script:lastDeletedRecord

    if ($null -eq $record) {
        return
    }

    $existing = Find-LatestHistoryById ([string]$record.ID)
    if ($null -ne $existing) {
        Hide-DeleteUndo
        Show-Info "Сделка $($record.ID) уже снова есть в истории."
        return
    }

    $restored = Convert-ToHistoryRecord $record $false
    $script:history += $restored

    Save-CurrentHistory
    Add-WorkflowAudit $restored "Удаление отменено"

    $undoDeleteTimer.Stop()
    $undoDeletePanel.Visible = $false
    $stateFilterPanel.Visible = $true
    $script:lastDeletedRecord = $null

    Refresh-HistoryGrid
    Update-SlotCounters
    Update-IdHistoryInfo
    Update-HandoffSummary

    # Если восстановленная сделка видна в текущем списке — сразу выбираем её.
    for ($i = 0; $i -lt $historyGrid.Rows.Count; $i++) {
        $rowRecord = $historyGrid.Rows[$i].Tag
        if ($null -ne $rowRecord -and [string]$rowRecord.ID -eq [string]$restored.ID) {
            Select-HistoryRow $i
            break
        }
    }

    Notify-Success "Удаление сделки $($restored.ID) отменено"
}

function Delete-HistoryRecord($record) {
    if ($null -eq $record) {
        return
    }

    $id = [string]$record.ID
    $consultDate = [string]$record.ConsultationDate
    $slot = [string]$record.Slot

    $confirmed = Ask-YesNo (
        "Удалить сделку из локальной истории и статистики?`r`n`r`n" +
        "ID: $id`r`n" +
        "Дата: $consultDate`r`n" +
        "Время: $slot`r`n`r`n" +
        "Комната KTalk и её уникальная ссылка НЕ удаляются."
    ) "Удаление сделки"

    if (-not $confirmed) {
        return
    }

    # Сохраняем полную копию на случай Undo.
    $deletedSnapshot = Convert-ToHistoryRecord $record $false

    Add-DeletionAudit $record

    $script:history = @(
        $script:history |
        Where-Object { [string]$_.ID -ne $id }
    )

    Save-CurrentHistory
    Refresh-HistoryGrid
    Update-SlotCounters
    Update-IdHistoryInfo

    $deleteHistoryButton.Enabled = $true

    # Если справа отображалась именно эта сделка — очищаем рабочие действия.
    if ([string]$script:lastUrl -eq [string]$record.URL) {
        $script:lastUrl = $null
        $script:lastMessage = $null
        $messageBox.Text = ""
        $copyMessageButton.Enabled = $true
        $copyLinkButton.Enabled = $true
        $openButton.Enabled = $true
    }

    if ($null -ne $script:selectedHistoryRecord -and [string]$script:selectedHistoryRecord.ID -eq $id) {
        Update-WorkflowPanel $null
    }

    Update-HandoffSummary
    Notify-Success "Сделка $id удалена из истории и статистики"
    Show-DeleteUndo $deletedSnapshot
}

function Delete-SelectedHistoryRecord {
    if ($historyGrid.SelectedRows.Count -eq 0) {
        Show-Info "Сначала выберите сделку в таблице."
        return
    }

    $record = $historyGrid.SelectedRows[0].Tag
    if ($null -eq $record) {
        Show-Info "Не удалось определить выбранную сделку."
        return
    }

    if (Is-ArchivedRecord $record) {
        Show-Info "Это архивная сделка. Архив хранится отдельно и из рабочего списка не удаляется."
        return
    }

    Delete-HistoryRecord $record
}

# ==================== API status ====================

$toolTip = New-Object System.Windows.Forms.ToolTip

$historyCellCopyToolTip = New-Object System.Windows.Forms.ToolTip
$historyCellCopyToolTip.ShowAlways = $true
$historyCellCopyToolTip.UseAnimation = $true
$historyCellCopyToolTip.UseFading = $true
$historyCellCopyToolTip.InitialDelay = 0
$historyCellCopyToolTip.ReshowDelay = 0
$historyCellCopyToolTip.AutoPopDelay = 900

function Update-ApiStatus {
    if (-not (Ensure-ApiKey)) {
        $apiStatus.Text = "API • ключ не задан"
        $apiStatus.ForeColor = [System.Drawing.Color]::DarkRed
        return
    }

    if (-not (Test-Path $apiCheckFile)) {
        $apiStatus.Text = "API • модуль не найден"
        $apiStatus.ForeColor = [System.Drawing.Color]::DarkRed
        return
    }

    $apiStatus.Text = "API • проверка..."
    $apiStatus.ForeColor = [System.Drawing.Color]::DimGray
    $form.Refresh()

    try {
        $env:KTALK_API_KEY = $script:plainKey
        $output = & php $apiCheckFile 2>&1
        $exitCode = $LASTEXITCODE
        $jsonText = ($output | Out-String).Trim()
        $result = $jsonText | ConvertFrom-Json

        if ($exitCode -eq 0 -and $result.ok) {
            $apiStatus.Text = "API • доступен"
            $apiStatus.ForeColor = [System.Drawing.Color]::ForestGreen
            $toolTip.SetToolTip($apiStatus, "Проверка API прошла успешно.")
        } else {
            $apiStatus.Text = "API • ошибка"
            $apiStatus.ForeColor = [System.Drawing.Color]::DarkRed
            $toolTip.SetToolTip($apiStatus, [string]$result.message)
        }
    } catch {
        $apiStatus.Text = "API • ошибка"
        $apiStatus.ForeColor = [System.Drawing.Color]::DarkRed
        $toolTip.SetToolTip($apiStatus, $_.Exception.Message)
    } finally {
        Remove-Item Env:\KTALK_API_KEY -ErrorAction SilentlyContinue
    }
}

# ==================== Duplicate dialog ====================

function Show-DuplicateDialog($record) {
    $d = New-Object System.Windows.Forms.Form
    $d.Text = "Комната уже существует"
    $d.StartPosition = "CenterParent"
    $d.Size = New-Object System.Drawing.Size(525, 250)
    $d.FormBorderStyle = "FixedDialog"
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font("Segoe UI", 10)

    $l = New-Object System.Windows.Forms.Label
    $l.Text = "Комната с ID $($record.ID) уже создавалась.`r`n`r`nДата/время: $($record.ConsultationDate) $($record.Slot)`r`nСоздано: $($record.CreatedAt)"
    $l.AutoSize = $true
    $l.Location = New-Object System.Drawing.Point(20, 20)
    $d.Controls.Add($l)

    $open = New-Object System.Windows.Forms.Button
    $open.Text = "Открыть существующую"
    $open.Location = New-Object System.Drawing.Point(20, 145)
    $open.Size = New-Object System.Drawing.Size(160, 38)
    $d.Controls.Add($open)

    $update = New-Object System.Windows.Forms.Button
    $update.Text = "Обновить комнату"
    $update.Location = New-Object System.Drawing.Point(190, 145)
    $update.Size = New-Object System.Drawing.Size(150, 38)
    $d.Controls.Add($update)

    $cancel = New-Object System.Windows.Forms.Button
    $cancel.Text = "Отмена"
    $cancel.Location = New-Object System.Drawing.Point(350, 145)
    $cancel.Size = New-Object System.Drawing.Size(130, 38)
    $d.Controls.Add($cancel)

    $script:duplicateChoice = "cancel"

    $open.Add_Click({
        $script:duplicateChoice = "open"
        $d.Close()
    })

    $update.Add_Click({
        $script:duplicateChoice = "update"
        $d.Close()
    })

    $cancel.Add_Click({
        $script:duplicateChoice = "cancel"
        $d.Close()
    })

    [void]$d.ShowDialog($form)
    return $script:duplicateChoice
}

# ==================== Validation / create ====================

function Confirm-DateAndTime([DateTime]$date, [string]$time) {
    $now = Get-MoscowNow
    $selectedDate = $date.Date

    if ($selectedDate -lt $now.Date) {
        if (-not (Ask-YesNo "Выбрана дата, которая уже прошла.`r`nВсё равно продолжить?" "Проверка даты")) {
            return $false
        }
    }

    $timeStart = [DateTime]::ParseExact(
        "$($selectedDate.ToString('dd.MM.yyyy')) $time",
        "dd.MM.yyyy HH:mm",
        $culture
    )

    if ($selectedDate -eq $now.Date -and $timeStart -lt $now) {
        if (-not (Ask-YesNo "Это время уже прошло по Москве.`r`nВсё равно продолжить?" "Проверка времени")) {
            return $false
        }
    }

    $futureDays = [int]$script:settings.FutureWarningDays
    if ($selectedDate -gt $now.Date.AddDays($futureDays)) {
        if (-not (Ask-YesNo "Дата больше чем на $futureDays дней вперёд.`r`nВсё равно продолжить?" "Проверка даты")) {
            return $false
        }
    }

    if (-not (Is-StandardTime $time)) {
        $end = Get-EndTime $time
        if (-not (Ask-YesNo "Нестандартное время: $time–$end МСК.`r`nОно не входит в обычную сетку PARTA.`r`n`r`nСоздать встречу?" "Нестандартное время")) {
            return $false
        }
    }

    return $true
}

function Set-ResultMessage([string]$message, [string]$url, [bool]$isLive) {
    $script:lastMessage = $message
    $script:lastUrl = $url

    $messageBox.Text = $message
    $copyMessageButton.Enabled = $true
    $copyLinkButton.Enabled = $true
    $openButton.Enabled = $true

    Set-AppPage "Main"
}

function Notify-Success([string]$text) {
    if (-not [bool]$script:settings.Notifications) {
        return
    }

    if ($script:settings.Sounds) {
        [System.Media.SystemSounds]::Asterisk.Play()
    }

    $notify.BalloonTipTitle = "KTalk"
    $notify.BalloonTipText = $text
    $notify.BalloonTipIcon = [System.Windows.Forms.ToolTipIcon]::Info
    $notify.ShowBalloonTip(1600)
}

function Invoke-MeetingCreate(
    [string]$id,
    [DateTime]$date,
    [string]$time
) {
    if ($id -notmatch '^\d+$') {
        Show-Error "Такой ID некорректен. ID должен состоять только из цифр."
        return $false
    }

    if ([string]::IsNullOrWhiteSpace($time)) {
        Show-Error "Сначала выберите время."
        return $false
    }

    if (-not (Confirm-DateAndTime $date $time)) {
        return $false
    }

    $dateDisplay = $date.ToString("dd.MM.yyyy")
    $dateApi = $date.ToString("yyyy-MM-dd")

    $roomIdentity = Resolve-RoomIdentity $id
    $roomName = [string]$roomIdentity.RoomName
    $url = [string]$roomIdentity.URL

    $existing = Find-LatestHistoryById $id
    $status = "Создано"

    if ($null -ne $existing) {
        $choice = Show-DuplicateDialog $existing

        if ($choice -eq "open") {
            $mappedExisting = Find-RoomMapById $id

            if ($null -ne $mappedExisting) {
                $openUrl = [string]$mappedExisting.URL
            } else {
                $openUrl = [string]$existing.URL
            }

            Start-Process $openUrl
            $existingMessage = Build-Message $existing.ConsultationDate $existing.Slot $openUrl
            Set-ResultMessage $existingMessage $openUrl $true
            Focus-IdInput $true
            return $false
        }

        if ($choice -eq "cancel") {
            Focus-IdInput $true
            return $false
        }

        $status = "Обновлено"
    }

    if (-not (Ensure-ApiKey)) {
        Show-Error "API-ключ не задан."
        return $false
    }

    if (-not (Test-Path $phpFile)) {
        Show-Error "Не найден модуль создания комнаты: C:\ktalk-auto\create_room.php"
        return $false
    }

    $createButton.Enabled = $false
    $createButton.Text = "Создаю..."

    try {
        $env:KTALK_API_KEY = $script:plainKey
        $output = & php $phpFile $id $roomName $dateApi $time 2>&1
        $exitCode = $LASTEXITCODE

        if ($exitCode -ne 0) {
            throw (($output | Out-String).Trim())
        }

        $result = (($output | Out-String).Trim()) | ConvertFrom-Json

        if (-not $result.ok) {
            throw "Комната не создана."
        }

        $message = Build-Message $result.date $result.start $result.url
        Set-ResultMessage $message $result.url $true

        # Один ID сделки = одна стабильная уникальная ссылка.
        Save-RoomMap $result.id $result.roomName $result.url

        # Автокопирование выполняется после успешного создания комнаты.
        switch ([string]$script:settings.AfterCreate) {
            "SMS" {
                Set-Clipboard -Value $message
            }
            "Link" {
                Set-Clipboard -Value $result.url
            }
            default {
                # None — ничего автоматически не копируем.
            }
        }

        Add-HistoryRecord $result.date $result.start $result.id $result.url $status
        Apply-PendingAmoData ([string]$result.id)
        Refresh-HistoryGrid
        Update-SlotCounters
        Update-IdHistoryInfo

        Notify-Success "$($status): $($result.id), $($result.start)"
        return $true

    } catch {
        Show-Error $_.Exception.Message
        return $false

    } finally {
        Remove-Item Env:\KTALK_API_KEY -ErrorAction SilentlyContinue
        Update-CreateButtonStyles
        Update-CreateEnabled
    }
}

# ==================== Settings dialog ====================

function Show-Settings {
    $d = New-Object System.Windows.Forms.Form
    $d.Text = "Настройки"
    $d.StartPosition = "CenterParent"
    $d.Size = New-Object System.Drawing.Size(700, 720)
    $d.FormBorderStyle = "FixedDialog"
    $d.MaximizeBox = $false
    $d.MinimizeBox = $false
    $d.Font = New-Object System.Drawing.Font("Segoe UI", 10)
    $d.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::Dpi

    $themeGroup = New-Object System.Windows.Forms.GroupBox
    $themeGroup.Text = "Оформление"
    $themeGroup.Location = New-Object System.Drawing.Point(22, 18)
    $themeGroup.Size = New-Object System.Drawing.Size(286, 110)
    $d.Controls.Add($themeGroup)

    $themeLabelInner = New-Object System.Windows.Forms.Label
    $themeLabelInner.Text = "Тема интерфейса"
    $themeLabelInner.AutoSize = $true
    $themeLabelInner.Location = New-Object System.Drawing.Point(18, 30)
    $themeGroup.Controls.Add($themeLabelInner)

    $themeLight = New-Object System.Windows.Forms.RadioButton
    $themeLight.Text = "Светлая"
    $themeLight.AutoSize = $true
    $themeLight.Location = New-Object System.Drawing.Point(18, 60)
    $themeGroup.Controls.Add($themeLight)

    $themeDark = New-Object System.Windows.Forms.RadioButton
    $themeDark.Text = "Тёмная"
    $themeDark.AutoSize = $true
    $themeDark.Location = New-Object System.Drawing.Point(130, 60)
    $themeGroup.Controls.Add($themeDark)

    if ([string]$script:settings.Theme -eq "Dark") {
        $themeDark.Checked = $true
    } else {
        $themeLight.Checked = $true
    }

    $apiGroup = New-Object System.Windows.Forms.GroupBox
    $apiGroup.Text = "KTalk API"
    $apiGroup.Location = New-Object System.Drawing.Point(344, 18)
    $apiGroup.Size = New-Object System.Drawing.Size(326, 140)
    $d.Controls.Add($apiGroup)

    $apiStatusTitle = New-Object System.Windows.Forms.Label
    $apiStatusTitle.Text = "Статус соединения"
    $apiStatusTitle.AutoSize = $true
    $apiStatusTitle.Location = New-Object System.Drawing.Point(18, 30)
    $apiGroup.Controls.Add($apiStatusTitle)

    $apiStatusInfo = New-Object System.Windows.Forms.Label
    $apiStatusInfo.Text = $apiStatus.Text
    $apiStatusInfo.AutoSize = $false
    $apiStatusInfo.Size = New-Object System.Drawing.Size(240, 28)
    $apiStatusInfo.Location = New-Object System.Drawing.Point(18, 54)
    $apiGroup.Controls.Add($apiStatusInfo)

    $apiCheckButton = New-Object System.Windows.Forms.Button
    $apiCheckButton.Text = "Проверить"
    $apiCheckButton.Location = New-Object System.Drawing.Point(18, 92)
    $apiCheckButton.Size = New-Object System.Drawing.Size(110, 34)
    $apiGroup.Controls.Add($apiCheckButton)

    $apiKeyButton = New-Object System.Windows.Forms.Button
    $apiKeyButton.Text = "API-ключ..."
    $apiKeyButton.Location = New-Object System.Drawing.Point(146, 92)
    $apiKeyButton.Size = New-Object System.Drawing.Size(112, 34)
    $apiGroup.Controls.Add($apiKeyButton)

    $apiHint = New-Object System.Windows.Forms.Label
    $apiHint.Text = "Проверка и смена API-ключа теперь находятся здесь, а не в верхней панели."
    $apiHint.AutoSize = $false
    $apiHint.Size = New-Object System.Drawing.Size(240, 36)
    $apiHint.Location = New-Object System.Drawing.Point(18, 132)
    $apiHint.Visible = $false

    $notificationGroup = New-Object System.Windows.Forms.GroupBox
    $notificationGroup.Text = "Уведомления"
    $notificationGroup.Location = New-Object System.Drawing.Point(344, 168)
    $notificationGroup.Size = New-Object System.Drawing.Size(326, 48)
    $d.Controls.Add($notificationGroup)

    $notificationCheck = New-Object System.Windows.Forms.CheckBox
    $notificationCheck.Text = "Показывать уведомления Windows"
    $notificationCheck.AutoSize = $true
    $notificationCheck.Location = New-Object System.Drawing.Point(18, 20)
    $notificationCheck.Checked = [bool]$script:settings.Notifications
    $notificationGroup.Controls.Add($notificationCheck)

    $mvlGroup = New-Object System.Windows.Forms.GroupBox
    $mvlGroup.Text = "Google / МВЛ"
    $mvlGroup.Location = New-Object System.Drawing.Point(22, 145)
    $mvlGroup.Size = New-Object System.Drawing.Size(286, 108)
    $d.Controls.Add($mvlGroup)

    $mvlSettingsLabel = New-Object System.Windows.Forms.Label
    $mvlSettingsLabel.Text = "Мой тег МВЛ для Google-таблицы"
    $mvlSettingsLabel.AutoSize = $true
    $mvlSettingsLabel.Location = New-Object System.Drawing.Point(18, 30)
    $mvlGroup.Controls.Add($mvlSettingsLabel)

    $mvlSettingsBox = New-Object System.Windows.Forms.TextBox
    $mvlSettingsBox.Location = New-Object System.Drawing.Point(18, 56)
    $mvlSettingsBox.Size = New-Object System.Drawing.Size(240, 30)
    $mvlSettingsBox.Text = [string]$script:settings.MvlTag
    $mvlGroup.Controls.Add($mvlSettingsBox)

    $updateGroup = New-Object System.Windows.Forms.GroupBox
    $updateGroup.Text = "Обновления"
    $updateGroup.Location = New-Object System.Drawing.Point(344, 230)
    $updateGroup.Size = New-Object System.Drawing.Size(326, 188)
    $d.Controls.Add($updateGroup)

    $updateVersionLabel = New-Object System.Windows.Forms.Label
    $updateVersionLabel.Text = "Текущая версия: $($script:appVersion.ToString())"
    $updateVersionLabel.AutoSize = $true
    $updateVersionLabel.Location = New-Object System.Drawing.Point(18, 30)
    $updateGroup.Controls.Add($updateVersionLabel)

    $autoUpdateCheck = New-Object System.Windows.Forms.CheckBox
    $autoUpdateCheck.Text = "Проверять обновления при запуске"
    $autoUpdateCheck.AutoSize = $true
    $autoUpdateCheck.Location = New-Object System.Drawing.Point(18, 58)
    $autoUpdateCheck.Checked = [bool]$script:settings.AutoUpdateCheck
    $updateGroup.Controls.Add($autoUpdateCheck)

    $updateUrlLabel = New-Object System.Windows.Forms.Label
    $updateUrlLabel.Text = "URL manifest.json"
    $updateUrlLabel.AutoSize = $true
    $updateUrlLabel.Location = New-Object System.Drawing.Point(18, 88)
    $updateGroup.Controls.Add($updateUrlLabel)

    $updateUrlBox = New-Object System.Windows.Forms.TextBox
    $updateUrlBox.Location = New-Object System.Drawing.Point(18, 112)
    $updateUrlBox.Size = New-Object System.Drawing.Size(288, 28)
    $updateUrlBox.Text = Get-UpdateChannelManifestUrl
    $updateGroup.Controls.Add($updateUrlBox)

    $checkUpdateButton = New-Object System.Windows.Forms.Button
    $checkUpdateButton.Text = "Проверить обновления"
    $checkUpdateButton.Location = New-Object System.Drawing.Point(18, 146)
    $checkUpdateButton.Size = New-Object System.Drawing.Size(180, 32)
    $updateGroup.Controls.Add($checkUpdateButton)

    $copyGroup = New-Object System.Windows.Forms.GroupBox
    $copyGroup.Text = "После успешного создания комнаты"
    $copyGroup.Location = New-Object System.Drawing.Point(22, 436)
    $copyGroup.Size = New-Object System.Drawing.Size(648, 160)
    $d.Controls.Add($copyGroup)

    $copyNone = New-Object System.Windows.Forms.RadioButton
    $copyNone.Text = "Ничего автоматически не копировать"
    $copyNone.AutoSize = $true
    $copyNone.Location = New-Object System.Drawing.Point(20, 36)
    $copyGroup.Controls.Add($copyNone)

    $copySms = New-Object System.Windows.Forms.RadioButton
    $copySms.Text = "Копировать готовое SMS"
    $copySms.AutoSize = $true
    $copySms.Location = New-Object System.Drawing.Point(20, 75)
    $copyGroup.Controls.Add($copySms)

    $copyLink = New-Object System.Windows.Forms.RadioButton
    $copyLink.Text = "Копировать только ссылку KTalk"
    $copyLink.AutoSize = $true
    $copyLink.Location = New-Object System.Drawing.Point(20, 114)
    $copyGroup.Controls.Add($copyLink)

    switch ([string]$script:settings.AfterCreate) {
        "None" { $copyNone.Checked = $true }
        "Link" { $copyLink.Checked = $true }
        default { $copySms.Checked = $true }
    }

    $copyNote = New-Object System.Windows.Forms.Label
    $copyNote.Text = "Автокопирование выполняется после успешного создания комнаты."
    $copyNote.AutoSize = $true
    $copyNote.Location = New-Object System.Drawing.Point(24, 604)
    $copyNote.Visible = $false

    $save = New-Object System.Windows.Forms.Button
    $save.Text = "Сохранить"
    $save.Location = New-Object System.Drawing.Point(545, 624)
    $save.Size = New-Object System.Drawing.Size(125, 40)
    $save.Anchor = "Bottom,Right"
    $d.Controls.Add($save)

    $dark = ([string]$script:settings.Theme -eq "Dark")
    $palette = Get-UiPalette $dark

    $d.BackColor = $palette.Card
    $d.ForeColor = $palette.Text
    Set-NativeTitleBarTheme $d $dark

    foreach ($group in @($themeGroup,$apiGroup,$notificationGroup,$mvlGroup,$updateGroup,$copyGroup)) {
        $group.BackColor = $palette.Card
        $group.ForeColor = $palette.Muted
    }

    foreach ($label in @($themeLabelInner,$apiStatusTitle,$apiStatusInfo,$apiHint,$mvlSettingsLabel,$updateVersionLabel,$updateUrlLabel,$copyNote)) {
        $label.ForeColor = $palette.Text
    }
    $apiHint.ForeColor = $palette.Muted
    $apiStatusInfo.ForeColor = if ($apiStatus.Text -like "*доступен*") { $palette.Success } else { $palette.Text }

    foreach ($radio in @($themeLight,$themeDark,$copyNone,$copySms,$copyLink)) {
        $radio.BackColor = $palette.Card
        $radio.ForeColor = $palette.Text
    }

    $notificationCheck.BackColor = $palette.Card
    $notificationCheck.ForeColor = $palette.Text
    $autoUpdateCheck.BackColor = $palette.Card
    $autoUpdateCheck.ForeColor = $palette.Text

    $mvlSettingsBox.BackColor = $palette.Input
    $mvlSettingsBox.ForeColor = $palette.Text
    $updateUrlBox.BackColor = $palette.Input
    $updateUrlBox.ForeColor = $palette.Text

    foreach ($b in @($apiCheckButton,$apiKeyButton,$checkUpdateButton,$save)) {
        Set-FlatButtonStyle $b $palette
    }
    $save.BackColor = $palette.Accent
    $save.ForeColor = [System.Drawing.Color]::White
    $save.FlatAppearance.BorderColor = $palette.Accent
    $save.FlatAppearance.MouseOverBackColor = $palette.AccentHover

    $apiCheckButton.Add_Click({
        Update-ApiStatus
        $apiStatusInfo.Text = $apiStatus.Text

        $darkLocal = ([string]$script:settings.Theme -eq "Dark")
        $paletteLocal = Get-UiPalette $darkLocal
        if ($apiStatus.Text -like "*доступен*") {
            $apiStatusInfo.ForeColor = $paletteLocal.Success
        } else {
            $apiStatusInfo.ForeColor = $paletteLocal.Text
        }
    })

    $apiKeyButton.Add_Click({
        Ask-And-Save-ApiKey
        Update-ApiStatus
        $apiStatusInfo.Text = $apiStatus.Text

        $darkLocal = ([string]$script:settings.Theme -eq "Dark")
        $paletteLocal = Get-UiPalette $darkLocal
        if ($apiStatus.Text -like "*доступен*") {
            $apiStatusInfo.ForeColor = $paletteLocal.Success
        } else {
            $apiStatusInfo.ForeColor = $paletteLocal.Text
        }
    })

    $checkUpdateButton.Add_Click({
        $script:settings.UpdateManifestUrl = $updateUrlBox.Text.Trim()
        $script:settings.AutoUpdateCheck = [bool]$autoUpdateCheck.Checked
        Save-Settings $script:settings
        Check-ForUpdates $false
    })

    $save.Add_Click({
        $mvlTag = $mvlSettingsBox.Text.Trim()

        if (-not [string]::IsNullOrWhiteSpace($mvlTag) -and -not $mvlTag.StartsWith("@")) {
            $mvlTag = "@$mvlTag"
        }

        $script:settings.MvlTag = $mvlTag
        $script:settings.Notifications = [bool]$notificationCheck.Checked
        $script:settings.AutoUpdateCheck = [bool]$autoUpdateCheck.Checked
        $script:settings.UpdateManifestUrl = $updateUrlBox.Text.Trim()

        if ($copyNone.Checked) {
            $script:settings.AfterCreate = "None"
        } elseif ($copyLink.Checked) {
            $script:settings.AfterCreate = "Link"
        } else {
            $script:settings.AfterCreate = "SMS"
        }

        if ($themeDark.Checked) {
            $script:settings.Theme = "Dark"
        } else {
            $script:settings.Theme = "Light"
        }

        Save-Settings $script:settings
        Apply-Theme
        Update-ApiStatus

        if ($null -ne $mvlTagValue) {
            if ([string]::IsNullOrWhiteSpace([string]$script:settings.MvlTag)) {
                $mvlTagValue.Text = "не указан"
            } else {
                $mvlTagValue.Text = [string]$script:settings.MvlTag
            }
        }

        $d.Close()
        $idBox.Focus()
    })

    [void]$d.ShowDialog($form)
}

# ==================== Tray ====================

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Icon = [System.Drawing.SystemIcons]::Application
$notify.Text = "PARTA — KTalk Creator"
$notify.Visible = $true

$trayMenu = New-Object System.Windows.Forms.ContextMenuStrip
$trayOpen = $trayMenu.Items.Add("Открыть")
$trayMenu.Items.Add("-") | Out-Null
$trayExit = $trayMenu.Items.Add("Выход")
$notify.ContextMenuStrip = $trayMenu

$handoffTimer = New-Object System.Windows.Forms.Timer
$handoffTimer.Interval = 30000
$handoffTimer.Add_Tick({
    Check-HandoffReminders

    if ($null -ne $script:selectedHistoryRecord -and $handoffDueLabel.Visible) {
        Update-HandoffDueLabel $script:selectedHistoryRecord
    }

    if (Archive-PastHistory) {
        Refresh-HistoryGrid
        Update-SlotCounters
        Update-HandoffSummary
        Update-WorkflowPanel $null
    }
})
$handoffTimer.Start()

$updateCheckTimer = New-Object System.Windows.Forms.Timer
$updateCheckTimer.Interval = 2500
$updateCheckTimer.Add_Tick({
    $updateCheckTimer.Stop()

    if ([bool]$script:settings.AutoUpdateCheck -and
        -not [string]::IsNullOrWhiteSpace((Get-UpdateChannelManifestUrl))) {
        Check-ForUpdates $true
    }
})

function Show-Main {
    $form.Show()
    $form.WindowState = "Normal"
    $form.Activate()
}

# ==================== Events ====================

foreach ($btn in $slotButtons) {
    $btn.Add_Click({
        $slot = [string]$this.Tag
        Set-SelectedTime $slot $false
        Set-SlotFilter $slot
    })
}

$customButton.Add_Click({
    Clear-SlotFilter

    if ($script:selectedTime -eq $null) {
        Set-SelectedTime "11:00" $true
    } else {
        Set-SelectedTime $script:selectedTime $true
    }

    $customTimeText.Focus()
    $customTimeText.SelectAll()
})

$customTimeText.Add_KeyPress({
    if (-not [char]::IsControl($_.KeyChar) -and
        -not [char]::IsDigit($_.KeyChar) -and
        $_.KeyChar -ne ':') {
        $_.Handled = $true
    }
})

$customTimeText.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true
        [void](Apply-CustomTimeText)
    }
})

$customTimeText.Add_Leave({
    [void](Apply-CustomTimeText)
})

$customTimeText.Add_TextChanged({
})

$minus30.Add_Click({ Shift-Time -30 })
$minus15.Add_Click({ Shift-Time -15 })
$plus15.Add_Click({ Shift-Time 15 })
$plus30.Add_Click({ Shift-Time 30 })

$mainPageButton.Add_Click({
    Set-AppPage "Main"
})

$dealsPageButton.Add_Click({
    Set-AppPage "Deals"
})

$messageNavButton.Add_Click({
    $workTabs.SelectedTab = $messageTab
    Update-WorkNavStyles
})

$handoffNavButton.Add_Click({
    $workTabs.SelectedTab = $handoffTab
    Update-WorkNavStyles
})

$googleNavButton.Add_Click({$workTabs.SelectedTab=$googleTab;Update-WorkNavStyles})
$timelineNavButton.Add_Click({$workTabs.SelectedTab=$historyTab;Update-WorkNavStyles})

$workTabs.Add_SelectedIndexChanged({
    Update-WorkNavStyles
    if(-not $script:restoringUiState){Save-UiState}
})


$lightButton.Add_Click({
    $script:settings.Theme = "Light"
    Save-Settings $script:settings
    Apply-Theme
})

$darkButton.Add_Click({
    $script:settings.Theme = "Dark"
    Save-Settings $script:settings
    Apply-Theme
})

$todayButton.Add_Click({
    $datePicker.Value = (Get-MoscowNow).Date
})

$tomorrowButton.Add_Click({
    $datePicker.Value = (Get-MoscowNow).Date.AddDays(1)
})

$otherDateButton.Add_Click({
    Show-DateCalendar
})

$dateSelectButton.Add_Click({
    Show-DateCalendar
})

$dateChevronLabel.Add_Click({
    Show-DateCalendar
})

$datePicker.Add_ValueChanged({
    $dateSelectButton.Text = $datePicker.Value.ToString("dd.MM.yyyy")
    if(-not $script:restoringUiState){$script:slotFilter=$null}
    Update-SlotFilterUi
    Update-DateButtonStyles
    Update-SlotCounters
    Update-Preview
    Refresh-HistoryGrid
    Update-HandoffSummary
    Update-WorkflowPanel $null
    if(-not $script:restoringUiState){Save-UiState}
})

$idBox.Add_KeyPress({
    if (-not [char]::IsControl($_.KeyChar) -and -not [char]::IsDigit($_.KeyChar)) {
        $_.Handled = $true
    }
})

$idBox.Add_TextChanged({
    Update-CreateEnabled
    Update-Preview
    Update-IdHistoryInfo
})

$idBox.Add_KeyDown({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        $_.SuppressKeyPress = $true

        $id = $idBox.Text.Trim()
        $created = Invoke-MeetingCreate $id $datePicker.Value $script:selectedTime

        if ($created) {
            $idBox.Clear()
        }

        Focus-IdInput (-not $created)
    }
})

$createButton.Add_Click({
    $id = $idBox.Text.Trim()
    $created = Invoke-MeetingCreate $id $datePicker.Value $script:selectedTime

    if ($created) {
        $idBox.Clear()
    }

    Focus-IdInput (-not $created)
})

$copyMessageButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($script:lastMessage)) {
        Show-Info "Сначала создайте встречу или выберите сделку."
        return
    }

    Set-Clipboard -Value $script:lastMessage
    Notify-Success "Сообщение скопировано"
})

$copyLinkButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($script:lastUrl)) {
        Show-Info "Сначала создайте встречу или выберите сделку."
        return
    }

    Set-Clipboard -Value $script:lastUrl
    Notify-Success "Ссылка скопирована"
})

$openButton.Add_Click({
    if ([string]::IsNullOrWhiteSpace($script:lastUrl) -or
        -not ([string]$script:lastUrl).StartsWith("http")) {
        Show-Info "Сейчас нет созданной KTalk-ссылки для открытия."
        return
    }

    Start-Process $script:lastUrl
})

foreach ($entry in $stateFilterButtons.GetEnumerator()) {
    $entry.Value.Add_Click({
        Set-StateFilter ([string]$this.Tag)
    })
}

$slotFilterButton.Add_Click({
    Clear-HistoryFilters
})

$historySearch.Add_TextChanged({
    Refresh-HistoryGrid

    # Если пользователь очистил поиск, возвращаем обычный режим списка.
    if (-not $script:historySearchPlaceholderActive -and
        [string]::IsNullOrWhiteSpace($historySearch.Text)) {
        Update-HandoffSummary
    }
})

$historySearch.Add_Enter({
    Clear-HistorySearchPlaceholder
})

$historySearch.Add_Leave({
    if ([string]::IsNullOrWhiteSpace($historySearch.Text)) {
        Set-HistorySearchPlaceholder
    }
})


function Test-HistoryCopyColumn([int]$columnIndex) {
    if ($columnIndex -lt 0 -or $columnIndex -ge $historyGrid.Columns.Count) {
        return $false
    }

    $columnName = [string]$historyGrid.Columns[$columnIndex].Name
    return (@("ConsultationDate","Slot","ID") -contains $columnName)
}

function Copy-HistoryCellValue([int]$rowIndex, [int]$columnIndex) {
    if ($rowIndex -lt 0 -or
        $rowIndex -ge $historyGrid.Rows.Count -or
        -not (Test-HistoryCopyColumn $columnIndex)) {
        return $false
    }

    $cell = $historyGrid.Rows[$rowIndex].Cells[$columnIndex]
    $value = [string]$cell.Value

    if ([string]::IsNullOrWhiteSpace($value)) {
        return $false
    }

    Set-Clipboard -Value $value

    $columnName = [string]$historyGrid.Columns[$columnIndex].Name
    $message = switch ($columnName) {
        "ConsultationDate" { "Дата скопирована" }
        "Slot" { "Время скопировано" }
        "ID" { "ID скопирован" }
        default { "Скопировано" }
    }

    try {
        $rect = $historyGrid.GetCellDisplayRectangle($columnIndex, $rowIndex, $true)
        $historyCellCopyToolTip.Show(
            $message,
            $historyGrid,
            $rect.Left + 6,
            $rect.Bottom + 2,
            900
        )
    } catch {}

    return $true
}

$historyGrid.Add_CellDoubleClick({
    if ($_.RowIndex -ge 0 -and (Test-HistoryCopyColumn $_.ColumnIndex)) {
        # Одинарный CellClick уже скопировал значение.
        # Не открываем KTalk при двойном клике по Дате / Времени / ID.
        return
    }

    if ($historyGrid.SelectedRows.Count -eq 0) {
        return
    }

    $record = $historyGrid.SelectedRows[0].Tag
    if ($null -eq $record) {
        return
    }

    $url = [string]$record.URL
    if ([string]::IsNullOrWhiteSpace($url) -or -not $url.StartsWith("http")) {
        Show-Info "У этой сделки нет рабочей KTalk-ссылки."
        return
    }

    Start-Process $url
})

$historyGrid.Add_CellClick({
    if ($_.RowIndex -ge 0) {
        [void](Copy-HistoryCellValue $_.RowIndex $_.ColumnIndex)
        Open-HandoffForSelectedRecord
    }
})

$historyGrid.Add_CellMouseEnter({
    if ($_.RowIndex -ge 0 -and (Test-HistoryCopyColumn $_.ColumnIndex)) {
        $historyGrid.Cursor = [System.Windows.Forms.Cursors]::Hand
    } else {
        $historyGrid.Cursor = [System.Windows.Forms.Cursors]::Default
    }
})

$historyGrid.Add_CellMouseLeave({
    $historyGrid.Cursor = [System.Windows.Forms.Cursors]::Default
})

$historyGrid.Add_KeyDown({
    if ($_.Control -and $_.KeyCode -eq [System.Windows.Forms.Keys]::C) {
        if ($null -ne $historyGrid.CurrentCell) {
            if (Copy-HistoryCellValue $historyGrid.CurrentCell.RowIndex $historyGrid.CurrentCell.ColumnIndex) {
                $_.SuppressKeyPress = $true
            }
        }
    }
})

$historyGrid.Add_KeyUp({
    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Up -or
        $_.KeyCode -eq [System.Windows.Forms.Keys]::Down -or
        $_.KeyCode -eq [System.Windows.Forms.Keys]::Enter) {
        Open-HandoffForSelectedRecord
    }
})

$historyGrid.Add_SelectionChanged({
    $deleteHistoryButton.Enabled = $true

    if ($historyGrid.SelectedRows.Count -gt 0) {
        $record = $historyGrid.SelectedRows[0].Tag

        # Во время Refresh-HistoryGrid событие иногда приходит до заполнения Row.Tag.
        # В таком случае ничего не делаем — после Refresh строка будет активирована явно.
        if ($null -ne $record) {
            Activate-HistoryRecord $record
        }
    } else {
        Update-WorkflowPanel $null
    }
})

$deleteHistoryButton.Add_Click({
    Delete-SelectedHistoryRecord
})

$undoDeleteAction.Add_Click({
    Undo-LastDeletion
})

$undoDeleteTimer.Add_Tick({
    Hide-DeleteUndo
})

$form.Add_KeyDown({
    if ([string]::IsNullOrWhiteSpace([string]$script:slotFilter)) {
        return
    }

    # В самой таблице стрелки уже работают нативно.
    if ($historyGrid.Focused) {
        return
    }

    # Не перехватываем стрелки, пока пользователь что-то вводит.
    if ($idBox.Focused -or
        $historySearch.Focused -or
        $customTimeText.Focused -or
        $clientPhoneBox.Focused -or
        $parentNameBox.Focused -or
        $studentNameBox.Focused -or
        $childClassBox.Focused -or
        $leadSourceBox.Focused) {
        return
    }

    if ($_.KeyCode -eq [System.Windows.Forms.Keys]::Down) {
        $_.SuppressKeyPress = $true
        Move-HistorySelection 1
    }
    elseif ($_.KeyCode -eq [System.Windows.Forms.Keys]::Up) {
        $_.SuppressKeyPress = $true
        Move-HistorySelection -1
    }
})

# Удаление сделки оставлено только в контекстном меню.
# Клавиша Delete намеренно не удаляет записи.


$confirmDealButton.Add_Click({
    Toggle-Confirmation
})

$reassignDealButton.Add_Click({
    Set-PreConfirmDecision "ПЕРЕНАЗНАЧИТЬ"
})

$refuseDealButton.Add_Click({
    Set-PreConfirmDecision "ОТКАЗ ОТ ДИАГНОСТИКИ"
})

$clearDecisionButton.Add_Click({
    Clear-PreConfirmDecision
})

$clipboardImportButton.Add_Click({[void](Import-AmoClipboard $false)})

$copySheetsButton.Add_Click({
    Copy-ForGoogle
})

$handoffDoneButton.Add_Click({
    Mark-HandoffDone
})

$clientPhoneBox.Add_Leave({
    Save-WorkflowFields
})

$parentNameBox.Add_Leave({
    Save-WorkflowFields
})

$studentNameBox.Add_Leave({
    Save-WorkflowFields
})

$childClassBox.Add_Leave({
    Save-WorkflowFields
})

$leadSourceBox.Add_Leave({
    Save-WorkflowFields
})

$exportButton.Add_Click({
    $selectedDateText = $datePicker.Value.ToString("dd.MM.yyyy")
    $selectedDateFile = $datePicker.Value.ToString("yyyy-MM-dd")

    $items = @(
        $script:history | Where-Object {
            $_.ConsultationDate -eq $selectedDateText
        }
    )

    if ($items.Count -eq 0) {
        Show-Info "На выбранную дату пока нет актуальных встреч."
        return
    }

    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = "CSV (*.csv)|*.csv"
    $dialog.FileName = "KTALK_$selectedDateFile.csv"

    if ($dialog.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        $items |
            Sort-Object Slot, ID |
            Export-Csv $dialog.FileName -Delimiter ';' -Encoding UTF8 -NoTypeInformation

        Show-Info "Актуальные встречи экспортированы:`r`n$($dialog.FileName)"
    }
})

$refreshApi.Add_Click({ Update-ApiStatus })
$settingsButton.Add_Click({ Show-Settings })

$trayOpen.Add_Click({ Show-Main })

$trayExit.Add_Click({
    Save-UiState
    $script:exitRequested = $true
    $form.Close()
})

$notify.Add_DoubleClick({ Show-Main })

$form.Add_Resize({
    if ($form.WindowState -eq [System.Windows.Forms.FormWindowState]::Minimized) {
        $form.Hide()

        if ([bool]$script:settings.Notifications) {
            $notify.BalloonTipTitle = "KTalk Creator"
            $notify.BalloonTipText = "Приложение продолжает работать в системном трее."
            $notify.ShowBalloonTip(1000)
        }
    }
})

$form.Add_FormClosing({
    Save-UiState
    if (-not $script:exitRequested) {
        $_.Cancel = $true
        $form.Hide()

        if ([bool]$script:settings.Notifications) {
            $notify.BalloonTipTitle = "KTalk Creator"
            $notify.BalloonTipText = "Приложение скрыто в трей. Для выхода используйте меню значка."
            $notify.ShowBalloonTip(1000)
        }
    }
})

$form.Add_Activated({
    Detect-ClipboardContent
})

$form.Add_Shown({
    # Fixed geometry guard. WinForms may perform an extra layout pass on first show;
    # restore the intended dimensions after that pass.
    $mainPagePanel.Location = New-Object System.Drawing.Point(22, 112)
    $mainPagePanel.Size = New-Object System.Drawing.Size(1195, 592)
    $dealsPagePanel.Location = New-Object System.Drawing.Point(22, 112)
    $dealsPagePanel.Size = New-Object System.Drawing.Size(1195, 592)

    $plannerCard.Location = New-Object System.Drawing.Point(0, 14)
    $plannerCard.Size = New-Object System.Drawing.Size(725, 578)
    $mainTableCard.Location = New-Object System.Drawing.Point(743, 14)
    $mainTableCard.Size = New-Object System.Drawing.Size(452, 338)
    $mainMessageCard.Location = New-Object System.Drawing.Point(743, 360)
    $mainMessageCard.Size = New-Object System.Drawing.Size(452, 218)

    $historyCard.Location = New-Object System.Drawing.Point(0, 0)
    $historyCard.Size = New-Object System.Drawing.Size(1195, 258)
    $dealsHandoffCard.Location = New-Object System.Drawing.Point(0, 274)
    $dealsHandoffCard.Size = New-Object System.Drawing.Size(585, 310)
    $dealsTimelineCard.Location = New-Object System.Drawing.Point(603, 274)
    $dealsTimelineCard.Size = New-Object System.Drawing.Size(592, 310)

    # Final startup pass for centered editable fields.
    Update-DateStyleTextFieldLayout $customTimeValueShell $customTimeText
    Update-DateStyleTextFieldLayout $idValueShell $idBox

    foreach ($box in @($clientPhoneBox, $parentNameBox, $studentNameBox, $childClassBox, $leadSourceBox)) {
        Update-CenteredTextBox $box
    }

    [void](Archive-PastHistory)
    Update-CreateButtonStyles
    Apply-Theme
    $toolTip.SetToolTip($deleteHistoryButton, "Удалить выбранную сделку")
    Set-HistorySearchPlaceholder
    Restore-UiState
    Update-ApiStatus
    Check-HandoffReminders
    Detect-ClipboardContent
    $updateCheckTimer.Start()
})

# ==================== Start ====================

if (Test-FirstRunRequired) {
    $script:firstRunSaved = $false

    if (-not (Show-FirstRunSetup)) {
        try { $script:singleInstanceMutex.Dispose() } catch {}
        exit
    }
}

[System.Windows.Forms.Application]::Run($form)

$handoffTimer.Stop()
$handoffTimer.Dispose()
$undoDeleteTimer.Stop()
$undoDeleteTimer.Dispose()
$updateCheckTimer.Stop()
$updateCheckTimer.Dispose()
$notify.Visible = $false
$notify.Dispose()

foreach ($font in @($script:uiFontCache.Values | Select-Object -Unique)) {
    try { $font.Dispose() } catch {}
}
$script:uiFontCache.Clear()

Remove-Item Env:\KTALK_API_KEY -ErrorAction SilentlyContinue
$script:plainKey = $null

try {
    $script:singleInstanceMutex.ReleaseMutex()
} catch {}

try {
    $script:singleInstanceMutex.Dispose()
} catch {}
