﻿param(
    [Parameter(Mandatory=$true)]
    [string]$PackagePath,

    [Parameter(Mandatory=$true)]
    [string]$ExpectedVersion,

    [Parameter(Mandatory=$true)]
    [int]$ParentPid
)

Add-Type -AssemblyName System.Windows.Forms

$ErrorActionPreference = "Stop"
$target = "C:\ktalk-auto"
$tempDir = Join-Path $env:TEMP ("KTalkCreator_Update_" + [Guid]::NewGuid().ToString("N"))
$backupRoot = Join-Path $target "backups"
$timestamp = Get-Date -Format "yyyyMMdd-HHmmss"
$backupDir = Join-Path $backupRoot ("before-" + $ExpectedVersion + "-" + $timestamp)

function Fail([string]$message) {
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        "KTalk Creator — обновление",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Error
    ) | Out-Null
    exit 1
}

try {
    try {
        $process = Get-Process -Id $ParentPid -ErrorAction SilentlyContinue
        if ($null -ne $process) {
            $process.WaitForExit(15000) | Out-Null
        }
    } catch {}

    if (-not (Test-Path $PackagePath)) {
        Fail "Файл обновления не найден."
    }

    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    Expand-Archive -Path $PackagePath -DestinationPath $tempDir -Force

    $payloadRoot = $tempDir
    if (Test-Path (Join-Path $tempDir "payload")) {
        $payloadRoot = Join-Path $tempDir "payload"
    }

    $newGui = Join-Path $payloadRoot "KTalk_GUI.ps1"
    if (-not (Test-Path $newGui)) {
        Fail "В пакете обновления нет KTalk_GUI.ps1."
    }

    $tokens = $null
    $parseErrors = $null
    [void][System.Management.Automation.Language.Parser]::ParseFile(
        $newGui,
        [ref]$tokens,
        [ref]$parseErrors
    )

    if ($parseErrors.Count -gt 0) {
        $details = ($parseErrors | ForEach-Object {
            "Строка $($_.Extent.StartLineNumber): $($_.Message)"
        }) -join "`r`n"

        Fail ("Новый GUI не прошёл проверку PowerShell.`r`n`r`n" + $details)
    }

    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    $appFiles = @(
        "KTalk_GUI.ps1",
        "create_room.php",
        "api_check.php",
        "launch_hidden.vbs",
        "KTalk_Updater.ps1",
        "version.json"
    )

    foreach ($name in $appFiles) {
        $current = Join-Path $target $name
        if (Test-Path $current) {
            Copy-Item $current (Join-Path $backupDir $name) -Force
        }
    }

    foreach ($name in $appFiles) {
        $source = Join-Path $payloadRoot $name
        if (Test-Path $source) {
            Copy-Item $source (Join-Path $target $name) -Force
        }
    }

    [System.Windows.Forms.MessageBox]::Show(
        "KTalk Creator обновлён до версии $ExpectedVersion.`r`n`r`nПредыдущая версия сохранена:`r`n$backupDir",
        "KTalk Creator",
        [System.Windows.Forms.MessageBoxButtons]::OK,
        [System.Windows.Forms.MessageBoxIcon]::Information
    ) | Out-Null

    Start-Process "$env:SystemRoot\System32\wscript.exe" -ArgumentList '"C:\ktalk-auto\launch_hidden.vbs"'
} catch {
    Fail ("Не удалось установить обновление:`r`n" + $_.Exception.Message)
} finally {
    Remove-Item $tempDir -Recurse -Force -ErrorAction SilentlyContinue
}
