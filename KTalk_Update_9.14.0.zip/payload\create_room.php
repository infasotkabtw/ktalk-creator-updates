﻿<?php

require __DIR__ . '/vendor/autoload.php';

use Kontur\Talk\TalkClient;

function failFriendly(string $message, int $code = 1): void {
    fwrite(STDERR, $message . PHP_EOL);
    exit($code);
}

function friendlyException(Throwable $e): string {
    $message = $e->getMessage();
    $code = (int)$e->getCode();
    $lower = mb_strtolower($message);

    if (str_contains($lower, 'curl error 6') || str_contains($lower, 'could not resolve')) {
        return 'Нет интернета или не удаётся найти сервер KTalk.';
    }
    if (str_contains($lower, 'curl error 7') || str_contains($lower, 'failed to connect')) {
        return 'Не удалось подключиться к KTalk. Проверьте интернет или VPN/прокси.';
    }
    if (str_contains($lower, 'curl error 28') || str_contains($lower, 'timed out')) {
        return 'KTalk не ответил вовремя. Повторите попытку.';
    }
    if (str_contains($lower, 'curl error 60') || str_contains($lower, 'certificate')) {
        return 'Ошибка SSL-сертификата на этом компьютере.';
    }
    if ($code === 401 || str_contains($lower, '401')) {
        return 'API-ключ недействителен или истёк.';
    }
    if ($code === 403 || str_contains($lower, '403') || str_contains($lower, 'forbidden')) {
        return 'У API-ключа недостаточно прав для создания комнаты.';
    }
    if ($code === 429 || str_contains($lower, '429')) {
        return 'Слишком много запросов к KTalk. Подождите немного.';
    }

    if ($message === '' || $message === 'API error') {
        return 'KTalk вернул ошибку и не создал комнату.';
    }

    return 'KTalk: ' . $message;
}

if ($argc < 5) {
    failFriendly('Не переданы ID, имя комнаты, дата или время.');
}

$leadId = trim($argv[1]);
$roomName = trim($argv[2]);
$date = trim($argv[3]);
$slot = trim($argv[4]);

if (!preg_match('/^\d+$/', $leadId)) {
    failFriendly('ID сделки должен состоять только из цифр.');
}

if (!preg_match('/^[a-z0-9]{10,32}$/', $roomName)) {
    failFriendly('Некорректное техническое имя комнаты.');
}

if (!preg_match('/^(?:[01]\d|2[0-3]):[0-5]\d$/', $slot)) {
    failFriendly('Некорректное время. Используйте формат HH:mm.');
}

$apiKey = getenv('KTALK_API_KEY');
if (!$apiKey) {
    failFriendly('API-ключ KTalk не загружен.');
}

$tz = new DateTimeZone('Europe/Moscow');
$start = DateTime::createFromFormat('!Y-m-d H:i', "$date $slot", $tz);

if (!$start) {
    failFriendly('Некорректная дата или время.');
}

$end = clone $start;
$end->modify('+90 minutes');

$expiration = clone $end;
$expiration->modify('+1 day');
$expiration->setTimezone(new DateTimeZone('UTC'));

try {
    $client = new TalkClient('oooparta', $apiKey);

    $client->rooms->createOrUpdate($roomName, [
        'title' => $leadId,
        'description' => sprintf(
            'Консультация PARTA — %s, %s–%s МСК',
            $start->format('d.m.Y'),
            $start->format('H:i'),
            $end->format('H:i')
        ),
        'allowAnonymous' => true,
        'anonymousAccessExpirationDate' => $expiration->format('Y-m-d\TH:i:s\Z'),
        'enableLobby' => false,
        'audioPolicy' => 'none',
        'videoPolicy' => 'none',
        'screenSharePolicy' => 'none',
    ]);

    echo json_encode([
        'ok' => true,
        'id' => $leadId,
        'roomName' => $roomName,
        'date' => $start->format('d.m.Y'),
        'start' => $start->format('H:i'),
        'end' => $end->format('H:i'),
        'url' => 'https://oooparta.ktalk.ru/' . $roomName,
    ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

} catch (Throwable $e) {
    failFriendly(friendlyException($e), 2);
}
